/**
 * $Id: StringTemplatesManager.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.uism;

/**
 * Accessor interface of an {@linkplain org.jwaresoftware.internal.apis.UIStringManager}
 * that manages standard {@linkplain java.text.MessageFormat MessageFormat}
 * string templates.
 *
 * @since    JWare/internal 1.2
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,helper
 **/

public interface StringTemplatesManager
{
    /**
     * Retrieves a message template. Caller responsible for all
     * placeholder substitution. Returns <i>null</i> if cannot locate
     * or load message format.
     * @throws IllegalArgumentException if string id is <i>null</i>
     **/
    String getFormat(String id);
}


/* end-of-StringTemplatesManager.java */
