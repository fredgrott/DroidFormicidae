/**
 * $Id: EmptyStringManager.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.uism;

import  java.text.MessageFormat;

import  org.jwaresoftware.internal.apis.UIStringManager;

/**
 * UIStringManager that returns your default message or the incoming message's
 * identifier. Works as a harmless proxy.
 *
 * @since    JWare/internal 1.0
 * @author   ssmc, &copy;1997-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern JWare.NullProxy
 **/

public final class EmptyStringManager implements UIStringManager
{
    /**
     * A VM-shareable (empty) string manager reference; never null.
     **/
    public static final EmptyStringManager INSTANCE = new EmptyStringManager();



    /**
     * Standard API for retrieving {@linkplain #INSTANCE singleton}.
     **/
    public static final EmptyStringManager getInstance()
    {
        return INSTANCE;
    }


    /**
     * Creates a new empty string manager with optional default (only)
     * message. If default message is undefined (null), this manager
     * will return each incoming query's message id as the message text.
     * @param defm [optional] default message
     **/
    public EmptyStringManager(String defm)
    {
        if (defm!=null) {
            m_defaultStr= defm;
        } else {
            m_defaultStr= null;
        }
    }


    /**
     * Creates a new empty string manager that returns the incoming
     * message id as the message text.
     **/
    public EmptyStringManager()
    {
        this(null);
    }



    /**
     * Determine what string gets returned by this manager. Will return
     * the incoming msgid itself (as placeholder) if no default message
     * provided.
     * @param msgid the message identifier (usually useful name)
     * @param defm [optional] default incoming message
     * @return message to publish
     * @since JWare/internal 1.3
     **/
    private String theMsg(String msgid, String defm)
    {
        if (defm!=null) {
            return defm;
        }
        if (m_defaultStr!=null) {
            return m_defaultStr;//NB:even if empty string...
        }
        return msgid;
    }



    /**
     * Returns default message (either incoming or manager's).
     **/
    public final String mget(String id, Object[] args, String defm)
    {
        if (id==null) {
            throw new IllegalArgumentException("get- NULL msgid");
        }
        return theMsg(id,defm);
    }



    /**
     * Returns default message (either incoming or manager's).
     **/
    public final String mget(MessageFormat mf, String id, Object[] args, String defm)
    {
        if (mf==null || id==null) {
            throw new IllegalArgumentException("get- NULL msgid or msgfmt");
        }
        return theMsg(id,defm);
    }



    /**
     * Returns <i>null</i> this object is considered empty.
     **/
    public final String getFormat(String id)
    {
        if (id==null) {
            throw new IllegalArgumentException("getfmt- NULL msgid");
        }
        return null;
    }



    /**
     * Retrieves a named message; assumes no placeholder substitution.
     **/
    public final String get(String id)
    {
        return mget(id, (Object[])null, (String)null);
    }



    /**
     * Retrieves a message or default if message not found.
     **/
    public final String dget(String id, String defm)
    {
        return mget(id, (Object[])null, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String mget(String id, Object[] args)
    {
        return mget(id,args,null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String dget(String id, Object arg1, String defm)
    {
        return mget(id, new Object[]{arg1}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1)
    {
        return mget(id, new Object[]{arg1}, null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String dget(String id, Object arg1, Object arg2, String defm)
    {
        return mget(id, new Object[]{arg1,arg2}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1, Object arg2)
    {
        return mget(id, new Object[]{arg1,arg2}, null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String dget(String id, Object arg1, Object arg2, Object arg3, String defm)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1, Object arg2, Object arg3)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, null);
    }



    /**
     * Returns the default string for this UIStringManager.
     **/
    public final String getDefaultString()
    {
        if (m_defaultStr==null) {
            return "An unknown problem has occured.";
        }
        return m_defaultStr;
    }


    private final String m_defaultStr;
}

/* end-of-EmptyStringManager.java */
