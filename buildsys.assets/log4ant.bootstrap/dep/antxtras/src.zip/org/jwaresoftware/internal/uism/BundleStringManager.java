/**
 * $Id: BundleStringManager.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.uism;

import  java.text.FieldPosition;
import  java.text.MessageFormat;
import  java.util.Locale;
import  java.util.MissingResourceException;
import  java.util.ResourceBundle;

import  org.jwaresoftware.internal.apis.UIStringManager;
import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * UIStringManager that manages the locating and retrieval of localized strings
 * from a standard Java resource bundle file (a <span class="src">Properties</span> file).
 * Safe for concurrent read access.
 * <p>
 * If you use chained bundle string managers (see {@linkplain #setNextUISM setNexUISM()})
 * method and also want to provide a default message, set the <em>last</em>
 * searched string manager's default message to your default string. Also note that
 * any request-supplied default message takes precedence over any "next-in-line" string
 * managers.
 * <p>
 * To have a bundle string manager report all of its missed resource lookups, set the
 * system property <span class="src">jware.trace.uism.calls</span> to
 * "<span class="src">true</span>".
 *
 * @since    JWare/internal 1.0
 * @author   ssmc, &copy;1997-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded
 * @.group   impl,infra
 **/

public class BundleStringManager implements UIStringManager, StringTemplatesManager
{
    /**
     * Setup this manager's default string based on constructor args.
     **/
    private void initDefaultString(ResourceBundle strings, String defm)
    {
        m_defaultStr = "";
        if (defm!=null) {
            try {
                m_defaultStr= strings.getString(defm);
            } catch(Exception ix) {
                unexpected_(ix,"Unable to locate default message("+defm+")");
            }
        }
    }



    /**
     * Create new string manager using given properties file as source
     * of localized strings. A default string is specified in case a localized
     * string is missing (or cannot be loaded).
     * @param bndlLocation resource bundle's location (non-null)
     * @param loc preferred locale (non-null)
     * @param defm default string to use for missing messages
     * @throws IllegalArgumentException if either location or locale is <i>null</i>
     **/
    public BundleStringManager(String bndlLocation, Locale loc, String defm)
    {
        if (bndlLocation==null || loc==null) {
            throw new IllegalArgumentException("Non-null bundle and locale");
        }
        m_name = "ResourceBundle@"+bndlLocation;
        m_strings = ResourceBundle.getBundle(bndlLocation, loc);
        initDefaultString(m_strings,defm);
    }



    /**
     * Create new string manager using given properties file as source
     * of strings (uses default Locale). If a requested string is missing or
     * cannot be loaded, an empty string is returned.
     * @see java.util.Locale#getDefault
     * @param bndlLocation resource bundle's location (non-null)
     * @throws IllegalArgumentException if location is <i>null</i>
     **/
    public BundleStringManager(String bndlLocation)
    {
        this(bndlLocation,Locale.getDefault(),null);
    }



    /**
     * Creates new string manager for an existing resource bundle o'
     * strings. Allows a string manager to be created for strings loaded
     * through alternative mechanisms.
     * @param strings already loaded resource bundle
     * @param defm [optional] default message's bundle key
     * @throws IllegalArgumentException if bundle is <i>null</i>
     **/
    public BundleStringManager(ResourceBundle strings, String defm)
    {
        if (strings==null) {
            throw new IllegalArgumentException("Non-null rez bundle");
        }
        m_name = "ResourceBundle@"+System.identityHashCode(strings);
        m_strings = strings;
        initDefaultString(strings, defm);
    }



    /**
     * Retrieves a localized message with given arguments substituted for
     * appropriate placeholders. Uses defm as a default response if cannot
     * locate the message template.
     * @throws IllegalArgumentException if string id is <i>null</i>
     **/
    public String mget(String id, Object[] args, String defm)
    {
        if (id==null) {
            throw new IllegalArgumentException("get- NULL msgid");
        }
        String tmpl=null;
        try {
            tmpl = m_strings.getString(id);
            if (args==null || args.length==0) {//NB: don't create format obj!
                return tmpl;
            }
            return MessageFormat.format(tmpl, args);
        } catch(MissingResourceException mx) {
            if (getNextUISM()!=null) {
                tmpl = getNextUISM().mget(id,args,m_name);
                if (m_name.equals(tmpl)) {
                    tmpl = null;//=> not found!
                }
            }
            if (tmpl!=null) {
                return tmpl;
            }
            unexpected_(mx,"Missing message: '"+id+"'");
            return (defm==null) ? m_defaultStr : defm;
        }
    }



    /**
     * Updates a string buffer with customized message with given arguments
     * substituted for appropriate placeholders. Uses defm as a default
     * response if cannot locate the message template. Buffer is <em>not</em>
     * cleared before text is appended.
     * @see #mget(MessageFormat, String, Object[], String) mget(&#8230;)
     * @throws IllegalArgumentException if either format or string id is <i>null</i>
     **/
    public StringBuffer fill(MessageFormat mf, String id, Object[] args,
                             StringBuffer sb, String defm)
    {
        if (id==null || mf==null) {
            throw new IllegalArgumentException("fill- NULL msgid or msgfmt");
        }
        String tmpl=null;
        try {
            if (sb==null) {
                sb= new StringBuffer(150);
            }
            tmpl= m_strings.getString(id);
            if (args==null || args.length==0) {
                sb.append(tmpl);//NB: don't create format obj unnecessarily
            } else {
                mf.applyPattern(tmpl);
                mf.format(args, sb, new FieldPosition(0));
            }
        } catch(MissingResourceException mx) {
            if (getNextUISM()!=null) {
                tmpl = getNextUISM().mget(mf,id,args,m_name);
                if (m_name.equals(tmpl)) {
                    tmpl = null;//=> not found!
                }
            }
            if (tmpl!=null) {
                sb.append(tmpl);
            } else {
                unexpected_(mx,"Missing message: '"+id+"'");
                if (defm==null) {
                    sb.append(m_defaultStr);
                } else {
                    sb.append(defm);
                }
            }
        }
        return sb;
    }



    /**
     * Retrieves a customized message with given arguments substituted for
     * appropriate placeholders. Uses defm as a default response if cannot
     * locate the message template.
     * @see #fill fill(&#8230;)
     **/
    public String mget(MessageFormat mf, String id, Object[] args, String defm)
    {
        StringBuffer output= fill(mf,id,args,null,defm);
        return output.substring(0);
    }



    /**
     * Retrieves a localized message template. Caller responsible for all
     * placeholder substitution. Returns <i>null</i> if cannot locate or
     * load message format.
     * @throws IllegalArgumentException if string id is <i>null</i>
     **/
    public final String getFormat(String id)
    {
        if (id==null) {
            throw new IllegalArgumentException("getf- NULL msgid");
        }
        try {
            return m_strings.getString(id);
        } catch(MissingResourceException mx) {
            if (getNextUISM() instanceof StringTemplatesManager) {
                return ((StringTemplatesManager)getNextUISM()).getFormat(id);
            }
            unexpected_(mx,"Missing message: '"+id+"'");
        }
        return null;
    }



    /**
     * Retrieves a named message; assumes no placeholder substitution.
     **/
    public final String get(String id)
    {
        return mget(id,(Object[])null,(String)null);
    }



    /**
     * Retrieves a message or default if message not found.
     **/
    public final String dget(String id, String defm)
    {
        return mget(id, (Object[])null, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String mget(String id, Object[] args)
    {
        return mget(id,args,null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders;
     * returns default message if message id not found.
     **/
    public final String dget(String id, Object arg1, String defm)
    {
        return mget(id, new Object[]{arg1}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1)
    {
        return mget(id, new Object[]{arg1}, null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders;
     * returns default message if message id not found.
     **/
    public final String dget(String id, Object arg1, Object arg2, String defm)
    {
        return mget(id, new Object[]{arg1,arg2}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1, Object arg2)
    {
        return mget(id, new Object[]{arg1,arg2}, null);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders;
     * returns default message if message id not found.
     **/
    public final String dget(String id, Object arg1, Object arg2, Object arg3, String defm)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, defm);
    }



    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    public final String get(String id, Object arg1, Object arg2, Object arg3)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, null);
    }


    /**
     * Returns the default string for this UIStringManager.
     **/
    public final String getDefaultString()
    {
        return m_defaultStr;
    }


    /**
     * Sets this string manager's next-in-line UISM. This method should
     * be called near construction time.
     * @param uism next SM in chain (<i>null</i> terminates chain here)
     * @.safety single
     * @since JWare/internal 1.2
     **/
    public void setNextUISM(UIStringManager uism)
    {
        m_nextUISM= uism;
    }


    /**
     * Returns this string manager's next-in-line UISM. Returns <i>null</i>
     * if never explicitly set.
     * @since JWare/internal 1.2
     **/
    protected UIStringManager getNextUISM()
    {
        return m_nextUISM;
    }



    /** Replacement for AntXtras Assertable's implementation. **/
    private void unexpected_(Throwable cause, String msg)
    {
        String s = SystemFixture.getProperty("jware.trace.uism.calls");
        if ("true".equals(s) || "yes".equals(s)) {
            SystemFixture.puterr("[ALERT] ", m_name+": "+msg);
        }
    }


    /* ---------- seekrit implementation details ----------- */
    private final String m_name;
    protected final ResourceBundle m_strings;//ro,required to be readonly
    protected String m_defaultStr;
    protected UIStringManager m_nextUISM;
}

/* end-of-BundleStringManager.java */
