/**
 * $Id: FixtureProperties.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.fixture;

import  java.util.Properties;

/**
 * Overlay Properties class that ensures system properties are queried
 * via the System API not generic Properties API so all security checks
 * are performed.
 *
 * @since     JWare/internal 2.0
 * @author    ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   guarded
 * @.group    impl,helper
 * @see       SystemFixture
 * @.caveat   On queries, security triggered rejections are dropped.
 **/

public final class FixtureProperties extends Properties
{
    /**
     * Initializes a new "empty" fixture properties. Note that a
     * fixture properties object is never empty technically as it
     * defers to the system properties always.
     **/
    public FixtureProperties()
    {
        super();
    }



    /**
     * Initializes a new "empty" fixture properties with an set of
     * defaults in between it and the system. See note for void
     * constructor regarding "emptiness" of fixture properties.
     * @param defaults default properties (non-null)
     **/
    public FixtureProperties(Properties defaults)
    {
        super(defaults);
        if (defaults==System.getProperties()) {
            throw new IllegalArgumentException
                ("System security check bypass attempt");
        }
    }



    /**
     * Fall back to system if property is not explicitly part
     * of this fixture. Allows balk on missing security permission
     * (eventhough we convert that to a <i>null</i>).
     **/
    public String getProperty(String key)
    {
        String v = super.getProperty(key);
        if (v==null) {
            try {
                v = System.getProperty(key);//Enforce security!
            }
            catch(SecurityException x)          {/*burp*/}
            catch(IllegalArgumentException iax) {/*burp*/}
            catch(NullPointerException npx)     {/*burp*/}
        }
        return v;
    }
}

/* end-of-FixtureProperties.java */
