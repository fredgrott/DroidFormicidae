/**
 * $Id: IfErrorTask.java 1311 2012-07-07 19:18:04Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.wrap;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.BuildAssertionException;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.ErrorSnapshot;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;
import  org.jwaresoftware.antxtras.parameters.PropertySource;
import  org.jwaresoftware.antxtras.starters.StrictInnerTaskSet;
import  org.jwaresoftware.antxtras.starters.Quiet;

/**
 * Set of tasks to be executed iff an build exception is detected by a
 * protected taskset. Must be nested within a {@linkplain TolerantTaskSet
 * TolerantTaskSet} like a ProtectedTaskSet.
 * <p>
 * If you specify an error substitution (see the <span class="src">convertto</span>
 * option), this task will store the <em>converted</em> error to any snapshots and/or
 * project references. The original error will be stored as the new error's causing
 * throwable.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @see      TolerantTaskSet
 **/

public final class IfErrorTask extends StrictInnerTaskSet implements Quiet
{
    /**
     * Creates a new iferror handler in a protected taskset.
     **/
    public IfErrorTask()
    {
        super(AntX.flowcontrol+"ProtectedTaskSet:");
    }


    /**
     * Sets the name of property updated with either a predefined
     * {@linkplain #setFailValue value} or the thrown exception's
     * message.
     * @see #setFailValue
     **/
    public void setFailProperty(String property)
    {
        require_(property!=null,"setFailProp- nonzro propnam");
        m_failProperty = property;
    }


    /**
     * Returns name of the property to be updated iff a build
     * exception is detected by this task's enclosing protected
     * taskset. Returns <i>null</i> if never set.
     **/
    public final String getFailProperty()
    {
        return m_failProperty;
    }


    /**
     * Sets the name of an exported property updated with either
     * a predefined {@linkplain #setFailValue value} or the
     * thrown exception's message.
     * @see #setFailValue
     * @since JWare/AntX 0.2
     **/
    public void setFailVariable(String variable)
    {
        require_(variable!=null,"setFailVar- nonzro varnam");
        m_failVar = variable;
    }


    /**
     * Returns name of the exported property to be updated iff a build
     * exception is detected by this task's enclosing protected
     * taskset. Returns <i>null</i> if never set.
     **/
    public final String getFailVariable()
    {
        return m_failVar;
    }


    /**
     * Sets the value used to set the failure property if a
     * build exception is detected. By default, if requested,
     * the fail property is set to the exception's message.
     **/
    public void setFailValue(String value)
    {
        require_(value!=null,"setfailV- nonzro valu");
        m_failValue = value;
    }


    /**
     * Returns the explicit value to which the failure property
     * is set in event of detected build exception. Returns
     * <i>null</i> if never set.
     **/
    public final String getFailValue()
    {
        return m_failValue;
    }


    /**
     * Sets the name of an {@linkplain ErrorSnapshot ErrorSnapshot}
     * reference to be created iff a build exception is detected. This
     * name should not refer to an existing project reference.
     * @param reference name of <em>new</em> reference
     **/
    public void setCaptureSnapshotRefId(String reference)
    {
        m_failSnapshotRefId= reference;
    }


    /**
     * Returns the name of a <em>new</em> ErrorSnapshot reference
     * to be created iff a build exception is detected.
     **/
    public final String getCaptureSnapshotRefId()
    {
        return m_failSnapshotRefId;
    }


    /**
     * Alias for {@linkplain #setCaptureSnapshotRefId setCaptureSnapshotRefId}
     * that is typically used from build xml (easier element name).
     **/
    public final void setCaptureSnapshot(String newRefId)
    {
        setCaptureSnapshotRefId(newRefId);
    }


    /**
     * Set the name of an BuildException reference to be created iff
     * a build exception is detected. This name should not refer to
     * an existing reference (overwritten).
     **/
    public void setCaptureThrownRefId(String reference)
    {
        m_failThrownRefId = reference;
    }


    /**
     * Alias for {@linkplain #setCaptureThrownRefId setCaptureThrownRefId}
     * that is typically used from build xml (easier element name).
     **/
    public final void setCaptureThrown(String thrownRefId)
    {
        setCaptureThrownRefId(thrownRefId);
    }


    /**
     * Returns the name of the <em>new</em> BuildException reference
     * to be created iff a build exception is detected.
     **/
    public final String getCaptureThrownRefId()
    {
        return m_failThrownRefId;
    }


    /**
     * Sets a comma-delimited list of properties to be captured with
     * an error snapshot if an exception is detected. If the given
     * namesList is either one of the symbolic property domain names
     * like "<span class="src">script</span>" or "<span class="src">jre</span>"
     * all of the matching domain's properties are included in the
     * snapshot.
     * @param namesList comma-delimited list of names
     * @see #setCaptureSnapshotRefId
     **/
    public void setCapturePropertyNames(String namesList)
    {
        require_(namesList!=null,"setCapturPs- nonzro list");
        m_propertyNames= namesList;
    }


    /**
     * Returns comma-delimited list of properties to be captured
     * with an error snapshot in the event of a detected build
     * exception. Will return <i>null</i> if never set.
     **/
    public final String getCapturePropertyNames()
    {
        return m_propertyNames;
    }


    /**
     * Alias to {@linkplain #setCapturePropertyNames setCapturePropertyNames}
     * that is typically used from build xml (easier element name).
     **/
    public final void setCaptureProperties(String namesList)
    {
        setCapturePropertyNames(namesList);
    }



    /**
     * Tells this handler to convert the captured error to something
     * else on script's behalf.
     * @param what "new", "assert" or custom exception class name
     * @since JWare/AntX 0.4
     **/
    public void setConvertTo(String what)
    {
        require_(what!=null,"setCvtTo- nonzro target");
        m_convertTo= what;
    }



    /**
     * Tells this handler to be quiet when it captures an error. Will
     * prevent informative message from being written to log.
     * @param quiet <i>true</i> if be quiet.
     * @since JWare/AntX 0.5
     **/
    public final void setQuiet(boolean quiet)
    {
        m_tellCaught = quiet ? Boolean.FALSE : Boolean.TRUE;
    }



    /**
     * Returns this handler's script-supplied quiet flag. Will return
     * <i>null</i> if never set explicitly.
     * @since JWare/AntX 0.5
     **/
    public final Boolean getQuietFlag()
    {
        return m_tellCaught;
    }



    /**
     * Sets the range of thrown exception this handler deals with.
     * @param ofType class of matching exception (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public void setOfType(Class ofType)
    {
        require_(ofType!=null,"setOfType- nonzro type");
        m_ofType = ofType;
    }



    /**
     * Returns this handler's filter type or <i>null</i> if unfiltered.
     * @since JWare/AntXtras 3.0.0
     */
    final Class getOfTypeClass()
    {
        return m_ofType;
    }



    /**
     * Called by enclosing block to prepare this task for execution
     * because of a detected build exception, rtX. By default captures
     * any requested error snapshots and sets up failure properties.
     * As of AntXtras 3.0.0 will update the {@linkplain ThrownErrors}
     * stack with the returned exception.
     * @return the incoming exception or, if requested, a substitute.
     **/
    final RuntimeException throwOccured(RuntimeException rtX)
    {
        final Project P= getProject();
        TolerantTaskSet wrt= (TolerantTaskSet)getEnclosingTask();
        Requester callback = new Requester.ForComponent(this);

        if (tellCaught()) {
            int loglevel = Project.MSG_ERR;
            if (!wrt.isHaltIfError()) {
                loglevel = Project.MSG_INFO;
            }
            log(uistrs().get("flow.caught.failure",
                             wrt.getOwningTarget().getName(), Tk.messageFrom(rtX)),
                loglevel);
        }

        String what= getFailValue();
        if (what==null) {
            what= Tk.messageFrom(rtX);
        }

        if (getFailProperty()!=null) {
            P.setNewProperty(getFailProperty(), what);
        }
        if (getFailVariable()!=null) {
            Variables.set(getFailVariable(), what, callback);
        }

        rtX = getPreferredX(rtX);
        ThrownErrors.installLast(rtX,callback);

        if (getCaptureThrownRefId()!=null) {
            String refid= getCaptureThrownRefId();

            if (P.getReference(refid)!=null) {
                log(Errs.ReferenceExists(refid),Project.MSG_WARN);
            }
            P.addReference(refid,rtX);
        }

        if (getCaptureSnapshotRefId()!=null) {
            String refid = getCaptureSnapshotRefId();

            if (P.getReference(refid)!=null) {
                log(Errs.ReferenceExists(refid),Project.MSG_WARN);
            }

            ErrorSnapshot es= new ErrorSnapshot(wrt, rtX);
            es.setName(refid);

            String nl= getCapturePropertyNames();
            if (nl!=null) {
                PropertySource domain = PropertySource.from(nl);
                if (domain!=null) {
                    es.captureProperties
                        (FixtureExaminer.copyOfProperties(domain,P));
                } else {
                    es.captureProperties(nl);
                }
            }
            P.addReference(refid,es);
        }

        return rtX;
    }



    /**
     * Replace the actual exception with a script requested
     * substitution if necessary. Will return the original if no
     * substitution requested or unable to create new exception.
     * @param rtX the causing exception (non-null)
     * @return script-requesed replacement or same if no such request
     * @since JWare/AntX 0.4
     **/
    private RuntimeException getPreferredX(RuntimeException rtX)
    {
        if (m_convertTo!=null) {
            if ("new".equals(m_convertTo)) {
                rtX = new BuildException(rtX.getMessage(),rtX,getLocation());
            }
            else
            if ("assert".equals(m_convertTo)) {
                if (!(rtX instanceof BuildAssertionException)) {
                    rtX = (RuntimeException)LocalTk.replaceError
                                (rtX, getLocation(), BuildAssertionException.class);
                }
            }
            else {
                rtX = (RuntimeException)LocalTk.replaceError
                                (rtX, getLocation(), m_convertTo);
            }
        }
        return rtX;
    }



    private boolean tellCaught()
    {
        Boolean setting = getQuietFlag();
        if (setting==null) {
            FeedbackLevel fbL = FeedbackLevel.getDefaultIfErrorLevel(getProject());
            if (FeedbackLevel.isQuietish(fbL,false,false)) {
                setting = Boolean.FALSE;
            }
        }
        return m_tellCaught==null || m_tellCaught==Boolean.TRUE;
    }


    private String  m_failProperty, m_failVar;
    private String  m_failValue;
    private String  m_failSnapshotRefId, m_failThrownRefId;
    private String  m_propertyNames;
    private String  m_convertTo;
    private Boolean m_tellCaught;//NB: null=>YES!
    private Class   m_ofType;//OPTIONAL:class of valid thrown
}

/* end-of-IfErrorTask.java */
