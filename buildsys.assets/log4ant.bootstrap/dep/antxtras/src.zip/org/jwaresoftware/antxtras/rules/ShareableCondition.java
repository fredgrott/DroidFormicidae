/**
 * $Id: ShareableCondition.java 799 2009-06-26 11:06:01Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.jwaresoftware.antxtras.core.NoiseLevel;

/**
 * A rule that can be evaluation from multiple tasks in multiple threads concurrently
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 * @see      RuleSet
 **/

public interface ShareableCondition
{
    /**
     * Evaluates this condition and updates specified information if
     * rule evaluates <i>false</i>.
     * @param calr ultimate user of condition (non-null)
     **/
    boolean eval(ShareableConditionUser calr);


    /**
     * Returns this rule's dominant effect. If 'ERROR' a <i>false</i>
     * evaluation might be a build-stopper. If 'WARNING' the rule will not
     * abort the build process. If '<i>null</i>' the effect is either not
     * known or has yet to be determined. Helps rule users determine if
     * a referral is a compatible match.
     **/
    NoiseLevel getFailureEffect();
}

/* end-of-ShareableCondition.java */
