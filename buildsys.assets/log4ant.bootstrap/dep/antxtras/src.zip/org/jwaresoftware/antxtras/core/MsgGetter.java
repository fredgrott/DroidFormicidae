/**
 * $Id: MsgGetter.java 399 2008-04-06 01:33:21Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * Method selector on a UIStringManager. Allows UIStringManager users to
 * select different UIStringManager 'get' methods while calling a single
 * 'getMsg' API on the dependent task.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 * @see      AssertableTask#getMsg
 **/

public interface MsgGetter
{
    /**
     * Calls the appropriate UIStringManager 'get' method to retrieve
     * a message.
     **/
    String get(String msgId);
}

/* end-of-MsgGetter.java */
