/**
 * $Id: VendorInfoTask.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.install;

import  java.net.URL;
import  java.util.List;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;
import  org.apache.tools.ant.util.ClasspathUtils;

import  org.jwaresoftware.internal.apis.Buildstrs;
import  org.jwaresoftware.internal.fixture.SystemFixture;
import  org.jwaresoftware.internal.helpers.EmptyBuildstrs;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.CustomLoaderEnabled;
import  org.jwaresoftware.antxtras.parameters.FlexExistenceEnabled;

/**
 * Task that converts a standard JWare
 * <span class="src">{@linkplain Buildstrs Buildstrs}</span> bean into a set of
 * project properties.
 * <p>
 * <b> Example Usage:</b><pre>
 *    &lt;vendorinfo/&gt; &lt;-- implies AntXtras itself --&gt;
 *    &lt;vendorinfo name="jware.antunit"/&gt;
 *    &lt;vendorinfo prefix="neato." infoclass="org.neatosoft.BuildInfo"/&gt;
 *    &lt;vendorinfo name="svn4ant" fields="longversion,longdate"/&gt;
 *    &lt;vendorinfo infoclass="neatosoft.BuildInfo" fields="label,version"/&gt;
 *    &lt;vendorinfo name="log4ant" mustexist="no"/&gt;
 *    &lt;vendorinfo prefix="jsvn." name="svn4ant.jsvn" loaderref="antx.loaderref"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2008,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/

public class VendorInfoTask extends AssertableTask 
    implements AntLibFriendly, CustomLoaderEnabled, FlexExistenceEnabled
{
    /** AntXtra's build information (which created/stored in
        <em>final</em> product archive). **/
    private static final String ANTX_BI= AntX.ANTX_PACKAGE_PREFIX+".BuildInfo";


    /**
     * Loads the default list of known name-to-info class mappings.
     **/
    private static final Properties DEFAULT_KNOWN_MAPPINGS;
    static {
        Properties list = null;
        URL url = VendorInfoTask.class.getResource("vendors.properties");
        if (url!=null) {
            try {
                list = InputFileLoader.loadProperties(url,null);
            } catch(Exception iox) {/*burp*/}
        }
        if (list==null) {
            SystemFixture.puterr("WARNG:",AntX.uistrs().get("vendorinfo.noini"));
            list = new Properties();
            list.setProperty("none",EmptyBuildstrs.class.getName());
            list.setProperty("antxtras",ANTX_BI);
            list.setProperty("antx",ANTX_BI);
        }
        DEFAULT_KNOWN_MAPPINGS= list;
        list= null;
    }



    /**
     * Initializes a new vendorinfo task.
     **/
    public VendorInfoTask()
    {
        super(AntX.nopackage);
    }



    /**
     * Initializes a new, enclosed vendorinfo task.
     * @param iam CV-label (non-null)
     **/
    public VendorInfoTask(String iam)
    {
        super(iam);
    }



    /**
     * Sets a default short hand name for this task. This name is
     * used if neither a name nor an info class is specified. This
     * name defaults to <span class="src">antxtras</span>" if not
     * set.
     * @param defaultName default (known) short hand name (non-null)
     **/
    protected final void setDefaultVendor(String defaultName)
    {
        require_(defaultName!=null,"setDfltName- nonzro name");
        m_defaultVendorName = defaultName;
    }


    /**
     * Returns this task's default vendor name if one not specified
     * explicitly. Defaults to <span class="src">antxtras</span>".
     * @since JWare/AntXtras 2.0.0
     **/
    protected final String getDefaultVendor()
    {
        return m_defaultVendorName;
    }


// ---------------------------------------------------------------------------------------
// Public-facing Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets the vendor's name using a symbolic short hand name.
     * @param name the (known) short hand name (non-null)
     * @throws BuildException if the info class has already been set
     **/
    public void setName(String name)
    {
        require_(name!=null,"setName- nonzro vendor name");
        if (m_infoClass!=null || m_infoClassName!=null) {
            String error = uistrs().get(Errs.TOOOA,"infoclass","name");
            log(error, Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
        m_vendorName = name;
    }



    /**
     * Returns the vendor's short hand name if known. Returns
     * <i>null</i> if never set.
     **/
    public String getVendor()
    {
        return m_vendorName;
    }



    /**
     * Sets the vendor's buildstrs class by fully qualified classname. The
     * named class must implement the standard JWare <span class="src">Buildstrs</span>
     * interface.
     * @param  infoClass the fully qualified classname to use (non-null)
     * @throws BuildException if the short hand name has already been set
     **/
    public void setInfoClass(String infoClass)
    {
        require_(infoClass!=null,"setInfoClaz- nonzro classname");
        if (m_vendorName!=null) {
            String error = uistrs().get(Errs.TOOOA,"infoclass","name");
            log(error, Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
        m_infoClassName = infoClass;
    }



    /**
     * Returns the vendor's buildstrs class if known. Will return
     * <i>null</i> if never set and this task has not been executed
     * at least once.
     **/
    public Class getInfoClass()
    {
        return m_infoClass;
    }



    /**
     * Tells this task that it should signal an error if it is
     * unable to either locate or create the vendor's build
     * information.
     * @param must <i>false</i> to let task ignore missing info
     **/
    public void setMustExist(boolean must)
    {
        m_mustExist = must;
    }



    /**
     * Returns <i>true</i> if this task will signal an error if it
     * cannot locate or create the vendor's information. Defaults
     * to <i>true</i> if never set explicitly.
     **/
    public boolean getMustExist()
    {
        return m_mustExist;
    }


    /**
     * Sets a custom property prefix for all of the interned vendor
     * info properties. If undefined each property is prefixed with
     * a standard marker like "<span class="src">vendor.build.</span>".
     * @param prefix the prefix string (non-null)
     **/
    public void setPrefix(String prefix)
    {
        require_(prefix!=null,"setPrefix- nonzro prefix");
        m_customPrefix = prefix;
    }



    /**
     * Returns the custom string this task will use with all of
     * the interned info properties. Will return <i>null</i> if
     * never set explicitly.
     **/
    public String getPrefix()
    {
        return m_customPrefix;
    }



    /**
     * Returns the string that <em>will</em> be used to prefix all
     * of the interned vendor info properties. This method returns
     * a standard prefix if you have not set the prefix explicitly.
     **/
    public String getFinalPrefix()
    {
        if (getPrefix()!=null) {
            String prefix = getPrefix();
            if (!prefix.endsWith(".")) {
                prefix += ".";
            }
            return prefix;
        }
        String vendorname = "vendor";//generic info
        if (getVendor()!=null) {
            vendorname = getVendor();
        } else if (m_infoClassName==null) {
            vendorname = getDefaultVendor();
        }
        return vendorname+".build.";
    }



    /**
     * Tells this task to intern only the info fields described by
     * the comma-delimited list. See this class's static fields
     * for the set of field name choices.
     * @param fieldnames comma-delimited list of names (non-null)
     **/
    public void setFields(String fieldnames)
    {
        require_(fieldnames!=null,"setFields- nonzro list");
        m_fieldsList = Tk.lowercaseFrom(fieldnames);
    }



    /**
     * Returns the list of fields this task will intern. Returns
     * <i>null</i> if this list never set explicitly.
     **/
    public String getFieldsList()
    {
        return m_fieldsList;
    }

// ---------------------------------------------------------------------------------------
// Extracting information from (Arbitrary) Buildstrs:
// ---------------------------------------------------------------------------------------

    public static final String LABEL="label";
    public static final String VERSION="version";
    public static final String LONGVERSION="longversion";
    public static final String DATE="date";
    public static final String LONGDATE="longdate";
    public static final String PLATFORM="platform";
    public static final String HOST="host";


    /**
     * Returns the collection of known short hand names to FQ
     * class names. Never returns <i>null</i>; subclasses can add to
     * this default list.
     **/
    protected Properties getKnownVendors()
    {
        return m_knownVendors;
    }



    /**
     * Tries to load a named class using this task's custom classloader
     * if possible. Will use the null-proxy class if unable to load class
     * and this task's haltiferror option is disabled.
     * @param classname the name of the class to load (non-null)
     * @return the loaded Buildstrs class or the placeholder
     **/
    private Class loadInfoClass(String classname)
    {
        Class claz=null;
        ClassLoader cl = getClass().getClassLoader();
        if (m_CLspi!=null) {
            cl = m_CLspi.getClassLoader();
        }
        try {
            if (cl!=null) {
                claz = Class.forName(classname,true,cl);
            } else {
                claz = Class.forName(classname);
            }
            if (!Buildstrs.class.isAssignableFrom(claz)) {
                throw new ClassCastException(uistrs().get
                        ("task.bad.custimpl.class1",classname,"Buildstrs"));
            }
        } catch(Exception loadX) {
            String issue = uistrs().get("vendorinfo.cant.makeinfo",classname);
            if (getMustExist()) {
                log(issue, Project.MSG_ERR);
                throw new BuildException(issue, loadX, getLocation());
            }
            log(issue, Project.MSG_WARN);
            claz = EmptyBuildstrs.class;
        }
        return claz;
    }



    /**
     * Tries to load a vendor specific version properties file from a
     * resource named '<span class="src">&lt;vendor&gt;-version&#46;properties</span>'
     * where &lt;vendor&gt; is value set as this task's vendor name.
     * @param vendorname name supplied to this task (non-null)
     * @return <i>true</i> if was able to load version properties file.
     * @since JWare/AntXtras 2.0.0
     **/
    private boolean loadInfoProperties(String vendorname)
    {
        boolean found=false;
        ClassLoader cl = getClass().getClassLoader();
        if (m_CLspi!=null) {
            cl = m_CLspi.getClassLoader();
        }
        try {
            String resource = vendorname+"-version.properties";
            URL url = null;
            if (cl!=null) {
                url = cl.getResource(resource);
            } else {
                url = LocalTk.getSystemResource(resource,getProject());
            }
            if (url!=null) {
                Properties p = InputFileLoader.loadProperties(url,null);
                m_buildinfo = new PropertiesBasedBuildInfo(p);
                found = true;
            }
        } catch(Exception loadX) {
            log(loadX.getMessage(),Project.MSG_VERBOSE);
        }
        return found;
    }



    /**
     * Determines which <span class="src">Buildstrs</em> implementation
     * class this task will use. The class is determined once; subsequent
     * calls reuse this class reference.
     * @.sideeffect Updates this task's underlying info class reference
     *              if a symbolic vendor-name was specified.
     * @see #getKnownVendors
     **/
    private void determineBuildInfoClass()
    {
        if (m_infoClass==null) {
            if (m_infoClassName!=null) {
                m_infoClass = loadInfoClass(m_infoClassName);
            } else {
                final String requestedname = getVendor();
                String vendorname = requestedname;
                if (vendorname==null) {
                    vendorname = getDefaultVendor();
                }
                String classname = getKnownVendors().getProperty(vendorname);
                if (classname!=null) {
                    m_infoClass = loadInfoClass(classname);
                } 
                else 
                if (requestedname==null || !loadInfoProperties(requestedname)) {
                    String error = uistrs().get("vendorinfo.nomatch.name", vendorname);
                    if (getMustExist()) {
                        log(error, Project.MSG_ERR);
                        throw new BuildException(error,getLocation());
                    }
                    log(error, Project.MSG_WARN);
                    m_infoClass = EmptyBuildstrs.class;
                }
            }
        }
    }



    /**
     * Returns the <span class="src">Buildstrs</span> this task uses
     * to extract vendor information. Never returns <i>null</i> but
     * can return a placeholder if unable to load/create the named
     * vendor's information (and {@linkplain #getMustExist mustExist}
     * option is <i>false</i>).
     * @.impl Expects this task's infoClass already determined.
     **/
    final Buildstrs getBuildInfo()
    {
        if (m_buildinfo==null) {
            determineBuildInfoClass();
            if (m_buildinfo==null) {
                try {
                    m_buildinfo = (Buildstrs)m_infoClass.newInstance();
                } catch(Exception newX) {
                    String error = uistrs().get("vendorinfo.cant.makeinfo",
                                                m_infoClass.getName());
                    if (getMustExist()) {
                        log(error, Project.MSG_ERR);
                        throw new BuildException(error,newX,getLocation());
                    }
                    log(error, Project.MSG_WARN);
                    m_buildinfo = EmptyBuildstrs.INSTANCE;
                }
            }
        }
        return m_buildinfo;
    }



    /**
     * Sets the appropriate field property in this task's project.
     **/
    private void setInfoProperty(String name, String value)
    {
        name = getFinalPrefix()+name;
        checkIfProperty_(name,true);
        getProject().setNewProperty(name,value);
    }



    /**
     * Copies all build information fields to properties.
     **/
    private void putAllProperties(Buildstrs info)
    {
        setInfoProperty(LABEL,info.getDisplayName());
        setInfoProperty(VERSION,info.getVersion());
        setInfoProperty(LONGVERSION,info.getBuildVersion());
        setInfoProperty(DATE,info.getAbbrDate());
        setInfoProperty(LONGDATE,info.getLongDate());
        setInfoProperty(PLATFORM,info.getOS());
        setInfoProperty(HOST,info.getHostID());
    }



    /**
     * Extracts the symbolically named field's value. Returns
     * <i>null</i> if field name not recognized.
     **/
    final String getFieldValue(Buildstrs info, String f)
    {
        String value = null;
        switch (f.charAt(0)) {
            case 'v': {
                if (VERSION.equals(f)) {
                    value = info.getVersion();
                } break;
            }
            case 'd': {
                if (DATE.equals(f)) {
                    value = info.getAbbrDate();
                } break;
            }
            case 'l': {
                if (LABEL.equals(f)) {
                    value = info.getDisplayName();
                } else if (LONGVERSION.equals(f)) {
                    value = info.getBuildVersion();
                } else if (LONGDATE.equals(f)) {
                    value = info.getLongDate();
                } break;
            }
            case 'p': {
                if (PLATFORM.equals(f)) {
                    value = info.getOS();
                } break;
            }
            case 'h': {
                if (HOST.equals(f)) {
                    value = info.getHostID();
                } break;
            }
        }
        return value;
    }



    /**
     * Copies a subset of build information to properties.
     **/
    private void putTheseProperties(Buildstrs info, String filterlist)
    {
        List l= LocalTk.splitList(filterlist,getProject());
        if (!l.isEmpty()) {
            for (int i=0,N=l.size();i<N;i++) {
                String f = l.get(i).toString();
                String value = getFieldValue(info,f);
                if (value!=null) {
                    setInfoProperty(f,value);
                } else {
                    String warning = uistrs().get("vendorinfo.bad.field",f);
                    log(warning,Project.MSG_WARN);
                }
            }
        }
        l=null;
    }



    /**
     * Copies the named vendor's build information into a set of
     * project properties.
     **/
    public void execute()
    {
        verifyCanExecute_("exec");

        Buildstrs info = getBuildInfo();

        if (m_fieldsList==null) {
            putAllProperties(info);
        } else {
            putTheseProperties(info,m_fieldsList);
        }
    }


//  ---------------------------------------------------------------------------------------
//  Loading provider class using custom class loader:
//  ---------------------------------------------------------------------------------------

    /**
     * Returns this task's custom classpath. Returns <i>null</i> if
     * never created.
     * @since JWare/AntX 0.6
     **/
    public final Path getClassPath()
    {
        if (m_CLspi!=null) {
            return m_CLspi.getClasspath();
        }
        return null;
    }


    /**
     * Adds a new classpath by-reference to this task's custom
     * classpath.
     * @param r reference to existing classpath item (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setClassPathRef(Reference r)
    {
        require_(r!=null,"setClzpathRef- nonzro ref");
        getCLSpi().setClasspathref(r);
    }


    /**
     * Tells this task to use an existing classloader to
     * search for and load provider class. If loader does not exist,
     * and this task has a custom class path, a new class loader
     * will be stored under this reference's id.
     * @param r reference to an existing ClassLoader (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setLoaderRef(Reference r)
    {
        require_(r!=null,"setLodrRef- nonzro ref");
        getCLSpi().setLoaderRef(r);
    }


    /**
     * Returns this task's own loader identifier based on
     * its <em>current</em> configuration. Returns <i>null</i>
     * if never defined (directly or indirectly through a classpath
     * reference).
     * @since JWare/AntX 0.6
     **/
    public String getLoaderRefId()
    {
        if (m_CLspi!=null) {
            return m_CLspi.getClassLoadId();
        }
        return null;
    }


    /**
     * Returns this task's custom class path helper. Never returns <i>null</i>.
     * @.safety single
     * @since JWare/AntX 0.6
     **/
    private final ClasspathUtils.Delegate getCLSpi()
    {
        if (m_CLspi==null) {
            m_CLspi= ClasspathUtils.getDelegate(this);
        }
        return m_CLspi;
    }


    private boolean m_mustExist=true;
    private String m_vendorName;
    private Class m_infoClass;
    private String m_infoClassName;
    private String m_customPrefix, m_fieldsList;
    private Buildstrs m_buildinfo;
    private String m_defaultVendorName="antxtras";
    private Properties m_knownVendors= new Properties(DEFAULT_KNOWN_MAPPINGS);
    private ClasspathUtils.Delegate m_CLspi;//NB:lazy-inited
}

/* end-of-VendorInfoTask.java */
