/**
 * $Id: ThrownErrorShortcuts.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  org.apache.tools.ant.BuildException;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.flowcontrol.wrap.ThrownErrors;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Collection of short funcuts all related to extracting information
 * about a captured exception (typically via &lt;iferror&gt; processing).
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,infra,helper
 * @see       ThrownErrors
 * @since     JWare/AntXtras 3.5.0 all funcuts will unmask to original
 *            cause if the "?unmask" option is given
 **/

public final class ThrownErrorShortcuts
{
    /**
     * Starting implementation for our shortcuts. Common behavior.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    private abstract static class InnerFuncut implements FunctionShortcut 
    {
        protected InnerFuncut() {
            super();
        }

        public String getDefaultValue(String fullUri, Requester clnt)
        {
            return "";
        }

        abstract String valueFrom(Throwable cause, boolean unmasked, Requester clnt);

        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            boolean unmask  = false;
            Throwable cause = ThrownErrors.getLast();
            if (cause!=null) {
                unmask = "unmask".equalsIgnoreCase(uriFragment);
                if (unmask) {
                    cause = unmasked(cause);
                }
                s = valueFrom(cause,unmask,clnt);
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }

        Throwable unmasked(Throwable original)
        {
            Throwable unmasked = original;
            if (BuildException.class.isInstance(original)) {
                Throwable underlying = original.getCause();
                if (underlying!=null)
                    unmasked = unmasked(underlying);
            }
            return unmasked;
        }
    }



    /**
     * Return MESSAGE associated with the last captured exception.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class GetThrownMessage extends InnerFuncut
    {
        public String valueFrom(Throwable cause, boolean unmasked, Requester clnt)
        {
            return Tk.messageFrom(cause);
        }
    }



    /**
     * Return FULLY QUALIFIED class name of the last captured exception.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class GetThrownFullClassName extends InnerFuncut
    {
        public String valueFrom(Throwable cause, boolean unmasked, Requester clnt)
        {
            return cause.getClass().getName();
        }
    }



    /**
     * Return class LEAF name of the last captured exception.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class GetThrownLeafName extends InnerFuncut
    {
        public String valueFrom(Throwable cause, boolean unmasked, Requester clnt)
        {
            return Tk.leafNameFrom(cause.getClass());
        }
    }



    /**
     * Return class SIMPLE name of the last captured exception.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class GetThrownSimpleName extends InnerFuncut
    {
        public String valueFrom(Throwable cause, boolean unmasked, Requester clnt)
        {
            return cause.getClass().getSimpleName();
        }
    }



    /**
     * Return COMBO of FULLY QUALIFIED class name and MESSAGE of the last
     * captured exception.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class GetThrownFull extends InnerFuncut
    {
        public String valueFrom(Throwable cause, boolean unmasked, Requester clnt)
        {
            String fqn = cause.getClass().getName(); 
            String msg = cause.getMessage();
            return (Tk.isWhitespace(msg)) ? fqn : fqn+": "+msg;
        }
    }



    /**
     * Hook to load class such that we can register our extensions.
     **/
    public static void doInstall()
    {
        FixtureFunctionShortcut.addMapping("thrown", GetThrownMessage.class);
        FixtureFunctionShortcut.addMapping("thrownclass",GetThrownFullClassName.class);
        FixtureFunctionShortcut.addMapping("thrownname",GetThrownLeafName.class);
        FixtureFunctionShortcut.addMapping("thrownsclass",GetThrownSimpleName.class);
        FixtureFunctionShortcut.addMapping("thrownfull",GetThrownFull.class);
    }

    /**
     * Hook to unload our registered extensions.
     * @.impl Used for testing
     **/
    public static void doUninstall()
    {
        FixtureFunctionShortcut.delMapping("thrown");
        FixtureFunctionShortcut.delMapping("thrownclass");
        FixtureFunctionShortcut.delMapping("thrownname");
        FixtureFunctionShortcut.delMapping("thrownsclass");
        FixtureFunctionShortcut.delMapping("thrownfull");
    }
}

/* end-of-ThrownErrorShortcuts.java */
