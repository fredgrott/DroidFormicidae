/**
 * $Id: FixtureFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.InstanceFactory;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns various bits of information about the
 * current Ant and AntXtras fixtures including the current execution
 * cycle's information. The general form of the funcut URI is: 
 * <span class="src"><b>$x:</b><nobr><i>selector</i>[?option]</nobr></span>  
 * where <i>selector</i> can be one of:<ul>
 *   <li>cycle: execution cycle information query (sub-selector needed)</li>
 *   <li>project[name]: caller's project's name</li>
 *   <li>target[name]: caller's target's name</li>
 *   <li>thread: caller's thread's name</li>
 *   <li>location, file, line[number]: caller's location information</li>
 * </ul>
 * <p/>
 * <b>Example Usage:</b><pre>
 *  (1) &lt;show if="run.debug"
 *         message="SAM Baseline: ${<b>$x:</b>cycle?id}, ${<b>$x:</b>cycle?class}"/&gt;
 *         
 *  (2) &lt;target name="..."&gt;
 *         &lt;inform message="${$iso:} in ${<b>$x:</b>target}:${<b>$x:</b>location}"/&gt;
 *
 * -- To Install and Enable --
 *  &lt;managefuncuts action="install"&gt;
 *     &lt;parameter name="x"
 *           value="${ojaf}.info.FixtureFunctionShortcut"/&gt;
 *     &lt;parameter name="fixture"
 *           value="${ojaf}.info.FixtureFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @see       org.jwaresoftware.antxtras.core.Iteration#toString(String) Iteration.toString(&#8230;)
 **/

public final class FixtureFunctionShortcut extends FunctionShortcutSkeleton
{
    private static InstanceFactory m_IF= new InstanceFactory();
    static {
        m_IF.put("file",RequesterShortcuts.GetFileName.class);
        m_IF.put("line",RequesterShortcuts.GetFileLine.class);
        m_IF.put("linenumber",RequesterShortcuts.GetFileLine.class);
        m_IF.put("location",RequesterShortcuts.GetFileLocation.class);
        m_IF.put("project",RequesterShortcuts.GetProjectName.class);
        m_IF.put("projectname",RequesterShortcuts.GetProjectName.class);
        m_IF.put("target",RequesterShortcuts.GetTargetName.class);
        m_IF.put("targetname",RequesterShortcuts.GetTargetName.class);
        m_IF.put("targetlocation",RequesterShortcuts.GetTargetLocation.class);
        m_IF.put("thread",RequesterShortcuts.GetThreadName.class);
    }



    /**
     * Initializes a new fixture function shortcut instance.
     **/
    public FixtureFunctionShortcut()
    {
        super();
    }



    /**
     * Programmatic extension point that allows others to add
     * own fixture item names and implementation classes.
     * @param name fixture element name (non-null)
     * @param claz {@linkplain FunctionShortcut} implementation class (non-null)
     * @throws ClassCastException if <span class="src">claz</span> is not
     *  assign-compatible with {@linkplain FunctionShortcut}.
     **/
    public static void addMapping(String name, Class claz)
    {
        AntX.require_(name!=null && claz!=null,
                AntX.funcuts+"Fixture:", "addMapin- nonzro args");

        if (!FunctionShortcut.class.isAssignableFrom(claz)) {
            throw new ClassCastException(claz.getName());
        }
        synchronized(m_IF) {
            m_IF.put(name,claz);
        }
    }


    /**
     * For testing purposes. Removes a previously installed mapping.
     * @param name fixture element name (non-null)
     * @.impl for testing only
     */
    static final void delMapping(String name)
    {
        synchronized(m_IF) {
            m_IF.remove(name);
        }
    }



    /**
     * Looks for one of known selectors and returns appropriate
     * information. Execution cycle "cycle" sub-selectors 
     * include: classname, id, funcut names, etc.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String pick = uriFragment;
        String args = "";
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            args = uriFragment.substring(i+SCHEME_DELIMITER_LEN);
            pick = uriFragment.substring(0,i);
        }
        String r = null;
        Object c = m_IF.newInstance(pick);
        if (c instanceof FunctionShortcut) {
            FunctionShortcut inner = (FunctionShortcut)c;
            if (clnt.getProject()!=null) {
                clnt.getProject().setProjectReference(inner);
            }
            r = inner.valueFrom(args, uriFragment, clnt);
        } else if ("cycle".equals(pick)) {
            Iteration iteration = Iteration.get();
            r = iteration.toString(args);
        }
        return r!=null ? r : getDefaultValue(fullUri,clnt);
    }
}

/* end-of-FixtureFunctionShortcut.java */