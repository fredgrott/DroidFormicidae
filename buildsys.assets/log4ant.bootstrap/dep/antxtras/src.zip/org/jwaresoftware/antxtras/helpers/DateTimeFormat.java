/**
 * $Id: DateTimeFormat.java 597 2009-02-09 00:15:39Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.text.FieldPosition;
import  java.text.Format;
import  java.text.SimpleDateFormat;
import  java.util.Date;
import  java.util.TimeZone;

/**
 * Helper for formatting time/dates in standard package format. Generated strings are
 * Locale-specific.
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;1997-2002,2004,2007-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded
 * @.group   impl,helper
 **/

public final class DateTimeFormat
{
    private DateTimeFormat() {/*prevent*/}

    /** Abbrev date/time format (not safe for concurrent use). **/
    public static final SimpleDateFormat ABBREV = new SimpleDateFormat("dd-MMM h:mm a");

    /** Abbrev date/time format (not safe for concurrent use). Safe for use in filesystem item name.
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat ABBREV_STRICT = new SimpleDateFormat("dd-MMM hh-mm-a");

    /** Abbrev date format (not safe for concurrent use). Safe for use in filesystem item name. **/
    public static final SimpleDateFormat ABBREV_DATE = new SimpleDateFormat("dd-MMM");

    /** Abbrev time format (not safe for concurrent use).
     *  @since JWare/AntX 0.5
     **/
    public static final SimpleDateFormat ABBREV_TIME = new SimpleDateFormat("h:mm a");

    /** Standard date/time format (not safe for concurrent use). **/
    public static final SimpleDateFormat STANDARD = new SimpleDateFormat("h:mm:ss a dd-MMM-yyyy");

    /** Standard date/time format (not safe for concurrent use). Safe for use in filesystem item name.
     *  @since JWare/AntXtras 2.0.0 
     **/
    public static final SimpleDateFormat STANDARD_STRICT = new SimpleDateFormat("hh-mm-ss-a dd-MMM-yyyy");

    /** Standard date format (not safe for concurrent use). Safe for use in filesystem item name. **/
    public static final SimpleDateFormat STANDARD_DATE = new SimpleDateFormat("dd-MMM-yyyy");

    /** Standard time format (not safe for concurrent use).
     *  @since JWare/AntX 0.5
     **/
    public static final SimpleDateFormat STANDARD_TIME = new SimpleDateFormat("h:mm:ss a");

    /** Standard time format (not safe for concurrent use). Safe for use in filesystem item name.
     *  @since JWare/AntX 2.0.0
     **/
    public static final SimpleDateFormat STANDARD_TIME_STRICT = new SimpleDateFormat("hh-mm-ss-a");

    /** Standard date format for CVS changelog. Safe for use in filesystem item name. 
     *  @since JWare/AntX 0.5
     **/
    public static final SimpleDateFormat CHANGELOG = new SimpleDateFormat("dd MMM yyyy");

    /** Standard date format for SVN changelog. NOT filesystem name safe. 
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat SVNLOG = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZ' ('EE', 'dd MMM yyyy')'");

    /** ISO8601 formatter for date-time with time zone. Not safe for concurrent use.
     *  @since JWare/AntX 0.9
     **/
    public static final SimpleDateFormat ISO = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    /** ISO8601 formatter for date-time with time zone but no milliseconds. Not safe for concurrent use.
     *  Safe for use as file or directory name in file system.
     *  @since JWare/AntX 0.9
     **/
    public static final SimpleDateFormat ISO_STRICT = new SimpleDateFormat("yyyyMMdd'T'HHmmssZZ");

    /** ISO8601-based formatter for date-time with time zone and milliseconds. 
     *  Not safe for concurrent use. Safe for use as file or directory name in file system.
     *  Example string: '20010704T120856&#46;235-0700'
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat ISO_MILLIS_STRICT = new SimpleDateFormat("yyyyMMdd'T'HHmmss.SSSZZ");

    /** ISO8601 formatter for time with time zone but no milliseconds. Not safe for concurrent use.
     *  Safe for use as file or directory name in file system.
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat ISO_TIME_STRICT = new SimpleDateFormat("HHmmssZZ");

    /** ISO8601 formatter for time with time zone and milliseconds. Not safe for concurrent use.
     *  Safe for use as file or directory name in file system.
     *  Example string: '120856&#46;235-0700'
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat ISO_TIME_MILLIS_STRICT = new SimpleDateFormat("HHmmss.SSSZZ");

    /** ISO8601 formatter for date. Not safe for concurrent use.
     *  Safe for use as file or directory name in file system.
     *  @since JWare/AntXtras 2.0.0
     **/
    public static final SimpleDateFormat ISO_DATE_STRICT = new SimpleDateFormat("yyyyMMddZZ");

    /** GMT-based date/time format (not safe for concurrent use). **/
    public static final SimpleDateFormat GMT = new SimpleDateFormat("k:mm:ss dd-MMM-yyyy 'GMT'");

    /** GMT-based date format (not safe for concurrent use). Safe for use in filesystem item name. **/
    public static final SimpleDateFormat GMT_DATE = new SimpleDateFormat("dd-MMM-yyyy 'GMT'");

    /** GMT-based time format (not safe for concurrent use). **/
    public static final SimpleDateFormat GMT_TIME = new SimpleDateFormat("k:mm:ss 'GMT'");

    static {
        TimeZone gmtz = TimeZone.getTimeZone("GMT");
        GMT.setTimeZone(gmtz);
        GMT_DATE.setTimeZone(gmtz);
        GMT_TIME.setTimeZone(gmtz);
    }


    /** Converts timestamp into new formatted string; protected against
        concurrent use.
        @param tm the timestamp to be formatted
        @param dfmt the date, time, duration formatter to use (non-null)
        @throws IllegalArgumentException if formatter is null.
        @since JWare/AntX 0.5
     **/
    public static String format(long tm, Format dfmt) {
        if (dfmt==null) {
            throw new IllegalArgumentException();
        }
        synchronized(dfmt) {
            sm_adhoc.setTime(tm);
            return dfmt.format(sm_adhoc);
        }
    }


    /** Converts timestamp into new standard formatted string; protected against
        concurrent use. **/
    public static String format(long tm) {
        synchronized(STANDARD) {
            sm_standard.setTime(tm);
            return STANDARD.format(sm_standard);
        }
    }

    /** Updates existing buffer with timestamp as standard formatted string;
        protected against concurrent use. **/
    public static StringBuffer format(long tm, StringBuffer sb) {
        synchronized(STANDARD) {
            sm_standard.setTime(tm);
            return STANDARD.format(sm_standard,sb,new FieldPosition(0));
        }
    }

    /** Converts timestamp into new abbreviated formatted string; protected
        against concurrent use. **/
    public static String shortformat(long tm) {
        synchronized(ABBREV) {
            sm_abbrev.setTime(tm);
            return ABBREV.format(sm_abbrev);
        }
    }

    /** Updates existing buffer with timestamp as abbreviated formatted string;
        protected against concurrent use. **/
    public static StringBuffer shortformat(long tm, StringBuffer sb) {
        synchronized(ABBREV) {
            sm_abbrev.setTime(tm);
            return ABBREV.format(sm_abbrev,sb,new FieldPosition(0));
        }
    }

    /** Converts timestamp into new GMT formatted string; protected
        against concurrent use. **/
    public static String GMTformat(long tm) {
        synchronized(GMT) {
            sm_GMT.setTime(tm);
            return GMT.format(sm_GMT);
        }
    }

    /** Updates existing buffer with timestamp as GMT formatted string;
        protected against concurrent use. **/
    public static StringBuffer GMTformat(long tm, StringBuffer sb) {
        synchronized(GMT) {
            sm_GMT.setTime(tm);
            return GMT.format(sm_GMT,sb,new FieldPosition(0));
        }
    }

    /** Converts timestamp into new ISO formatted datetime string; protected
        against concurrent use.
        @since JWare/AntX 0.9 **/
    public static String ISOformat(long tm) {
        synchronized(ISO) {
            sm_ISO.setTime(tm);
            return ISO.format(sm_ISO);
        }
    }

    /** Converts timestamp into new ISO strict formatted datetime string;
        protected against concurrent use.
        @since JWare/AntX 0.9 **/
    public static String ISOstrictformat(long tm) {
        synchronized(ISO) {
            sm_ISO.setTime(tm);
            return ISO_STRICT.format(sm_ISO);
        }
    }

    /** Converts timestamp into new ISO millis strict formatted datetime 
        string; protected against concurrent use. Includes milliseconds.
        @since JWare/AntXtras 2.0.0 **/
    public static String ISOmillistrictformat(long tm) {
        synchronized(ISO) {
            sm_ISO.setTime(tm);
            return ISO_MILLIS_STRICT.format(sm_ISO);
        }
    }

    /** Updates existing buffer with date as abbreviated formatted string;
        protected against concurrent use.
        @since JWare/AntX 0.4
     **/
    public static StringBuffer shortdate(long tm, StringBuffer sb) {
        synchronized(ABBREV_DATE) {
            Date dt = new Date(tm);
            return ABBREV_DATE.format(dt,sb,new FieldPosition(0));
        }
    }

    /** Converts timestamp into new short date formatted string; protected
        against concurrent use.
        @since JWare/AntX 0.4
     **/
    public static String shortdate(long tm) {
        synchronized(ABBREV_DATE) {
            Date dt = new Date(tm);
            return ABBREV_DATE.format(dt);
        }
    }


    private static final Date sm_abbrev   = new Date();
    private static final Date sm_standard = new Date();
    private static final Date sm_GMT      = new Date();
    private static final Date sm_ISO      = new Date();
    private static final Date sm_adhoc    = new Date();


    public static final void main(String[] argv) {
        long tm = System.currentTimeMillis();
        if (argv.length==1) {
            tm = Long.parseLong(argv[0]);
        }
        System.out.println("NOW(msecs): "+tm);
        System.out.println("ABBREV:  "+format(tm,ABBREV));
        System.out.println("ABBREV_STRICT:  "+format(tm,ABBREV_STRICT));
        System.out.println("ABBREV_DATE:  "+format(tm,ABBREV_DATE));
        System.out.println("ABBREV_TIME:  "+format(tm,ABBREV_TIME));
        System.out.println("CHANGELOG:  "+format(tm,CHANGELOG));
        System.out.println("SVNLOG:  "+format(tm,SVNLOG));
        System.out.println("GMT:  "+format(tm,GMT));
        System.out.println("GMT_DATE:  "+format(tm,GMT_DATE));
        System.out.println("GMT_TIME:  "+format(tm,GMT_TIME));
        System.out.println("ISO:  "+format(tm,ISO));
        System.out.println("ISO_DATE_STRICT:  "+format(tm,ISO_DATE_STRICT));
        System.out.println("ISO_STRICT:  "+format(tm,ISO_STRICT));
        System.out.println("ISO_MILLIS_STRICT:  "+format(tm,ISO_MILLIS_STRICT));
        System.out.println("ISO_TIME_STRICT:  "+format(tm,ISO_TIME_STRICT));
        System.out.println("ISO_TIME_MILLIS_STRICT:  "+format(tm,ISO_TIME_MILLIS_STRICT));
        System.out.println("STANDARD:  "+format(tm,STANDARD));
        System.out.println("STANDARD_STRICT:  "+format(tm,STANDARD_STRICT));
        System.out.println("STANDARD_DATE:  "+format(tm,STANDARD_DATE));
        System.out.println("STANDARD_TIME:  "+format(tm,STANDARD_TIME));
        System.out.println("STANDARD_TIME_STRICT:  "+format(tm,STANDARD_TIME_STRICT));        
    }
}

/* end-of-DateTimeFormat.java */
