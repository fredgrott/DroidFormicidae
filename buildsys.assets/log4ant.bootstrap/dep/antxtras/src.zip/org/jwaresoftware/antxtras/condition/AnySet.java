/**
 * $Id: AnySet.java 610 2009-02-15 00:21:26Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  java.util.Iterator;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.Handling;

/**
 * Shortcut condition that returns <i>true</i> if at least one of the nested items is
 * set in the project's environment. Empty sets always evaluate <i>false</i>.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;tally&gt;
 *     &lt;available classname="junit.framework.Assert" property="junit.present"/&gt;
 *     &lt;available classname="com.idaremedia.pet.PET" property="pet.present"/&gt;
 *     &lt;<b>isanyset</b> trueproperty="run.tests.enable"&gt;
 *       &lt;property name="junit.present/&gt;
 *       &lt;property name="pet.present/&gt;
 *     &lt;/isanyset&gt;
 *   &lt;/tally&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 * @see      AllSet
 * @see      NoneSet
 **/

public class AnySet extends CheckSetCondition implements URIable
{
    /**
     * Initializes new AnySet condition. Will return <i>false</i>
     * if evaluated and still empty.
     **/
    public AnySet()
    {
        super(AntX.rules+"anyset");
    }



    /**
     * Initializes a filled-in AnySet instance.
     * @param properties comma-delimited list of properties (non-null)
     * @param P condition's project
     **/
    public AnySet(String properties,Project P)
    {
        super(AntX.rules+"anyset",properties,P);
    }



    /**
     * Returns <i>true</i> if any of the condition's items are
     * defined.
     **/
    public boolean eval()
    {
        verifyInProject_("eval");

        final Project P = getProject();
        boolean istrue = false;//=> empty=failure, noneset=failure

        if (!getIncludes().isEmpty()) {

            boolean ignoreWS = ignoreWhitespace();
            boolean iffTrue  = isTruesOnly();
            boolean checkUnresolved = getMalformedHandling()==Handling.REJECT;
            Iterator itr = getIncludesIterator();

            while (itr.hasNext()) {
                FlexString xv = (FlexString)itr.next();
                String v = null;

                if (xv.isProperty() && checkUnresolved) {
                    if (LocalPropertyExaminer.verifyProperty(P, xv)) {
                        v = xv.getValue(P);
                    }
                } else {
                    v = xv.getValue(P);
                }
                if (v!=null) {
                    if (ignoreWS && Tk.isWhitespace(v)) {
                        v = null;
                    } else if (iffTrue && Tk.string2PosBool(v)!=Boolean.TRUE) {
                        v = null;
                    }
                }
                if (v!=null) {
                    istrue=true;
                    break;
                }
            }
        }

        if (istrue && getUpdateProperty()!=null) {
            String what = Strings.TRUE;
            if (isUpdateVariable()) {
                Variables.set(getUpdateProperty(),what);
            } else {
                getProject().setNewProperty(getUpdateProperty(),what);
            }
        }

        return istrue;
    }



    /**
     * Sets this condition's list of properties as part of
     * a value URI.
     * @param fragment the value uri bits (non-null)
     * @since JWare/AntX 0.5
     */
    public void xsetFromURI(String fragment)
    {
        xsetFromURIFragment(fragment);
    }
}

/* end-of-AnySet.java */
