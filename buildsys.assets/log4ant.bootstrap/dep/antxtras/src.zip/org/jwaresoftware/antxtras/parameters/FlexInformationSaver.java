/**
 * $Id: FlexInformationSaver.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that can write captured string-based
 * information to various sinks. This interface is an extension of the base
 * saver API that allows derived string-based information to be stored to
 * project properties directly.  The item must support the standard
 * '<span class="src">toproperty=propertyname</span>' short-hand parameter.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,helper
 **/

public interface FlexInformationSaver extends InformationSaver
{
    /**
     * Sets the property to which information should be copied.
     * @param property the property to create (non-null)
     **/
    void setToProperty(String property);


    /**
     * Returns the name of the property this item will set with
     * the captured information. Can return <i>null</i> if never
     * set explicitly.
     * @see #setToProperty setToProperty
     **/
    String getToProperty();
}

/* end-of-FlexInformationSaver.java */
