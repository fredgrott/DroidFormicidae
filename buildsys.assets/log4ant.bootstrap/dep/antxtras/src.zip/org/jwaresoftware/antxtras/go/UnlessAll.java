/**
 * $Id: UnlessAll.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;

/**
 * Implementation of the general <i>unlessAll</i> and <i>unlessAllTrue</i> tests
 * for all conditional components. The <span class="src">UnlessAll</span> criteria
 * passes if at least one of the named properties in a list does <em>not</em> exist
 * within a specified project.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern GoF.Strategy
 * @see      Go
 * @see      Unless
 * @see      IffAll
 **/

public final class UnlessAll
{
    /**
     * Returns <i>true</i> if at least one of the named does not
     * exist in given project.
     * @param list delimited list of property names
     * @param P project from which properties read
     * @param onlyIfTrue <i>true</i> if each property only counts if
     *        it is a valid positive boolean string
     **/
    public static boolean pass(String list, Project P, boolean onlyIfTrue)
    {
        if (Tk.isWhitespace(list)) {
            return false;
        }
        List l= LocalTk.splitList(list,P);
        Iterator itr= l.iterator();

        while (itr.hasNext()) {
            if (Unless.allowed(itr.next().toString(),P,onlyIfTrue)) {
                return true; //=> missin at least one!
            }
        }
        return false;// => all there so NOT ok!
    }


    /**
     * Prevent; only helpers public.
     **/
    private UnlessAll() {
    }
}

/* end-of-UnlessAll.java */
