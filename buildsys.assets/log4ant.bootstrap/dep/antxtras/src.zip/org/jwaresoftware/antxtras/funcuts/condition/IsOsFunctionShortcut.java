/**
 * $Id: IsOsFunctionShortcut.java 594 2009-02-08 18:43:15Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.go.IffOs;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that checks the runtime OS for a match against a 
 * script-supplied value and returns either "true" or "false. This
 * funcut is atually a shortcut for the standard Ant 
 * <span class="src">&lt;os&gt;</span> condition. The general
 * format of the URI is:
 * <span class="src">$isOS:[family|*],[name|*],[arch|*],[version|*]</span>. 
 * Note that the query should contain at least one specific field 
 * selector.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;do false="${$isOs:windows}"&gt;
 *      <i>[chmod +x...]</i>
 *    &lt;/do&gt;
 * 
 * <b>2)</b> &lt;domatch value="${<b>$isOS:</b>windows}"&gt;
 *      &lt;true&gt;&#8230;
 *        <i>[windows setup]</i>
 *      &lt;otherwise&gt;&#8230;
 *        <i>[linux setup]</i>
 *    &lt;/domatch&gt;
 *
 * <b>3)</b> -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="isOS"
 *           value="${ojaf}.condition.IsOsFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.6
 * @author    ssmc, &copy;2005-2006,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class IsOsFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new is-OS function shortcut.
     **/
    public IsOsFunctionShortcut()
    {
        super();
    }


    /**
     * Uses {@linkplain IffOs} to determine whether runtime operating
     * system matches incoming uri fragment. Returns "true" or "false"
     * strings.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String query = Tk.resolveString(clnt.getProject(),uriFragment,true);
        boolean matches = IffOs.pass(query,clnt.getProject(),false);
        return String.valueOf(matches);
    }
}

/* end-of-IsOsFunctionShortcut.java */
