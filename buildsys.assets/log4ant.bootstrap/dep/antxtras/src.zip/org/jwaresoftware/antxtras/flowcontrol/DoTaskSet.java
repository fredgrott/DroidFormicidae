/**
 * $Id: DoTaskSet.java 1516 2012-09-25 01:50:00Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol;

import  org.apache.tools.ant.AntTypeDefinition;
import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.ComponentHelper;
import  org.apache.tools.ant.DynamicAttributeNS;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.condition.ConditionFunctionShortcuts;
import  org.jwaresoftware.antxtras.condition.URIable;
import  org.jwaresoftware.antxtras.condition.URIableGoTestAdapter;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.FlexConditional;
import  org.jwaresoftware.antxtras.rules.RulesTk;
import  org.jwaresoftware.antxtras.starters.ConditionalTaskSet;

/**
 * Taskset that has builtin support for conditional execution. Implements
 * basic support for both the standard '<i>if</i>' and '<i>unless</i>' control
 * options as well as several other AntXtras-specific variants like 
 * '<i>ifAll</i>', '<i>ifOs</i>', '<i>true</i>', '<i>false</i>', and 
 * '<i>ifAnt</i>'. Also supports the Ant &lt;locals&gt; scoping mechanism. 
 * See the {@linkplain FlexConditional} interface for the complete list 
 * of supported execution conditions.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;do test="some-condition-id"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 *
 *    &lt;do ifAntLike=".*\1\.6.*"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 *
 *    &lt;do ifAllTrue="a,b,c" unless="no-alpabet"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 *
 *    &lt;do isdirectory="${localconf.d}"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2002-2005,2008,2010-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,infra
 **/

public class DoTaskSet extends ConditionalTaskSet
    implements FlexConditional, DynamicAttributeNS
{
    /**
     * Initializes a new empty do taskset.
     **/
    public DoTaskSet()
    {
        this(AntX.flowcontrol+"DoTaskSet:");
    }


    /**
     * Initializes a new CV-labeled empty do taskset.
     * @param iam CV-label (non-null)
     **/
    protected DoTaskSet(String iam)
    {
        super(iam);
        setWithLocals(true);
    }



    /**
     * Adds the if-condition-is-true to this taskset.
     * A property value is considered <i>true</i> if it
     * is one of: "true","on", or "yes".
     **/
    public void setIfTrue(String property)
    {
        m_guard.setIfTrue(property);
    }

    public void setTrue(String booleanString)
    {
        m_guard.setTrue(booleanString);
    }

    public void setFalse(String booleanString)
    {
        m_guard.setFalse(booleanString);
    }


    public void setIfAll(String properties)
    {
        m_guard.setIfAll(properties);
    }

    public void setIfAllTrue(String properties)
    {
        m_guard.setIfAllTrue(properties);
    }

    public void setIfOS(String choice)
    {
        m_guard.setIfOS(choice);
    }

    public void setIfAntLike(String version)
    {
        m_guard.setIfAntLike(version);
    }



    /**
     * Adds the unless-condition-is-true to this taskset.
     * A property value is considered <i>true</i> if it is
     * one of: "true", "on", or "yes".
     **/
    public final void setUnlessTrue(String property)
    {
        m_guard.setUnlessTrue(property);
    }


    public void setUnlessAll(String properties)
    {
        m_guard.setUnlessAll(properties);
    }

    public void setUnlessAllTrue(String properties)
    {
        m_guard.setUnlessAllTrue(properties);
    }

    public void setUnlessOS(String choice)
    {
        m_guard.setUnlessOS(choice);
    }

    public void setUnlessAntLike(String version)
    {
        m_guard.setUnlessAntLike(version);
    }


    /**
     * Assigns this taskset a named condition execution guard. If the
     * referenced condition evaluates <i>true</i> this taskset's
     * contents will be performed.
     * @param testRef reference to test definition (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setCriteria(Reference testRef)
    {
        require_(testRef!=null,"setTest: nonzro test refid");
        m_conditionId = testRef;
    }



    /**
     * Synonym for {@linkplain #setCriteria(Reference) setCriteria}.
     * @param testRef reference to test definition (non-null)
     * @since JWare/AntX 0.5
     **/
    public final void setTest(Reference testRef)
    {
        setCriteria(testRef);
    }



    /**
     * Adds a disabled check to this conditional task's if conditions.
     * @param uri fixture option to check (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setDisabled(String uri)
    {
        require_(uri!=null,"setDisabled- nonzro uri");
        m_guard.addIfTest(new IfDisabled(uri));
    }



    /**
     * Adds an arbitrary appication-defined condition shorthand to this
     * taskset. The name of the parameter can be the typedef'd name of
     * a condition or a recognized condition funcut name. Works very similar
     * to the assert task's dynamic attribute support except with the 
     * addition of condition funcut support!
     * @param uri [optional] linked namespace uri (empty = Ant namespace)
     * @param name condition or funcut name (no namespace)
     * @param qName qualified name (with namespace if present), non-blank
     * @param value URIable condition's URI fragment (non-null)
     * @since JWare/AntXtras 3.5.0
     * @throws BuildException if attribute's name is not a valid URIable condition.
     * @throws IllegalArgumentException if the 'test' attribute also defined
     **/
    public void setDynamicAttribute(String uri, String name, String qName, String value)
    {
        require_(name!=null && value!=null, "set- nonzro dynamic condition");

        boolean ok = false;
        Project P = getProject();
        String err = null;//non-null if should barf!

        if (m_conditionId!=null) {
            err = Errs.OneOrOtherAttribute("test", "{dynamic-condition}");
        } else {
            AntTypeDefinition td = ComponentHelper.getComponentHelper(P).getDefinition(qName);
            if (td!=null) {
                Class cls = td.getExposedClass(P);
                if (cls!=null && URIable.class.isAssignableFrom(cls)) {
                    URIable c = (URIable)td.create(P);
                    m_guard.addIfTest(new URIableGoTestAdapter(name,value,c));
                    ok = true;
                }
            }
            if (!ok && Tk.isWhitespace(uri)) {
                URIable c = ConditionFunctionShortcuts.newTest(name,value,m_rqlink);
                if (c!=null) {
                    m_guard.addIfTest(new URIableGoTestAdapter(name,value,c));
                    ok = true;
                }
            }
            if (!ok)
                err = Errs.UnsupportedAttribute(getTaskName(),qName);
        }
        if (!ok) {
            log(err,Project.MSG_ERR);
            throw new BuildException(err,getLocation());
        }
    }



    /**
     * Returns <i>true</i> if either this taskset's named condition test
     * passes or all of its individual if tests pass.
     * @return <i>true</i> if all execution conditions met
     * @since JWare/AntX 0.5
     **/
    public boolean testIfCondition()
    {
        if (m_conditionId!=null) {
            String testId = m_conditionId.getRefId();
            boolean passIf = true;
            if (!RulesTk.evalTest(testId, m_rqlink)) {
                m_guard.setLastFailure("$test:"+testId);
                passIf = false;
            }
            log("Conditional execution (test="+testId+") is "+passIf, Project.MSG_DEBUG);
            return passIf;
        }
        return super.testIfCondition();
    }



    /**
     * Ensures that for conditional execution either a single named
     * condition has been defined or a combination of if/unless options.
     * @throws BuildException if a test condition has been named well
     *   as other if/unless conditions.
     * @throws BuildExceptionif a referred-to test object is not a
     *   valid condition object.
     * @since JWare/AntX 0.5
     */
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (m_conditionId!=null) {
            if (!m_guard.isEmpty()) {
                String e = getAntXMsg("flow.only.test.param",m_conditionId.getRefId());
                log(e, Project.MSG_ERR);
                throw new BuildException(e, getLocation());
            }
            RulesTk.verifyTest(m_conditionId.getRefId(), m_rqlink);
        }
    }



    private Requester m_rqlink = new Requester.ForComponent(this);
    private Reference m_conditionId;
}

/* end-of-DoTaskSet.java */
