/**
 * $Id: HardLimitEnabled.java 430 2008-04-27 15:27:03Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol;

/**
 * Interface to any flow control component that supports the standard
 * '<span class="src">maxloops=N</span>' and '<span class="src">haltifmax[yes|no]</span>'
 * parameters.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   n/a
 * @.group    api,helper
 **/

public interface HardLimitEnabled
{
    /**
     * Gives this flow control task a hard limit to the
     * number of times it can execute. This attribute serves mostly
     * as an error handling mechanism to prevent infinite loops.
     **/
    void setMaxLoops(int maxLoops);



    /**
     * Tells this tasks whether to fail if the hard limit is
     * reached. Ignored if this flow control task does not have a
     * hard limit.
     * @see #setMaxLoops setMaxLoops(LIMIT)
     **/
    void setHaltIfMax(boolean halt);
}

/* end-of-HardLimitEnabled.java */