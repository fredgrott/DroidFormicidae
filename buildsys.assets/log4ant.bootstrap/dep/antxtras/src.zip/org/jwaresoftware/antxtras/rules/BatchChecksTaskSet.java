/**
 * $Id: BatchChecksTaskSet.java 1373 2012-07-27 11:33:08Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.BuildAssertionException;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.TaskHandle;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.starters.TaskSet;

/**
 * Aggregating taskset that always executes each of its nested assertions and/or fixture
 * checks tasks even if one or more of them fail. Once all checks have been performed,
 * this taskset will propagate a wrapper assertion exception if at least one check failed.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;<b>batchchecks</b> failproperty="..."&gt;
 *       &lt;fixturecheck isset="module_basedir" message="..."/&gt;
 *       &lt;assert allset="module_id,module_name" whitespace="reject" message="..."&gt;
 *    &lt;/batchchecks&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,infra
 * @see       AssertTask
 * @see       FixtureCheckTask
 **/

public final class BatchChecksTaskSet extends TaskSet implements Condition, AntLibFriendly
{
    /**
     * Initializes a new batch checks taskset.
     **/
    public BatchChecksTaskSet()
    {
        super(AntX.conditions+"BatchChecks:");
    }



    /**
     * Sets name of the property set if this batchcheck fails.
     * @param property the property to update (non-null, non-whitespace)
     **/
    public final void setFailProperty(String property)
    {
        require_(!Tk.isWhitespace(property),"setfailp- nonwspc");
        m_failProperty = property;
    }


    /**
     * Returns the property updated if this assertion fails. Returns
     * default property-name if this attribute never set.
     **/
    public final String getFailProperty()
    {
        return m_failProperty;
    }


    /**
     * Sets an inlined message to be displayed if rule fails (typically)
     * or has something to say.
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setMessage(String msg)
    {
        m_defaultMsg = msg;
    }



    /**
     * Returns this task's loaded message (if messageid used)
     * or inlined default message. Returns <i>null</i> if no message
     * or message id ever set.
     * @since JWare/AntXtras 2.0.0
     */
    public final String getOverrideMsg()
    {
        String msg = m_defaultMsg;
        if (getMessageId()!=null) {// asof AntXtras 3.0.0
            msg = getMsg();
        }
        return msg;
    }



    /**
     * Returns <i>true</i> if candidate task is a boolean rule.
     * @param taskH the task to be nested (as handle)
     **/
    protected boolean includeTask(TaskHandle taskH)
    {
        Class c = TaskExaminer.trueClass(taskH.getTask());
        return c!=null && BooleanRule.class.isAssignableFrom(c);
    }



    /**
     * Runs each nested assertion or fixture check task in order
     * capturing any thrown signals until all checks have been done
     * @throws BuildException if any nested check does.
     **/
    protected void performNestedTasks() throws BuildException
    {
        Task[] tasks = getTasks();
        int signals = 0;
        for (int i=0;i<tasks.length;i++) {
            try {
                tasks[i].perform();
            } catch(RuntimeException rtX) {
                signals++;
                if (!(rtX instanceof BuildAssertionException)) {//make sure it's seen!
                    log(rtX.getMessage(), Project.MSG_ERR);
                }
            }
        }
        if (signals>0) {
            String what = String.valueOf(signals);
            String msg = getAntXMsg("brul.batch.asserts.failed",what);
            String ownmsg = getOverrideMsg();
            if (!Tk.isWhitespace(ownmsg)) {
                msg = ownmsg;
            }
            if (m_failProperty!=null) {
                checkIfProperty_(m_failProperty,true);
                getProject().setNewProperty(m_failProperty, what);
                log("BatchCheck false; setting failure property "+m_failProperty+
                    " to "+what, Project.MSG_DEBUG);
                if (msg==ownmsg) {
                    log(ownmsg,Project.MSG_WARN);
                }
            } else {
                log(msg, Project.MSG_WARN);
            }
            throw new BuildAssertionException(msg,getLocation());
        }
    }


    /**
     * Executes this collection of checks. Will always return
     * <i>true</i> if all assertions pass; otherwise an assertion
     * exception is always signaled (nothing returned).
     * @throws BuildException if any nested check does.
     **/
    public boolean eval()
    {
        execute();
        return true;
    }


    private String m_failProperty;//NB:null => none!
    private String m_defaultMsg;//NB:fallback inlined message
}

/* end-of-BatchChecksTaskSet.java */