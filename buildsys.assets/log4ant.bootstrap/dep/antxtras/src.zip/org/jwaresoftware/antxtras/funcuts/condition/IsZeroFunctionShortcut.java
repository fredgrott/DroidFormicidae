/**
 * $Id: IsZeroFunctionShortcut.java 582 2009-02-07 17:27:56Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns "true" if the incoming source 
 * value is "0". Useful for testing the initial boundary value of a 
 * loop cursor when creating compound strings. An empty fragment
 * returns "false".
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;doforeach i="i" in="0,10"&gt;
 *      &lt;do false="${<b>$iszero:</b>${i}}"&gt;
 *        &#8230;
 *    &lt;/doforeach&gt;
 *
 * <b>2)</b>&lt;properties id="localedits" file="${conf.d}/local.properties"/&gt;
 *   &lt;do false="${<b>$iszero:</b>${$map:localedits?size}}"&gt;
 *     &#8230;
 *   &lt;/do&gt;
 *
 * <b>3)</b>-- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="iszero"
 *           value="${ojaf}.condition.IsZeroFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class IsZeroFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new iszero function shortcut.
     **/
    public IsZeroFunctionShortcut()
    {
        super();
    }


    /**
     * Returns <span class="src">true</span> iff the incoming fragment
     * resolves to the value "0".
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String value = Tk.resolveString(clnt.getProject(),uriFragment,true);
        return String.valueOf("0".equals(value));
    }
}

/* end-of-IsZeroFunctionShortcut.java */