/**
 * $Id: ShortenFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.strings;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that tries to shorten a long string in a display friendly manner.
 * This handler is very useful for shortening long file paths into something easily
 * readable in build archive logs. The general form of the URI:
 * <span class="src"><nobr>$shorten:string[?[maxlength][,,[left|right][,,ellipses string]]]</nobr>
 * </span>.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;emit:show messageid="msg.generating.apidocs" 
 *        arg0="<b>${$shorten:</b>@{html}}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="shorten"
 *             value="${ojaf}.strings.ShortenFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class ShortenFunctionShortcut extends FunctionShortcutSkeleton
{
    static final int LEFT=0;
    static final int RIGHT=LEFT+1;
    private static final String DDD="...";

    /**
     * Default trim length for shortened strings ({@value}).
     */
    public static final int MAXLEN= 41;

    /**
     * Default minimum length for shortened strings (<i>3</i>).
     */
    public static final int MINLEN= DDD.length();


    /**
     * Initializes a new shorten string function shortcut handler.
     **/
    public ShortenFunctionShortcut()
    {
        super();
    }


    /**
     * Tries to shorten the incoming string as requested. If string does
     * not need shortening it is returned unchanged (property references
     * are resolved).
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();
        int maxlength = MAXLEN;
        String ellipses= DDD;
        int dropped = LEFT;
        String longstring = uriFragment;
        final int urilen= uriFragment.length();

        int i = longstring.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            longstring = longstring.substring(0,i);
            i += SCHEME_DELIMITER_LEN;
            if (i<urilen) {
                String s;
                int j = uriFragment.indexOf(PARAMS_DELIMITER,i);
                if (j>=0) {
                    s = Tk.resolveString(P,uriFragment.substring(i,j),true);
                    maxlength = Tk.integerFrom(s,MAXLEN);

                    i = uriFragment.indexOf(PARAMS_DELIMITER,j+PARAMS_DELIMITER_LEN);
                    if (i<0) {
                        s = uriFragment.substring(j+PARAMS_DELIMITER_LEN);
                        dropped = leftOrRight(s,LEFT,P);
                    } else {
                        s = uriFragment.substring(j+PARAMS_DELIMITER_LEN,i);
                        dropped = leftOrRight(s,LEFT,P);
                        i += PARAMS_DELIMITER_LEN;
                        if (i<urilen) {
                            s = uriFragment.substring(i);
                            ellipses = Tk.resolveString(P,s,true);
                        }
                    }
                } else {
                    s = Tk.resolveString(P,uriFragment.substring(i),true);
                    maxlength = Tk.integerFrom(s,MAXLEN);
                }
            }
        }
        if (maxlength<MINLEN) {
            maxlength=MINLEN;
        }
        longstring = Tk.resolveString(P,longstring,true);
        final int strlen = longstring.length();
        if (strlen>maxlength) {
            switch (dropped) {
                case LEFT: {
                    int from = strlen-maxlength+ellipses.length();
                    if (from>=strlen) {
                        from = strlen-maxlength+DDD.length();
                        ellipses = DDD;
                    }
                    longstring= ellipses+longstring.substring(from);
                    break;
                }
                default: {
                    int to = maxlength-ellipses.length();
                    if (to<=0) {
                        to = maxlength-DDD.length();
                        ellipses = DDD;
                    }
                    longstring = longstring.substring(0,to)+ellipses;
                    break;
                }
            }
        }
        return longstring;
    }


    static int leftOrRight(String s, int dflt, Project P)
    {
        s = Tk.resolveString(P,s,true);
        s = s.toLowerCase();

        if ("left".equals(s)) {
            return LEFT;
        }
        if ("right".equals(s)) {
            return RIGHT;
        }
        return dflt;
    }
}


/* end-of-ShortenFunctionShortcut.java */