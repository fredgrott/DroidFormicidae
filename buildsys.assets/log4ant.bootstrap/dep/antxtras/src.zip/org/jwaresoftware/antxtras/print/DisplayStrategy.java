/**
 * $Id: DisplayStrategy.java 414 2008-04-22 01:26:19Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.IOException;
import  java.io.OutputStream;

import  org.apache.tools.ant.BuildException;

/**
 * A strategy to display an Ant object's state as readable text.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,helper
 **/

public interface DisplayStrategy
{
    /**
     * Prints the given <i>thing</i> to an output stream.
     * @param information information to be displayed (non-null)
     * @param out the output stream (non-null, might be a buffered stream)
     * @throws IOException if any I/O problems occur
     * @throws BuildException if any other error occurs
     **/
    void print(DisplayRequest information, OutputStream out)
        throws IOException, BuildException;
}

/* end-of-DisplayStrategy.java */
