/**
 * $Id: ConditionalInnerNameValuePair.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.parameters.Conditional;

/**
 * Simple key-value parameter helper that supports optional inclusion
 * using standard if/unless parameter mechanism.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 **/

public class ConditionalInnerNameValuePair extends InnerNameValuePair
    implements Conditional
{
    /**
     * Initializes a new blank inner name/value pair.
     **/
    public ConditionalInnerNameValuePair()
    {
        super();
    }


    /**
     * Initializes new predefined pair.
     **/
    public ConditionalInnerNameValuePair(String name, String value)
    {
        super(name,value);
    }



    /**
     * Sets this parameter's 'if' constraint.
     * @param property name of guard property (non-null)
     **/
    public void setIf(String property)
    {
        m_ifProperty = property;
    }


    /**
     * Returns this parameter's 'if' constraint or <i>null</i>
     * if none set explicitly.
     **/
    public String getIfProperty()
    {
        return m_ifProperty;
    }


    /**
     * Sets this parameter's 'unless' constraint.
     * @param property name of guard property (non-null)
     **/
    public void setUnless(String property)
    {
        m_unProperty = property;
    }


    /**
     * Returns this parameter's 'unless' constraint or <i>null</i>
     * if none set explicitly.
     **/
    public String getUnlessProperty()
    {
        return m_unProperty;
    }


    private String m_ifProperty, m_unProperty;
}

/* end-of-ConditionalInnerNameValuePair.java */