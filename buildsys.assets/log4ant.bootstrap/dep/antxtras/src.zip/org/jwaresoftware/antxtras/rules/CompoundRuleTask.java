/**
 * $Id: CompoundRuleTask.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.taskdefs.Available;
import  org.apache.tools.ant.taskdefs.UpToDate;
import  org.apache.tools.ant.taskdefs.condition.*;

import  org.jwaresoftware.antxtras.condition.AllSet;
import  org.jwaresoftware.antxtras.condition.AllSetTrue;
import  org.jwaresoftware.antxtras.condition.AnySet;
import  org.jwaresoftware.antxtras.condition.AnySetTrue;
import  org.jwaresoftware.antxtras.condition.FileNotEmpty;
import  org.jwaresoftware.antxtras.condition.IsAntVersion;
import  org.jwaresoftware.antxtras.condition.IsBoolean;
import  org.jwaresoftware.antxtras.condition.IsClass;
import  org.jwaresoftware.antxtras.condition.IsDirectory;
import  org.jwaresoftware.antxtras.condition.IsFile;
import  org.jwaresoftware.antxtras.condition.IsNotSet;
import  org.jwaresoftware.antxtras.condition.IsNotWhitespace;
import  org.jwaresoftware.antxtras.condition.IsNumber;
import  org.jwaresoftware.antxtras.condition.IsReference;
import  org.jwaresoftware.antxtras.condition.IsResource;
import  org.jwaresoftware.antxtras.condition.IsSetTrue;
import  org.jwaresoftware.antxtras.condition.IsMatch;
import  org.jwaresoftware.antxtras.condition.NoneSet;
import  org.jwaresoftware.antxtras.condition.StringEquals;

/**
 * Adds several Condition compatible nested elements to a generic RuleTask. Basically
 * a big ol' cut-n-paste from ConditionBase's source ;-) with the additional
 * AntX conditions thrown in. Although, as of Ant 1.6 with its introduction of
 * {@linkplain FreeformRule}, it is no longer necessary to update this task with all
 * nestable conditions, it's still a good idea to do. By explicitly including a nested
 * element handler we allow script writers to use our conditions without having to
 * declare them manually.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public abstract class CompoundRuleTask extends RuleTask
{
    /**
     * Initializes a new CV-labeled CompoundRuleTask instance.
     * @param iam CV-label (non-null)
     **/
    protected CompoundRuleTask(String iam)
    {
        super(iam);
    }


    /**
     * Initializes a new CompoundRuleTask subclass with custom
     * embedded setting.
     * @param iam CV-label
     * @param embed <i>true</i> if embedded
     **/
    protected CompoundRuleTask(String iam, boolean embed)
    {
        super(iam,embed);
    }


// ---------------------------------------------------------------------------------------
// Conditions that match standard Ant 'condition':
// ---------------------------------------------------------------------------------------

    /**
     * Adds a &lt;not&gt; condition container to this rule.
     **/
    public void addNot(Not n)
    {
        xaddCondition(n);
    }


    /**
     * Adds an &lt;and&gt; condition container to this rule.
     **/
    public void addAnd(And a)
    {
        xaddCondition(a);
    }


    /**
     * Adds an &lt;or&gt; condition container to this rule.
     **/
    public void addOr(Or o)
    {
        xaddCondition(o);
    }


    /**
     * Adds an &lt;available&gt; condition to this rule.
     **/
    public void addAvailable(Available a)
    {
        xaddCondition(a);
    }


    /**
     * Adds an &lt;uptodate&gt; condition to this rule.
     **/
    public void addUpToDate(UpToDate u)
    {
        xaddCondition(u);
    }


    /**
     * Adds a &lt;contains&gt; condition to this rule.
     **/
    public void addContains(Contains match)
    {
        xaddCondition(match);
    }


    /**
     * Adds an &lt;istrue&gt; condition to this rule.
     **/
    public void addIsTrue(IsTrue isT)
    {
        xaddCondition(isT);
    }


    /**
     * Adds an &lt;isfalse&gt; condition to this rule.
     **/
    public void addIsFalse(IsFalse isF)
    {
        xaddCondition(isF);
    }


    /**
     * Adds an &lt;os&gt; condition to this rule.
     **/
    public void addOS(Os os)
    {
        xaddCondition(os);
    }


    /**
     * Synonym for adding &lt;http&gt; that better
     * reflects its purpose. We keep in addition to isalive
     * as the http condition has some attributes specific
     * to that protocol.
     **/
    public void addHTTPAlive(Http h)
    {
        xaddCondition(h);
    }


    /**
     * Adds a &lt;reachable&gt; condition to this rule.
     * Same as general &lt;isreachable&gt; condition.
     * @since JWare/AntXtras 3.0.0
     * @since JWare/AntXtras 3.5.0 renamed from [isalive]
     **/
    public void addReachable(IsReachable h)
    {
        xaddCondition(h);
    }


    /**
     * Adds an &lt;typefound&gt; condition to this rule.
     * @since JWare/AntXtras 3.5.0
     **/
    public void addTypeFound(TypeFound a)
    {
        xaddCondition(a);
    }


// ---------------------------------------------------------------------------------------
// AntX extended conditons:
// ---------------------------------------------------------------------------------------

    /**
     * Adds an &lt;isnotwhitespace&gt; condition to this rule.
     **/
    public void addIsNotWhitespace(IsNotWhitespace ws)
    {
        xaddCondition(ws);
    }


    /**
     * Adds an &lt;isboolean&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public void addIsBoolean(IsBoolean isb)
    {
        xaddCondition(isb);
    }


    /**
     * Adds an &lt;isnumber&gt; condition to this rule.
     * @since JWare/AntXtras 2.0.0
     **/
    public void addIsNumber(IsNumber isN)
    {
        xaddCondition(isN);
    }


    /**
     * Adds an &lt;isclass&gt; condition to this rule.
     **/
    public void addIsClass(IsClass isClz)
    {
        xaddCondition(isClz);
    }


    /**
     * Adds an &lt;isresource&gt; condition to this rule.
     **/
    public void addIsResource(IsResource isR)
    {
        xaddCondition(isR);
    }


    /**
     * Adds an &lt;isdirectory&gt; condition to this rule.
     * @since JWare/AntX 0.5
     **/
    public void addIsDirectory(IsDirectory isD)
    {
        xaddCondition(isD);
    }


    /**
     * Adds an &lt;isdir&gt; alias condition to this rule.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void addIsDir(IsDirectory isD)
    {
        addIsDirectory(isD);
    }


    /**
     * Adds an &lt;isfile&gt; condition to this rule.
     * @since JWare/AntXtras 2.0.0
     **/
    public void addIsFile(IsFile isFile)
    {
        xaddCondition(isFile);
    }


    /**
     * Adds an &lt;isreference&gt; condition to this rule.
     **/
    public void addIsReference(IsReference isR)
    {
        xaddCondition(isR);
    }


    /**
     * Adds an &lt;isref&gt; alias condition to this rule.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void addIsRef(IsReference isR)
    {
        addIsReference(isR);
    }


    /**
     * Adds a &lt;isset&gt; condition to this rule.
     **/
    public void addIsSet(org.jwaresoftware.antxtras.condition.IsSet iss)
    {
        xaddCondition(iss);
    }


    /**
     * Adds a &lt;isdeclared&gt; condition to this rule.
     * @since JWare/AntXtras 3.5.0
     **/
    public void addIsDeclared(org.jwaresoftware.antxtras.condition.IsSet iss)
    {
        xaddCondition(iss);
    }


    /**
     * Adds a &lt;issettrue&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public void addIsSetTrue(IsSetTrue ist)
    {
        xaddCondition(ist);
    }


    /**
     * Adds a &lt;isnotset&gt; condition to this rule.
     **/
    public void addIsNotSet(IsNotSet ins)
    {
        xaddCondition(ins);
    }


    /**
     * Adds an &lt;allset&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public final void addAllSet(AllSet allset)
    {
        xaddCondition(allset);
    }


    /**
     * Adds an &lt;allsettrue&gt; condition to this rule.
     * @since JWare/AntX 0.5
     **/
    public final void addAllSetTrue(AllSetTrue allset)
    {
        xaddCondition(allset);
    }


    /**
     * Adds a &lt;noneset&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public final void addNoneSet(NoneSet noneset)
    {
        xaddCondition(noneset);
    }


    /**
     * Adds an &lt;anyset&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public final void addAnySet(AnySet anyset)
    {
        xaddCondition(anyset);
    }


    /**
     * Adds an &lt;anysettrue&gt; condition to this rule.
     * @since JWare/AntX 0.5
     **/
    public final void addAnySetTrue(AnySetTrue anyset)
    {
        xaddCondition(anyset);
    }


    /**
     * Adds a &lt;filenotempty&gt; condition to this rule.
     * @since JWare/AntX 0.2
     **/
    public void addFileNotEmpty(FileNotEmpty fne)
    {
        xaddCondition(fne);
    }


    /**
     * Adds an &lt;equals&gt; condition to this rule.
     * @since JWare/AntX 0.3 (converted to AntX StringEquals)
     **/
    public void addEquals(StringEquals e)
    {
        xaddCondition(e);
    }


    /**
     * Adds an &lt;ismatch&gt; condition to this rule.
     * @since JWare/AntX 0.3
     **/
    public void addIsMatch(IsMatch mc)
    {
        xaddCondition(mc);
    }



    /**
     * Adds an &lt;isantversion&gt; condition to this rule.
     * @since JWare/AntXtras 3.0.0
     **/
    public void addIsAntVersion(IsAntVersion vc)
    {
        xaddCondition(vc);
    }
}

/* end-of-CompoundRuleTask.java */
