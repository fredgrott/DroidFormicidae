/**
 * $Id: Parameters.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.types;

import  java.io.File;
import  java.io.IOException;
import  java.io.InputStream;
import  java.net.URL;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureComponent;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.GenericParameters;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.ownhelpers.ReferenceHandle;
import  org.jwaresoftware.antxtras.parameters.FlexSourceSupport;
import  org.jwaresoftware.antxtras.starters.ListFriendly;

/**
 * List of string name-value pairs that can be used as source for loop iteration,
 * macro arguments, overlays, function shortcuts, etc. When printed as a string a 
 * parameters' pairs are separated by a semi-colon string (;) unless
 * its <span class="src">delim</span> parameter has been set. A Parameters 
 * is the standard AntXtras bean for {@linkplain GenericParameters} or
 * <span class="src">Properties</span>. HOWEVER, a Parameters is <em>not</em>
 * purely a Properties object; its keys are always normalized lowercased US-locale
 * to match the effect of Ant's own parameter normalization algorithm unless
 * you set the 'normalize=off' parameter.
 * <p>
 * <b>Example Usage:</b><pre>
 * [1]
 *    &lt;<b>parameters</b> id="javadoc.options"&gt;
 *       &lt;parameter name="visibility" value="package"/&gt;
 *       &lt;parameter name="maintitle" value="My API Documentation"/&gt;
 *       &lt;parameter name="copyleft" value="(c) 2004 Me, Myself, and I."/&gt;
 *       ...
 *    &lt;/parameters&gt;
 *    ...
 *    &lt;macrodef name="apidocs"&gt;
 *       &lt;attribute name="args"/&gt;
 *       &lt;sequential&gt;
 *          &lt;javadoc
 *               access="${$property:@{args}->visibility}"
 *               windowtitle="${$property:@{args}->maintitle}"
 *               .../&gt;
 *    ...
 *    &lt;apidocs args="javadoc.options"/&gt;
 * 
 *  [2]
 *     &lt;<b>parameters</b> id="myconf" normalize="off" 
 *          file="${conf.d}/run.properties"/&gt;  
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 * @see       org.jwaresoftware.antxtras.types.PropertiesList
 **/

public final class Parameters extends GenericParameters
    implements ListFriendly, FlexSourceSupport, FixtureComponent, AntLibFriendly
{
    private static final String IAM_= AntX.fixture+"Parameters:";


    /** Default delimiter used by all parameter sets. **/
    public static final String DEFAULT_DELIMITER = AntX.DEFAULT_DELIMITER;



    /**
     * Initializes a new empty parameters set.
     **/
    public Parameters()
    {
    }



    /**
     * Initializes a new empty parameters set associated
     * with project.
     * @param project this object's enclosing project
     **/
    public Parameters(Project project)
    {
        setProject(project);
    }



    /**
     * Capture our identifier for feedback since types don't
     * always get correct location information.
     * @param id our identifier (via build script)
     **/
    public void setId(String id)
    {
        m_Id= id;
    }



    /**
     * Tries to return an unique identifier for this set.
     **/
    public String getId()
    {
        return m_Id;
    }



    /**
     * Sets a custom delimiter for this parameters set. This
     * delimiter will be used by all stringification(TM) methods.
     * @param delimiter new delimiter (non-null)
     **/
    public void setDelim(String delimiter)
    {
        AntX.require_(delimiter!=null,IAM_,"setDelim- nonzro delim");
        m_delim = delimiter;
    }



    /**
     * Returns the delimiter this set will use for all
     * stringification(TM). Never returns <i>null</i>. Will return
     * whatever the current default is for the "pairs" delimiter.
     **/
    public String getDelim()
    {
        String delim = m_delim;
        if (delim==null) {
            delim = Iteration.defaultdefaults().delimiter(getProject(),"pairs",false,null);
        }
        return delim;
    }



    /**
     * Shorthand for setting this set to a set of project properties.
     * @param delimitedNames comma-delimited set of property names
     * @since JWare/AntXtras 3.0.0
     **/
    public void setProperties(String delimitedNames)
    {
        AntX.require_(delimitedNames!=null,IAM_,"setProperties- nonzro names");
        final Project myProject = getProject();
        List names = LocalTk.splitList(delimitedNames,myProject);
        for (int i=0,n=names.size();i<n;i++) {
            String propertyname = (String)names.get(i);
            String value = myProject.getProperty(propertyname);
            if (value==null) {
                value="";
            }
            put(propertyname,value);
        }
    }



    /**
     * From another properties-like object, add all unique contents
     * (no overwriting of locally defined items). The referenced
     * thing must be an object that we can translate into a standard
     * <span class="src">Properties</span> object.
     * @param other reference to other properties item (non-null)
     * @throws BuildException if reference is malformed or
     *         referred-to thing is not convertible to a Properties.
     **/
    public void addConfiguredParameters(ReferenceHandle other)
    {
        AntX.require_(other!=null,IAM_,"addProps- nonzro handle");
        Reference r = other.getRefId();
        if (r==null || r.getRefId()==null || r.getRefId().equals(m_Id)) {
            String error = Errs.ItemImproperlyDefined("parameters", "invalid 'refid'");
            log(error,Project.MSG_ERR);
            throw new BuildException(error);
        }
        boolean continu = true;
        if (other.getHaltIfMissingFlag()==Boolean.FALSE) {
            Object referredTo = getProject().getReference(r.getRefId());
            if (referredTo==null) {
                continu = false;
            }
        }
        if (continu) {
            Properties otherP = FixtureExaminer.
                getReferencedProperties(getProject(),r.getRefId(),null);
            Iterator itr = otherP.entrySet().iterator();
            while (itr.hasNext()) {
                Map.Entry kv = (Map.Entry)itr.next();
                String key = (String)kv.getKey();
                if (get(key)==null) {
                    put(key, (String)kv.getValue());
                }
            }
        }
    }



    /**
     * Returns an iterator for all stringified key-value pairs
     * in this set. Each item is a single string of form:
     * <i>key</i>=<i>value</i> where <i>value</i> can be the
     * empty string.
     * @param fromproject [optional] the context project (can be <i>null</i>)
     */
    public Iterator readonlyStringIterator(Project fromproject)
    {
        Map items = copyOfParameterObjects();
        List kvpairs = AntXFixture.newList(items.size());
        Iterator itr = items.values().iterator();
        while (itr.hasNext()) {
            InnerNameValuePair e = (InnerNameValuePair)itr.next();
            String v = e.getValue(fromproject,true);
            if (v==null) {
                kvpairs.add(""+e.getName());
            } else {
                kvpairs.add(""+e.getName()+"="+v);
            }
        }
        return kvpairs.iterator();
    }



    /**
     * Returns the string-form appropriate for this parameters object.
     * Each key-value pair is delimited by whatever the current project's
     * setting is for a "pairs" delimiter; defaults to the semi-colon.
     * @param fromproject [optional] the context project (can be <i>null</i>)
     **/
    public String stringFrom(Project fromproject)
    {
        StringBuffer sb = AntXFixture.newLargeStringBuffer();
        final String theDelimiter = getDelim();

        int N=0;
        Iterator itr= readonlyStringIterator(fromproject);

        while (itr.hasNext()) {
            if (N>0) {
                sb.append(theDelimiter);
            }
            sb.append(itr.next().toString());
            N++;
        }
        itr=null;
        return sb.substring(0);
    }



    /**
     * Adds the contents of the given resource source to this parameters.
     * The resource file must contain a standard Properties-formatted 
     * set of key-value pairs. This method acts as a no-op if the 
     * resource does not exists.
     * @param rn (subpath) name of resource (non-null)
     * @throws BuildException if unable to read resource ONCE OPENED
     **/
    public void setResource(String rn)
    {
        AntX.require_(rn!=null,IAM_,"setRez- nonzro name");

        InputStream is = LocalTk.getSystemResourceAsStream(rn, getProject());
        if (is!=null) {
            try {
                Properties values = new Properties();
                values.load(is);
                mergeOther(values);
            } catch(IOException ioX) {
                String error = Errs.CantLoadConfigSource("resource("+rn+")",ioX.getMessage());
                log(error,Project.MSG_ERR);
                throw new BuildException(error,ioX);
            }
        } else {
            String warning = Errs.CantFindInputStreamForResource(rn);
            log(warning,Project.MSG_WARN);
        }
    }



    /**
     * Adds the contents of the named Properties file to this set.
     * The contents of the file are <em>merged</em> with
     * this set's current contents, unconditionally replacing any
     * pre-existing items of same names. This method does nothing if
     * the named file does not exist.
     * @param filepath absolute path or project-relative path (non-null)
     * @throws BuildException if unable to read existing file for any reason.
     **/
    public void setFile(String filepath)
    {
        AntX.require_(filepath!=null,IAM_,"setFile- nonzro name");

        File f = getProject().resolveFile(filepath);
        if (f.canRead()) {
            try {
                URL url = AntXFixture.fileUtils().getFileURL(f);
                Properties values = InputFileLoader.loadProperties(url,null);
                mergeOther(values);
            } catch(IOException ioX) {
                String error = Errs.CantLoadConfigSource(filepath,ioX.getMessage());
                log(error,Project.MSG_ERR);
                throw new BuildException(error,ioX);
            }
        } else {
            String warning = Errs.FileNotFound(filepath);
            log(warning, Project.MSG_WARN);
        }
    }



    /**
     * Adds the contents of the named Properties URL to this set.
     * The contents of the resource are <em>merged</em> with
     * this set's current contents, unconditionally replacing any
     * pre-existing items of same names.
     * @param urlstring location of Properties file (non-null)
     * @throws BuildException if unable to load resource for any reason.
     **/
    public void setURL(String urlstring)
    {
        AntX.require_(urlstring!=null,IAM_,"setURL- nonzro URL");

        try {
            URL url = new URL(urlstring);
            Properties values = InputFileLoader.loadProperties(url,null);
            mergeOther(values);
        } catch(IOException ioX) {
            String error = Errs.CantLoadConfigSource("URL("+urlstring+")",ioX.getMessage());
            log(error,Project.MSG_ERR);
            throw new BuildException(error,ioX);
        }
    }



    /**
     * Tells this parameters object whether to normalize its keys 
     * to what Ant expects for component parameters. The default is 
     * to match Ant; however, if you're using a parameters object  
     * as a Properties replacement, you should turn off normalization
     * of keys so you match your source.
     * @param normalize <i>false</i>  to keep keys untouched
     * @since JWare/AntXtras 2.1.0
     **/
    public void setNormalize(boolean normalize)
    {
        m_asis = !normalize;
    }



    /**
     * Check to see if this set wants to preserve names as-is.
     * If yes, return original untouched; otherwise, let inherited
     * method do normalization.
     * @since JWare/AntXtras 2.1.0
     **/
    protected String nameFrom(String original)
    {
        return m_asis ? original : super.nameFrom(original);
    }



    /**
     * Sets this parameter set's source path from an embedded
     * element instead of a simple attribute. Use this method in
     * order to enforce a 'normalize=off' scenario. Because data
     * types load attributes in non-predictable order, you need
     * to use a nested element to guarantee the normalize flag 
     * is processed BEFORE the data source is loaded!
     * @param filedef file information as simple inner string (non-null)
     * @since JWare/AntXtras 2.1.0
     **/
    public void addConfiguredFile(InnerString filedef)
    {
        AntX.require_(filedef!=null,"Parameters:","addFile- nonzro file");
        setFile(filedef.toString(getProject()));
    }


    private String  m_Id = Strings.ND;
    private String  m_delim = null; //@since 3.5.0 - read from project default
    private boolean m_asis = false; //v1+v2: like-Ant => default!
}


/* end-of-Parameters.java */