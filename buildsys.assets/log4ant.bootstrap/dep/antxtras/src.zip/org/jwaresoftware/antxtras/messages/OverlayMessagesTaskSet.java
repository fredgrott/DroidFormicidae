/**
 * $Id: OverlayMessagesTaskSet.java 618 2009-02-21 15:02:31Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/
package org.jwaresoftware.antxtras.messages;

import  java.io.File;
import  java.net.URL;
import  java.text.MessageFormat;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.internal.apis.UIStringManager;
import  org.jwaresoftware.internal.uism.BundleStringManager;

import  org.jwaresoftware.antxtras.behaviors.BuildError;
import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureOverlay;
import  org.jwaresoftware.antxtras.core.UISMContext;
import  org.jwaresoftware.antxtras.starters.ConditionalTaskSet;

/**
 * Configuration taskset that adds another UIStringManager for use by nested
 * AntXtras tasks in a build iteration. The effect of an OverlayMessagesTaskSet
 * is like a logical 'or'-- if the nearest task's UIStringManager does not contain
 * the requested message, the previous UIStringManager (another configure task or a
 * root UIStringManager) is asked to find the message. This delegation continues until
 * the message is located or there are no more UIStringManagers to ask. Note that if
 * the root bundle also does not contain the message and there is an installed
 * default message bundle, that bundle will also be searched.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;target name="mainclasses" depends="workspace"&gt;
 *     &lt;assign var="starttime" value="${$isodatetime:now}"/>
 *     &lt;<b>overlaymessages</b> resource="compiling.msgs"&gt;
 *       &lt;show messageid="compile.started" arg1="${$var:starttime}"/&gt;
 *       <i>[...more components that use msgids]</i>
 *     &lt/overlaymessages&gt;
 *   &lt;/target&gt;
 *
 *   &lt;target name="programmertests" depends="testlibraries"&gt;
 *     &lt;assign var="starttime" value="${$isodatetime:now}"/>
 *     &lt;<b>overlaymessages</b> resource="testing.msgs" if="test.msgs.enabled"&gt;
 *       &lt;show messageid="programmertests.started" arg1="${$var:starttime}"/&gt;
 *       <i>[...more components that use msgids]</i>
 *     &lt/overlaymessages&gt;
 *   &lt;/target&gt;

 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded (from UIStringManager interface once configured)
 * @.group   api,infra
 **/

public class OverlayMessagesTaskSet extends ConditionalTaskSet
    implements FixtureOverlay, MessagesSource, UIStringManager
{
    /**
     * Initializes a new OverlayMessagesTaskSet instance.
     **/
    public OverlayMessagesTaskSet()
    {
        super(AntX.messages+"OverlayMessagesTaskSet:");
    }


    /**
     * Initializes a new CV-tagged OverlayMessagesTaskSet instance.
     * @param iam CV-label (non-null)
     **/
    public OverlayMessagesTaskSet(String iam)
    {
        super(iam);
    }


    /**
     * Sets this task's project; updates other underlying
     * project-components.
     **/
    public void setProject(Project P)
    {
        super.setProject(P);
        m_bundle.setProject(P);
    }


    /**
     * Sets this tasks bundle as reference to an existing
     * msgs bundle declaration.
     * @param reference referenc to bundle (non-null)
     **/
    public void setBundleId(Reference reference)
    {
        m_bundle.setRefid(reference);
    }

// ---------------------------------------------------------------------------------------
// MessagesSource implementation (inherit javadoc comments):
// ---------------------------------------------------------------------------------------

    public void setURL(String url)
    {
        m_bundle.setURL(url);
    }

    public URL getURL()
    {
        return m_bundle.getURL();
    }

    public void setFile(String filepath)
    {
        m_bundle.setFile(filepath);
    }

    public File getFile()
    {
        return m_bundle.getFile();
    }

    public void setResource(String rsrc)
    {
        m_bundle.setResource(rsrc);
    }

    public String getResource()
    {
        return m_bundle.getResource();
    }


    public void setFormat(String hint)
    {
        m_bundle.setFormat(hint);
    }

// ---------------------------------------------------------------------------------------
// Resource loading implementation (subset of CustomLoaderEnabled):
// ---------------------------------------------------------------------------------------

    /**
     * Defines a simple lookup path for this taskset's bundle
     * resource.
     * @param classpath the path to be searched (non-null)
     * @see #setClassPathRef
     **/
    public void setClassPath(Path classpath)
    {
        m_bundle.setClassPath(classpath);
    }


    /**
     * Defines a custom lookup path for this taskset's bundle
     * resource by (re)using an existing path reference.
     * @param r reference to an existing path (non-null)
     **/
    public void setClassPathRef(Reference r)
    {
        m_bundle.setClassPathRef(r);
    }



    /**
     * Returns the custom lookup path this taskset will use when
     * looking for its resource bundle. Will returns <i>null</i>
     * if lookup path has not been customized.
     **/
    public Path getClassPath()
    {
        return m_bundle.getClassPath();
    }


    /**
     * Tells this taskset to use an existing classloader when
     * searching and/or loading bundle resource.
     * @param r reference to an existing ClassLoader (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setLoaderRef(Reference r)
    {
        m_bundle.setLoaderRef(r);
    }


    /**
     * Returns the identifier of the custom classloader this taskset
     * will use to lookup its bundle resource. Returns <i>null</i>
     * if no custom class loader.
     * @since JWare/AntX 0.4
     **/
    public String getLoaderRefId()
    {
        return m_bundle.getLoaderRefId();
    }


// ---------------------------------------------------------------------------------------
// UIStringManager implementation (inherit javadoc comments):
// ---------------------------------------------------------------------------------------

    /** Used as marker for strings that aren't in my immediate bundle. **/
    private static final String NOSTR= new String("==_\\\"");//NB:unlikely legit entry


    public String mget(String id, Object[] args, String defm)
    {
        BundleStringManager uism = getThisUISM();

        String msg = uism.mget(id,args,NOSTR);

        if (NOSTR.equals(msg)) {
            if (!ignoreAllInherited() && (m_inheritedUISM!=null || !UISMContext.isDefaultUndefined())) {
                if (m_inheritedUISM!=null) {
                    msg = m_inheritedUISM.mget(id,args,defm);
                } else {
                    msg = UISMContext.getDefaultStringManager().mget(id,args,defm);
                }
            } else if (defm!=null) {
                msg = defm;
            } else {
                msg = uism.getDefaultString();
            }
        }
        return msg;
    }


    public String mget(MessageFormat mf, String id, Object[] args, String defm)
    {
        BundleStringManager uism = getThisUISM();

        String msg = uism.mget(mf,id,args,NOSTR);
        if (NOSTR.equals(msg)) {
            if (!ignoreAllInherited() && (m_inheritedUISM!=null || !UISMContext.isDefaultUndefined())) {
                if (m_inheritedUISM!=null) {
                    msg = m_inheritedUISM.mget(mf,id,args,defm);
                } else {
                    msg = UISMContext.getDefaultStringManager().mget(mf,id,args,defm);
                }
            } else if (defm!=null) {
                msg = defm;
            } else {
                msg = uism.getDefaultString();
            }
        }
        return msg;
    }


    public final String mget(String id, Object[] args)
    {
        return mget(id,args,null);
    }

    public final String get(String id)
    {
        return mget(id,(Object[])null,(String)null);
    }

    public final String dget(String id, String defm)
    {
        return mget(id,(Object[])null, defm);
    }

    public final String get(String id, Object arg1)
    {
        return mget(id, new Object[]{arg1}, null);
    }

    public final String dget(String id, Object arg1, String defm)
    {
        return mget(id, new Object[]{arg1}, defm);
    }

    public final String get(String id, Object arg1, Object arg2)
    {
        return mget(id, new Object[]{arg1,arg2}, null);
    }

    public final String dget(String id, Object arg1, Object arg2, String defm)
    {
        return mget(id, new Object[]{arg1,arg2}, defm);
    }

    public final String get(String id, Object arg1, Object arg2, Object arg3)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, null);
    }

    public final String dget(String id, Object arg1, Object arg2, Object arg3, String defm)
    {
        return mget(id, new Object[]{arg1,arg2,arg3}, defm);
    }

    public final String getDefaultString()
    {
        return getThisUISM().getDefaultString();
    }

// ---------------------------------------------------------------------------------------
// Taskset/controller management
// ---------------------------------------------------------------------------------------

    /**
     * Returns <i>true</i> if this task ignores its inherited UIStringManager
     * and returns only messages contained in its bundle. Is <i>false</i>
     * by default.
     **/
    protected final boolean ignoreAllInherited()
    {
        return m_noInherited;
    }


    /**
     * Set whether this task will use the UIStringManager hierarchy or
     * return only messages contained in its bundle.
     * @param passthru <i>false</i> if this task should ignore the
     *        the UIStringManager hierarchy.
     **/
    public void setInheritance(boolean passthru)
    {
        m_noInherited = !passthru;
    }


    /**
     * Returns this task's underlying UIStringManager. Never
     * returns <i>null</i>.
     * @.safety single
     **/
    private BundleStringManager getThisUISM()
    {
        if (m_UISM==null) {
            m_UISM = new BundleStringManager
                (m_bundle.newBundle(m_rqlink),null);
        }
        return m_UISM;
    }


    /**
     * Installs this UIStringManager as the frontmost within the current
     * thread's iteration environment before running nested tasks. When tasks
     * have finished (or failed), uninstalls self from UISM context stack.
     * @throws BuildException if inner tasks do, or we cannot install UIStringManager
     * @throws BuildError if iteration UIStringManager stack is fatally corrupted
     * @see UISMContext
     **/
    protected void performTheCheckedTasks()
        throws BuildException
    {
        synchronized(m_runlock) {
            boolean installed=false;
            try {
                m_inheritedUISM = UISMContext.installStringManager(this,m_rqlink);
                installed= true;
                getThisUISM();
                performTheTasksList();

            } finally {
                if (installed) {
                    m_inheritedUISM = null;
                    UIStringManager uism = UISMContext.getStringManager();
                    if (uism!=this) {
                        String ME= uistrs().dget("task.uism.whoami","UIStringManager");
                        String ermsg = uistrs().get("context.stack.corrupted",ME);
                        log(ermsg, Project.MSG_ERR);
                        throw new BuildError(ermsg,getLocation());
                    }
                    UISMContext.unwindStringManager(null);
                }//installed
            }
        }
    }


    private boolean m_noInherited;//NB:=>use inheritance hierarchy
    private UIStringManager m_inheritedUISM;//NB:on execution
    private MessagesBundle m_bundle= 
        new MessagesBundle(AntX.messages+"OverlayMessagesTaskSet:",false);//NB:delegatee for configuration
    private BundleStringManager m_UISM;//NB:inited on 1st use
    private Object m_runlock = new int[0];//NB:prevent nested execution
    private ProblemHandler m_rqlink = new Requester.ForComponent(this);
}

/* end-of-OverlayMessagesTaskSet.java */
