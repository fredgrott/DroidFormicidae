/**
 * $Id: MacroInstanceCaller.java 1423 2012-08-03 23:03:42Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Target;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.UnknownElement;
import  org.apache.tools.ant.taskdefs.Ant;
import  org.apache.tools.ant.taskdefs.Property;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.ProjectDependentSkeleton;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.ownhelpers.ScopedProperties;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;

/**
 * Implementation of {@linkplain TargetCaller} for local macrodefs. Without any
 * overlayed properties and/or attributes, this caller is an expensive adapter
 * of the standard macro invocation mechanism (so you really want to use it
 * only if overlaying is likely).
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2004-2005,2008,2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public final class MacroInstanceCaller extends ProjectDependentSkeleton
    implements TargetCaller, ConfigurableCaller
{
    private static final String IAM_= AntX.flowcontrol+"MacroInstanceCaller";


    /**
     * Initializes a new local macro instance caller. This
     * caller's target and project must be defined before it
     * is used.
     * @see #setCaller setCaller(&#8230;)
     **/
    public MacroInstanceCaller()
    {
    }


    /**
     * Initializes a new local macro instance caller. This
     * caller's target must be defined before it is used.
     * @param task controlling task (non-null)
     * @see #setCaller setCaller(&#8230;)
     **/
    public MacroInstanceCaller(CallerTask task)
    {
        setCaller(task);
    }



    /**
     * Initializes this caller's controlling task.
     * @param task controlling task (non-null)
     * @.sideeffect This caller's target name is initialized
     *     to the task's enclosing target's name (if exists).
     **/
    public void setCaller(Task task)
    {
        AntX.require_(task!=null,IAM_,"setCalr- nonzro task");
        Target parent = task.getOwningTarget();
        if (parent!=null) {
            setTarget(parent.getName());
        }
        setProject(task.getProject());
        m_owningTask = task;
    }



    /**
     * (Re)Sets the target macro's name for this caller.
     **/
    public void setTarget(String targetName)
    {
        m_targetName = targetName;
    }


    /**
     * Returns this caller's target macro's name.
     **/
    public String getTargetName()
    {
        return m_targetName;
    }



    /**
     * Create a new property to passthru to called macro.
     **/
    public Property createProperty()
    {
        Property p = new Property();
        p.setProject(getProject());
        if (m_plist==null) {
            m_plist = AntXFixture.newList();
        }
        m_plist.add(p);
        return p;
    }



    /**
     * Create a new property set to passthru to called macro.
     **/
    public PropertySet createPropertySet()
    {
        PropertySet p = new PropertySet();//?use just one?
        p.setProject(getProject());
        if (m_plist==null) {
            m_plist = AntXFixture.newList();
        }
        m_plist.add(p);
        return p;
    }



    /**
     * Unsupported operation; only macro parameters can be created.
     * @throws UnsupportedOperationException always.
     **/
    public Ant.Reference createReference()
    {
        throw new UnsupportedOperationException();
    }



    /**
     * Create a new macro attribute to passthru to called macro.
     **/
    public InnerNameValuePair createAttribute()
    {
        InnerNameValuePair a = new InnerNameValuePair();
        if (m_plist==null) {
            m_plist = AntXFixture.newList();
        }
        m_plist.add(a);
        return a;
    }



    /**
     * Installs all of our property declarations as a PropertyHelper
     * hook. Any macro attribute definitions are returned to be
     * given directly to macro instance factory.
     **/
    private Map installOverlay()
    {
        Project P= getProjectNoNull();
        Map attrs = null;
        if (m_plist!=null) {
            m_overlay = new ScopedProperties(P,true);
            Iterator itr= m_plist.iterator();
            while (itr.hasNext()) {
                Object o = itr.next();
                if (o instanceof InnerNameValuePair) {
                    InnerNameValuePair nv = (InnerNameValuePair)o;
                    nv.verifyNamed();
                    if (attrs==null) {
                        attrs = AntXFixture.newMap();
                    }
                    attrs.put(nv.getName(), nv.getValue(P,true));
                }
                else if (o instanceof Property) {
                    m_overlay.put((Property)o);
                }
                else {
                    m_overlay.put((PropertySet)o);
                }
            }
            m_overlay.install(new Requester.ForComponent(m_owningTask));
        }
        return attrs;
    }



    /**
     * Undoes the effect of {@linkplain #installOverlay}.
     **/
    private void uninstallOverlay()
    {
        if (m_overlay!=null) {
            m_overlay.uninstall(new Requester.ForComponent(m_owningTask));
            m_overlay=null;
        }
    }




    /**
     * Executes a new instance of this caller's named macro. Any custom
     * properties are converted into property overlay properties; named
     * attribute values are passed directly into the macro instance
     * factory.
     **/
    public void run()
        throws BuildException
    {
        Map attrs = installOverlay();
        try {
            UnknownElement launch = TaskExaminer.newUEProxy
                (getTargetName(),attrs,(String)null,getProject());
            launch.setOwningTarget(m_owningTask.getOwningTarget());
            launch.perform();
        } finally {
            uninstallOverlay();
        }
    }



    /**
     * Convenient {@linkplain #run() run} alternative that defines
     * a required attribute of the macro instance before we execute
     * it.
     * @param property property name (non-null)
     * @param value property value-- used as-is no additional
     *          replacements are done (non-null)
     **/
    public final void run(String property, String value)
        throws BuildException
    {
        Property p= this.createProperty();
        p.setName(property);
        p.setValue(value);
        run();
    }


    private String m_targetName;
    private List m_plist;
    private Task m_owningTask;
    private ScopedProperties m_overlay;//as-propertyhook
}

/* end-of-MacroInstanceCaller.java */
