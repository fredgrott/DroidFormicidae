/**
 * $Id: NoiseLevel.java 1311 2012-07-07 19:18:04Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  java.util.logging.Level;

import  org.apache.tools.ant.BuildEvent;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.EnumSkeleton;

/**
 * Enumeration of (log) noise levels. Exposed as standalone class
 * since reused by multiple AntXtras tasks and conditions. Note that
 * AntXtras components should use the 
 * {@linkplain org.jwaresoftware.antxtras.parameters.FeedbackLevel
 * FeedbackLevel} item for public-facing parameters instead of a 
 * noise level!
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public final class NoiseLevel extends EnumSkeleton
{
    /** Index of {@linkplain #ERROR ERROR}. 
     *  Implementation: must be indice 0.**/
    public static final int ERROR_INDEX= 0;
    /** Index of {@linkplain #WARNING WARNING}. **/
    public static final int WARNING_INDEX= ERROR_INDEX+1;
    /** Index of {@linkplain #INFO INFO}. **/
    public static final int INFO_INDEX= WARNING_INDEX+1;
    /** Index of {@linkplain #VERBOSE VERBOSE}. **/
    public static final int VERBOSE_INDEX= INFO_INDEX+1;
    /** Index of {@linkplain #DEBUG DEBUG}. **/
    public static final int DEBUG_INDEX= VERBOSE_INDEX+1;
    /** Index of {@linkplain #FATAL FATAL}. 
     *  Implementation: inconsistent index must be handled manually! **/
    public static final int FATAL_INDEX= DEBUG_INDEX+1;

    /** Singleton "fatal" noise level. **/
    public static final NoiseLevel FATAL = new NoiseLevel("fatal",FATAL_INDEX);
    /** Singleton "error" noise level. **/
    public static final NoiseLevel ERROR = new NoiseLevel("error",ERROR_INDEX);
    /** Singleton "warning" noise level. **/
    public static final NoiseLevel WARNING = new NoiseLevel("warning",WARNING_INDEX);
    /** Singleton "info" noise level. **/
    public static final NoiseLevel INFO = new NoiseLevel("info",INFO_INDEX);
    /** Singleton "verbose" noise level. **/
    public static final NoiseLevel VERBOSE = new NoiseLevel("verbose",VERBOSE_INDEX);
    /** Singleton "debug" noise level. **/
    public static final NoiseLevel DEBUG = new NoiseLevel("debug",DEBUG_INDEX);



    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public NoiseLevel()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensure it's initialized
     * as with default Ant Introspector helper thingy.
     **/
    private NoiseLevel(String v, int i)
    {
        super(v);
    }


    /**
     * Returns copy of all possible noise level values as an ordered
     * string array. Note: should be same ordering as EchoLevel.
     **/
    public String[] getValues()
    {
        return new String[] {"error","warning","info","verbose","debug","fatal"};
    };



    /**
     * Helper that converts a scalar to a known noise level.
     * Returns <i>null</i> if value does not match any of expected
     * noise levels index.
     * @param i the index to be matched
     **/
    public static NoiseLevel from(int i)
    {
        switch(i) {
            case ERROR_INDEX:
                return ERROR;
            case WARNING_INDEX:
                return WARNING;
            case INFO_INDEX:
                return INFO;
            case VERBOSE_INDEX:
                return VERBOSE;
            case DEBUG_INDEX:
                return DEBUG;
            case FATAL_INDEX:
                return FATAL;
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(int) from(int)} but with a
     * default value if value does not match any known noise level
     * index.
     * @param i the index to be matched
     * @param dfltNL the default NoiseLevel if necessary
     **/
    public static NoiseLevel from(int i, NoiseLevel dfltNL)
    {
        NoiseLevel nl= from(i);
        return (nl==null) ? dfltNL : nl;
    }


    /**
     * Helper that converts a string to a known noise level
     * singleton. Returns <i>null</i> if string unrecognized.
     * String can be either noise level's symbolic name or
     * its index.
     **/
    public static NoiseLevel from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            if (Character.isDigit(s.charAt(0))) {
                try { return from(Integer.parseInt(s)); }
                catch(Exception nfx) {/*burp*/}
            } else {
                if ("default".equals(s))     { return getAntXDefault(); }
                if (ERROR.value.equals(s))   { return ERROR; }
                if (WARNING.value.equals(s)) { return WARNING; }
                if (INFO.value.equals(s))    { return INFO; }
                if (VERBOSE.value.equals(s)) { return VERBOSE; }
                if (DEBUG.value.equals(s))   { return DEBUG; }
                if (FATAL.value.equals(s))   { return FATAL; }
            }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(java.lang.String) from(String)} but
     * with a default value if value does not match any known
     * noise level name.
     * @param s the symbolic name to be matched
     * @param dfltNL the default NoiseLevel if necessary
     **/
    public static NoiseLevel from(String s, NoiseLevel dfltNL)
    {
        NoiseLevel nl= from(s);
        return (nl==null) ? dfltNL : nl;
    }



    /**
     * Helper that converts a standard Ant message priority to a
     * known noise level. Returns <i>null</i> if priority does not
     * match any of expected project message levels.
     * @param msgLevel the standard Ant message level
     * @since JWare/AntX 0.5
     **/
    public static NoiseLevel fromNativeIndex(int msgLevel)
    {
        switch(msgLevel) {
            case Project.MSG_ERR:
                return ERROR;
            case Project.MSG_WARN:
                return WARNING;
            case Project.MSG_INFO:
                return INFO;
            case Project.MSG_VERBOSE:
                return VERBOSE;
            case Project.MSG_DEBUG:
                return DEBUG;
        }
        return null;
    }


    /**
     * Helper that converts a BuildEvent's priority to a known noise
     * level. Returns <i>null</i> if priority does not match any of
     * expected noise levels.
     * @param e the event (non-null)
     **/
    public static NoiseLevel from(BuildEvent e)
    {
        return fromNativeIndex(e.getPriority());
    }


    /**
     * Helper that converts a JRE's level to a known noise level.
     * @param e the JRE log level (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public static NoiseLevel from(Level e)
    {
        if (e==null) {
            return null;
        }
        if (e==Level.SEVERE) {
            return NoiseLevel.ERROR;
        }
        if (e==Level.WARNING) {
            return NoiseLevel.WARNING;
        }
        if (e==Level.INFO) {
            return NoiseLevel.INFO;
        }
        if (e==Level.FINE || e==Level.CONFIG) {
            return NoiseLevel.VERBOSE;
        }
        return NoiseLevel.DEBUG;
    }


    /**
     * Returns a "pinned" level that's within the standard Ant
     * &lt;echo&gt; and Project MSG_* level set.
     **/
    public final int getNativeIndex()
    {
        int i= getIndex();
        if (i==FATAL_INDEX) {
            return ERROR_INDEX;
        }
        return i;
    }


    /**
     * Returns the <i>AntX</i> default noise level (INFO).
     * @see #getDefault
     **/
    public static final NoiseLevel getAntXDefault()
    {
        return NoiseLevel.INFO;
    }



    /**
     * Helper that returns a project's default noise level.
     * Looks in the project to see if a script-specified
     * {@linkplain AntX#DEFAULT_NOISELEVEL_PROP default} noise
     * level has been defined. If none specified in project (which
     * also includes System properties) then returns the AntXtras
     * {@linkplain #getAntXDefault default}. Never returns
     * <i>null</i>.
     * @param P [optional] caller's project
     * @see #getAntXDefault
     **/
    public static final NoiseLevel getDefault(final Project P)
    {
        String slvl = Tk.getTheProperty(P, AntX.DEFAULT_NOISELEVEL_PROP);
        NoiseLevel nl = getAntXDefault();
        if (slvl!=null) {
            nl= NoiseLevel.from(slvl,nl);
        }
        return nl;
    }



    /**
     * Helper that returns an sub-context or antxtras-dependent project's
     * default noiselevel. Allows dependent projects like 'svn4ant' or
     * 'log4ant' to be controlled distinct from each other. Note that the
     * "&#46;noiselevel" tail is appended to incoming context prefix.
     * @param other name of sub-context or antxtras dependent project (non-null)
     * @param P [optional] caller's project
     * @return default noise level (never <i>null</i>)
     * @since JWare/AntXtras 2.0.0
     **/
    public static final NoiseLevel getDefault(String other, final Project P)
    {
        String propertyname = AntX.ANTX_CONFIG_DEFAULTS_PREFIX+other+".noiselevel";
        String slvl = Tk.getTheProperty(P, propertyname);
        NoiseLevel nl = getDefault(P);
        if (slvl!=null) {
            nl= NoiseLevel.from(slvl,nl);
        }
        return nl;
    }



    /**
     * Determine if the given noise level is as bad (in effect) as the
     * named threshold.
     * @param unk noise level to be tested (non-null)
     * @param threshold threshold level (non-null)
     * @return <i>true</i> if is as bad (in effect) as threshold
     * @since JWare/AntX 0.5
     **/
    public static final boolean isAsBadAs(NoiseLevel unk, NoiseLevel threshold)
    {
        boolean is;
        if (FATAL.equals(threshold)) { is = FATAL.equals(unk); }
        else { is = unk.getNativeIndex() <= threshold.getNativeIndex(); }
        return is;
    }



    /**
     * Determine if the given Ant log level is as bad (in effect) as the
     * named noise threshold.
     * @param loglevel Ant log level to be tested (non-null)
     * @param threshold threshold level (non-null)
     * @return <i>true</i> if is as bad (in effect) as threshold
     * @since JWare/AntX 0.5
     **/
    public static final boolean isAsBadAs(int loglevel, NoiseLevel threshold)
    {
        return loglevel <= threshold.getNativeIndex();
    }



    /**
     * Convenient (and visually clearer) instance variant of
     * {@linkplain #isAsBadAs(NoiseLevel, NoiseLevel)
     * isAsBadAs(NoiseLevel,NoiseLevel)}.
     * @param threshold threshold level (non-null)
     * @return <i>true</i> if is as bad (in effect) as threshold
     * @since JWare/AntX 0.5
     **/
    public final boolean isAsBadAs(NoiseLevel threshold)
    {
        return isAsBadAs(this,threshold);
    }
}

/* end-of-NoiseLevel.java */
