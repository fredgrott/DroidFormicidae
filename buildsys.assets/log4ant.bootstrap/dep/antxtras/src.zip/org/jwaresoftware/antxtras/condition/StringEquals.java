/**
 * $Id: StringEquals.java 1488 2012-08-21 11:40:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.ownhelpers.StringEquality;
import  org.jwaresoftware.antxtras.parameters.IgnoreCaseEnabled;
import  org.jwaresoftware.antxtras.parameters.TrimEnabled;
import  org.jwaresoftware.antxtras.parameters.ValueMatchEnabled;

/**
 * Flexible String-Equals condition that evaluates <i>true</i> if
 * an unknown value equals a predefined value. This condition allows
 * script writers to include simple &lt;equals&gt; checks in rules where
 * properties or variables may or may not exist before the rule is
 * parsed; for instance:
 * <pre>
 *  &lt;rule id="is.public.dist"&gt;
 *    &lt;require&gt;
 *      &lt;<b>equals</b> match="public" property="dist.type"/&gt;
 *      &lt;noneset&gt;
 *          &lt;property name ="build.number"&gt;
 *          &lt;property name ="disable.cvs"&gt;
 *          &lt;property name ="disable.clean"&gt;
 *      &lt;/noneset&gt;
 *    &lt;/require&gt;
 *  &lt;/rule&gt;
 *  
 *  -or-
 *  
 *  &lt;do true="${<b>$isequal:</b>public,,${dist.type}}"&gt;
 *     ...
 * </pre>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2004,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple (after fully configured)
 * @.group   api,infra
 * @see      StringEquality
 **/

public final class StringEquals extends FlexCondition
    implements IgnoreCaseEnabled, TrimEnabled, ValueMatchEnabled, URIable
{
    /**
     * Initializes a new StringEquals condition. The new
     * condition's match value and flex value must be defined
     * before it is evaluated.
     **/
    public StringEquals()
    {
        super();
        m_impl.setOperator(StringEquality.OP_EQUALS);
        getValueHelper().setLenient(false);
    }


    /**
     * Initializes the enclosing project of this condition.
     * Also updates this condition's helper bits.
     **/
    public void setProject(Project P)
    {
        super.setProject(P);
        m_impl.setProject(P);
    }


    /**
     * Returns this equality condition's underlying unknown
     * argument's flex string. Never returns <i>null</i>.
     **/
    protected final FlexString getValueHelper()
    {
        return m_impl.getUnknownValueGetter();
    }



    /**
     * Sets this condition's value and match as part of a URI. The
     * first param is the match-against pattern, the second param is
     * the unknown VALUE.
     * @param fragment the matcher's uri bits (non-null)
     * @since JWare/AntXtras 4.0.0
     */
    public void xsetFromURI(String fragment)
    {
        int N = fragment.length();
        int i = -1;
        if (N>=FunctionShortcut.PARAMS_DELIMITER_LEN+2) {
            i = fragment.indexOf(FunctionShortcut.PARAMS_DELIMITER);
            if (i>0 && (i+FunctionShortcut.PARAMS_DELIMITER_LEN<N)) {
                setMatch(fragment.substring(0,i));
                setValue(fragment.substring(i+FunctionShortcut.PARAMS_DELIMITER_LEN));
            }
        }
    }

// ---------------------------------------------------------------------------------------
// Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets this condition's known to-be-equaled value.
     * @param value value against which determined value is checked (non-null)
     **/
    public void setMatch(String value)
    {
        require_(value!=null,"setMatch- nonzro mtch valu");
        m_impl.setKnownArg(value);
    }



    /**
     * Synonym for {@linkplain #setMatch(String) setMatch}
     * that allows scripts to use nested CDATA to escape XML 
     * reserved characters in the incoming match value.
     * @param value literal value as a simple nested text element (non-null)
     * @since JWare/AntXtras 3.5.0
     **/
    public final void addConfiguredMatch(InnerString value)
    {
        setMatch(value.getText());
    }



    /**
     * Returns value against which the determined value is checked.
     * Returns <i>null</i> if never set.
     **/
    public final String getMatch()
    {
        return m_impl.getKnownArg();
    }



    /**
     * Sets a to-be-checked literal value.
     * @param value value to be matched (non-null)
     **/
    public final void setValue(String value)
    {
        require_(value!=null,"setValue- nonzro");
        setLiteral(value);
    }



    /**
     * Synonym for {@linkplain #setValue(String) setValue}
     * that allows scripts to use nested CDATA to escape XML 
     * reserved characters in the incoming value.
     * @param value literal value as a simple nested text element (non-null)
     * @since JWare/AntXtras 3.5.0
     **/
    public final void addConfiguredValue(InnerString value)
    {
        setValue(value.getText());
    }



    /**
     * Set whether the values should be trimmed of whitespace
     * before they are compared.
     **/
    public void setTrim(boolean trim)
    {
        m_impl.setTrim(trim);
    }


    /**
     * Returns <i>true</i> if the values will be trimmed before
     * they are compared.
     **/
    public final boolean willTrim()
    {
        return m_impl.willTrim();
    }



    /**
     * Set whether the values should be lower-cased before
     * they are compared.
     **/
    public void setIgnoreCase(boolean ignore)
    {
        m_impl.setIgnoreCase(ignore);
    }


    /**
     * Returns <i>true</i> if the values will be lower-cased
     * before they are compared.
     **/
    public final boolean isIgnoreCase()
    {
        return m_impl.isIgnoreCase();
    }


// ---------------------------------------------------------------------------------------
// Evaluation:
// ---------------------------------------------------------------------------------------

    /**
     * Returns <i>true</i> if the calculated value equals the expected
     * value.
     **/
    public boolean eval()
    {
        verifyCanEvaluate_("eval");

        return m_impl.eval();
    }


    /**
     * Verifies that this condition is in valid project and has both its
     * known and unknown values defined.
     * @param calr caller's identifier
     * @throws BuildException if not in project or all bits not defined
     **/
    protected void verifyCanEvaluate_(String calr)
    {
        super.verifyCanEvaluate_(calr);

        if (getMatch()==null) {
            String ermsg = Errs.NeedsThisAttribute(getTypicalName(),"match");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg);
        }
    }


    private final StringEquality m_impl = new StringEquality();
}

/* end-of-StringEquals.java */
