/**
 * $Id: AssertableProjectComponent.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.apache.tools.ant.ComponentHelper;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;

import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.internal.apis.UIStringManager;

/**
 * Extension of basic Ant <i>ProjectComponent</i> that adds builtin assertions.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,infra
 **/

public abstract class AssertableProjectComponent extends ProjectComponent
    implements ProjectDependent
{
    /**
     * Creates new unlabeled component.
     **/
    protected AssertableProjectComponent()
    {
        super();
        Iam_="";
    }


    /**
     * Creates new cv-labeled component.
     * @param iam CV-label (non-null)
     **/
    protected AssertableProjectComponent(String iam)
    {
        super();
        Iam_= Tk.cvlabelFrom(iam);
    }



    /**
     * Gets as descriptive as possible a name used for this simple component.
     * @return brief type name or class leaf name if not declared
     * @since JWare/AntXtras 3.5.0
     */
    protected final String getDeclaredTypeName()
    {
        return ComponentHelper.getElementName(getProject(), this, true);
    }


    /**
     * Shortcut that returns this task's internal AntX UI
     * strings manager. Never returns <i>null</i>.
     * @see Iteration#uistrs
     **/
    public final UIStringManager uistrs()
    {
        return Iteration.uistrs();
    }


    /**
     * Throws assertion error if pre-condtion is not met.
     * @param c pre-condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalArgumentException if condition not met
     **/
    protected final void require_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.require",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalArgumentException(ermsg);
        }
    }


    /**
     * Throws assertion error if post-condition is not met. Used
     * for post-condition verification.
     * @param c post-condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalStateException if condition not met
     **/
    protected final void ensure_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.ensure",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    /**
     * Throws assertion error if condition is not met. Used for
     * block and invariant verification.
     * @param c condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalStateException if condition not met
     **/
    protected final void verify_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.verify",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    /**
     * Notes an unexpected but manageable problem has occured.
     * Just logs a warning by default.
     * @param t [optional] causing throwable
     * @param msg caller's additional (context) message
     **/
    protected final void unexpected_(Throwable t, String msg)
    {
        String ermsg = uistrs().get("cv.unexpected",Iam_,msg,t);
        log(ermsg, Project.MSG_WARN);
    }


    /**
     * Verifies we're in a live project (created from build
     * process).
     **/
    protected final void verifyInProject_(String calr)
    {
        if (getProject()==null) {
            String ermsg = uistrs().get("cv.verifyInP",Iam_,calr);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    private final String Iam_;
}

/* end-of-AssertableProjectComponent.java */
