/**
 * $Id: UnresolvedProperty.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

/**
 * Special marker value for a property with a unresolved variable reference.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,helper
 * @.pattern Fowler.SpecialValue
 **/

public final class UnresolvedProperty
{
    /**
     * Special value of a property with an unresolved variable
     * substitution problem.
     * @.impl The string is explicitly allocated so its reference
     *        is not the same as the interned constant.
     **/
    public static final String VALUE;
    static {
        StringBuffer sb = new StringBuffer(new String("__unresolved__"));
        VALUE= sb.substring(0);//=>different,unshared,string!
        sb= null;
    }


    /**
     * Hide; only the public constant available.
     **/
    private UnresolvedProperty()
    {
    }
}

/* end-of-UnresolvedProperty.java */
