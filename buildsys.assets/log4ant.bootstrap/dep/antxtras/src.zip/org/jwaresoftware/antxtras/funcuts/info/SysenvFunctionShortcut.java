/**
 * $Id: SysenvFunctionShortcut.java 991 2010-02-28 19:09:20Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import org.apache.tools.ant.util.JavaEnvUtils;

/**
 * Function shortcut that returns current value of the named System 
 * <i>environment</i> variable or null if no such property found.
 * The general form of the funcut URI is: 
 * <span class="src">$sysenv:<nobr>name[?default-value]</nobr></span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;property name="uid" value="${$sysenv:USERNAME?public}/&gt;
 * <b>2)</b> &lt;assign var="_root" value="${$sysenv:DEPLOY_HOMES?${tmp.d}}/&gt;
 *
 * <b>3)</b> -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="sysenv"
 *          value="${ojaf}.info.SysenvFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class SysenvFunctionShortcut extends SystemFunctionShortcut
{
    /**
     * Determine if our runtime permits use of System.getenv. Because
     * System.getenv was not only deprecated but actually generates
     * a java&#46;lang&#46;Error for JRE 1&#46;2 thru 1&#46;4, we need
     * to avoid calling this function if our runtime matches this range.
     */
    public final static boolean ALLOWED;
    static {
        int jre = JavaEnvUtils.getJavaVersionNumber();
        if (jre==JavaEnvUtils.VERSION_1_4||
            jre==JavaEnvUtils.VERSION_1_3||
            jre==JavaEnvUtils.VERSION_1_2) {
            ALLOWED = false;
        } else {
            ALLOWED = true;
        }
    }


    /**
     * Initializes a new sysenv function shortcut instance.
     **/
    public SysenvFunctionShortcut()
    {
        super();
    }


    /**
     * Looks up the named property against the system environment.
     * Returns the default value if no such property.
     * @param name property name (non-null)
     * @param dfault [optional] default if property not found
     **/
    protected String getProperty(String name, String dfault)
    {
        String s = ALLOWED ? System.getenv(name) : super.getProperty(name,dfault);
        return (s==null) ? dfault : s;
    }
}

/* end-of-SysenvFunctionShortcut.java */
