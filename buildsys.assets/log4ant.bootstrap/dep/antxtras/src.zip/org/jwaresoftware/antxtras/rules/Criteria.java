/**
 * $Id: Criteria.java 1019 2010-03-13 16:13:19Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureComponent;
import  org.jwaresoftware.antxtras.core.NoiseLevel;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.ProjectPropertiesNet;
import  org.jwaresoftware.antxtras.starters.Quiet;
import  org.jwaresoftware.antxtras.starters.TaskSet;

/**
 * A reusable condition that requires more than a sequence of simplier conditions
 * to determine whether all criteria have been met. Criteria can have two kinds of
 * fixture side-effects: they can initialize or modify fixture variables (actually
 * this is required for the criteria to set the returned result variable), and
 * they can create or alter project references.
 * <p/>
 * A criteria is meant to be reusable and can be executed many times within
 * a single execution cycle. Therefore, the items you nest within a criteria
 * <em>cannot</em> rely on changing properties outside the scope of the criteria.
 * All property additions and/or modifications are limited to the criteria's
 * scope (and are not seen by the project once the criteria has exited). As you
 * would expect, pre-existing and overlaid properties can be read from within
 * the criteria.
 * <p/>
 * For a criteria to pass, you <em>must</em> set the result variable (as defined
 * by the <span class="src">resultvar</span> parameter) before leaving the
 * criteria's body.
 * <p/>
 * Criteria are <em>not</em> tallysets or rulesets. Their purpose is to be a
 * general and reusable boolean function whose effect on the surrounding fixture
 * is not prescribed (as it is. for instance, for assertions or preferences).
 * Although this (lack of) definition makes them different from other rule
 * components, they're still meant to be used as execution tests for the various
 * AntXtras flow control task(set)s.
 * <p/>
 * <b>Example Usage:</b><pre>
 * 1) &lt;<b>criteria</b> id="alms-uptodate" resultvar="out:alms-uptodate"&gt;
 *      &lt;local name="_module.meta"/&gt;
 *      &lt;property name="_module.meta" value="${alms.module.dir}/.crdate"/&gt;
 *      &lt;domatch value="${$filenotempty:${_module.meta}}"&gt;
 *        &lt;true&gt;
 *           &lt;loadfile srcFile="${repository.arms}/${alms.module}/.crdate"
 *                        property="_repo.crdate"/&gt;
 *           &lt;loadfile srcFile="${_module.meta}"
 *                        property="_alms.crdate"/&gt;
 *           &lt;do true="${$newerdate:${_repo.crdate},,${_alms.crdate}}"&gt;
 *              &lt;assign var="out:alms-uptodate" value="no"/&gt;
 *           &lt;/do&gt;
 *        &lt;/true&gt;
 *        &lt;otherwise&gt;
 *           &lt;assign var="out:alms-uptodate" value="no"/&gt;
 *        &lt;/otherwise&gt;
 *      &lt;/domatch&gt;
 *    &lt;/criteria&gt;
 *
 * 2) &lt;<b>criteria</b> id="docs-uptodate" resultvar="out:docs-uptodate"&gt;
 *       &lt;assert allset="src,html" message="src and html directory defined"/&gt;
 *       &lt;local name="docs-uptodate"/&gt;
 *       &lt;tally trueproperty="docs-uptodate"&gt;
 *          &lt;issettrue property="disable.apidocs"/&gt;
 *          &lt;isnotset property="clean"/&gt;
 *          &lt;uptodate targetfile="${html}/index.html"&gt;
 *             &lt;srcfiles dir="${srcs}"&gt;
 *                &lt;include name="**&#47;doc-files&#47;"/&gt;
 *                &lt;include name="**&#47;*.java"/&gt;
 *                &lt;exclude name="**&#47;*Test*.java" unless="allapis"/&gt;
 *                &lt;include name="**&#47;package.html"/&gt;
 *                &lt;include name="**&#47;overview.html"/&gt;
 *                &lt;exclude name="**&#47;.*&#47;**"/&gt;
 *             &lt;/srcfiles&gt;
 *          &lt;/uptodate&gt;
 *       &lt;/tally&gt;
 *       &lt;assign var="out:docs-uptodate" fromproperty="docs-uptodate"/&gt;
 *    &lt;/criteria&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,infra
 **/

public final class Criteria extends TaskSet
    implements ShareableCondition, Quiet, AntLibFriendly, FixtureComponent
{
    /**
     * Initializes a new criteria instance.
     **/
    public Criteria()
    {
        super(AntX.rules+"Criteria:");
        setWithLocals(true);
    }


    /**
     * Returns {@linkplain NoiseLevel#INFO INFO} always.
     **/
    public NoiseLevel getFailureEffect()
    {
        return NoiseLevel.INFO;
    }


//  ---------------------------------------------------------------------------------------
//  Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Captures this criteria's reference identifier. Will be used
     * in feedback and other internal needs.
     * @param id the reference handle (non-null)
     **/
    public void setId(String id)
    {
        require_(id!=null,"setId- nonzro id");
        m_id = id;
    }



    /**
     * Returns this criteria's reference id. Will return a default
     * name "<span class="src">criteria</span>" if not set explicitly.
     * Never returns <i>null</i>.
     **/
    public String getId()
    {
        return m_id;
    }



    /**
     * Tells this criteria the result variable it should check when
     * it is evaluated. The variable is checked <em>after</em> all
     * nested tasks have been performed.
     * @param outVar the variable name (non-null)
     **/
    public void setResultVariable(String outVar)
    {
        require_(!Tk.isWhitespace(outVar),"setRsltVar- nonzro name");
        m_outParam = outVar;
    }



    /**
     * Synonym for {@linkplain #setResultVariable setResultVariable(&#8230;)}.
     * @param outVar the variable name (non-null)
     **/
    public final void setResultVar(String outVar)
    {
        setResultVariable(outVar);
    }



    /**
     * Returns this criteria's result variable. Will return
     * <i>null</i> if never set explicitly.
     * @see #setResultVariable setResultVariable(&#8230;)
     **/
    public final String getResultVariable()
    {
        return m_outParam;
    }


//  ---------------------------------------------------------------------------------------
//  Evaluation:
//  ---------------------------------------------------------------------------------------

    /**
     * Ensure we have been assigned a (default) result variable. This is
     * required so we can determine the true/false result of the criteria
     * we represent.
     * @throws BuildException if have not been assigned a result variable.
     */
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (getResultVariable()==null) {
            String e = getAntXMsg("type.needs.this.attr",getTaskName(),"resultvariable");
            log(e, Project.MSG_ERR);
            throw new BuildException(e, getLocation());
        }
    }



    /**
     * Calls this criterial nested tasks then checks the {@linkplain
     * #setResultVar result variable} for a positive boolean string.
     * Caller can override the prescribed result variable's name by
     * passing in an update variable.
     * @param calr caller (non-null)
     * @throws BuildException if any nested task does.
     **/
    public boolean eval(ShareableConditionUser calr)
    {
        verifyCanExecute_("eval");

        String resultVar = getResultVariable();
        if (calr.getUpdateVariable()!=null) {
            resultVar = calr.getUpdateVariable();
        }
        Variables.unset(resultVar);

        performNestedTasks();

        String evalResult = Variables.readstring(resultVar);
        return Tk.string2PosBool(evalResult)==Boolean.TRUE;
    }



    /**
     * Runs a new copy of nested tasks in order. The <span class="src">perform</span>
     * message is sent to each nested task. Subclasses can override this method to
     * decorate the central <span class="src">performIterationOfTasksList</span>
     * method which does the heavy lifting.
     * @throws BuildException if any nested task does.
     **/
    protected void performNestedTasks()
    {
        ProjectPropertiesNet bubble = new ProjectPropertiesNet(getId(),getProject());
        try {
            performIterationOfTheTasksList();
        } finally {
            bubble.uninstall(new Requester.ForComponent(this));
        }
    }



    /**
     * No-op; criteria must be explicitly evaluated by other tasks.
     **/
    public final void execute()
    {
        //burp...quietly
    }


    private String m_outParam;
    private String m_id = "criteria";
}

/* end-of-Criteria.java */