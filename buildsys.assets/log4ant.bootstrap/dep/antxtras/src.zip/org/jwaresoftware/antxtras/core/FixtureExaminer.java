/**
 * $Id: FixtureExaminer.java 1303 2011-10-22 11:52:46Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  java.lang.reflect.Method;
import  java.util.Collection;
import  java.util.Collections;
import  java.util.Iterator;
import  java.util.List;
import  java.util.ListIterator;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.ComponentHelper;
import  org.apache.tools.ant.Location;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.UnknownElement;
import  org.apache.tools.ant.PropertyHelper.Delegate;
import  org.apache.tools.ant.property.LocalProperties;
import  org.apache.tools.ant.property.LocalPropertyStack;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.behaviors.PropertiesFactoryMethod;
import  org.jwaresoftware.antxtras.behaviors.PropertyHelperWrap;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.PropertySource;

/**
 * Collection of utilities for extracting bits of information from the current
 * project and/or execution cycle's fixture.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2007-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded
 * @.group   impl,helper
 * @see      org.jwaresoftware.antxtras.ownhelpers.LocalTk LocalTk
 * @.stereo  utility
 **/

public final class FixtureExaminer implements FixtureCore
{
    private static final String IAM_= AntX.AntX+"FixtureExaminer:";


    /**
     * Determine best fit location to associated with message.
     * @sideeffect: logs incoming message.
     **/
    private static Location prethrow(Project project, Requester from,
                                     String message, int level)
    {
        Location loc = Location.UNKNOWN_LOCATION;
        if (from!=null) {
            from.log(message, level);
            loc = from.getLocation();
        } else {
            project.log(message,level);
        }
        return loc;
    }


    /**
     * Returns a type-checked referenced object. Common utility that
     * generates a resource bundle based messages if reference broken.
     * @param project the source project
     * @param from [optional] the calling element
     * @param refid the referred-to thing's identifier (non-null)
     * @param requiredClass the required class of referred-to thing (non-null)
     * @throws BuildException if no such reference or object is not compatible
     **/
    public static final Object getReferencedObject(Project project,
                                                   Requester from,
                                                   String refid,
                                                   Class requiredClass)
    {
        AntX.require_(refid!=null,IAM_,"getRefObj- nonzro id");
        AntX.require_(project!=null,IAM_,"getRefObj- nonzro project");

        Object o = project.getReference(refid);
        String error = null;

        if (o==null) {
            error = AntX.uistrs().get(Errs.TMR, refid);
        }
        else if (!requiredClass.isInstance(o)) {
            error = AntX.uistrs().get(Errs.TBR, refid,
                                      requiredClass.getName(),
                                      o.getClass().getName());
        }
        if (error!=null) {
            Location loc = prethrow(project,from,error,Project.MSG_ERR);
            throw new BuildException(error,loc);
        }
        return o;
    }



    private static String isOneOf(String value,
            String shortshortcut, String shortcut, String fullname)
    {
        if (shortshortcut!=null && value.startsWith(shortshortcut)) {
            return value.substring(shortshortcut.length());
        }
        if (shortcut!=null && value.startsWith(shortcut)) {
            return value.substring(shortcut.length());
        }
        if (value.startsWith(fullname)) {
            return value.substring(fullname.length());
        }
        return null;
    }



    /**
     * Utility that converts a reference to a properties collection to a
     * standard Java <span class="src">Properties</span> object. Currently
     * handles references to <span class="src">GenericParameters</span>,
     * <span class="src">PropertySet</span>s, and
     * <span class="src>Properties</span> objects
     * @param project source project (non-null)
     * @param refid referenced data object (non-null)
     * @param defaultProperties [optional] set to a fallback properties if
     *         reference does not exist.
     * @return Properties object if reference is convertible; <i>null</i>
     *         if it is not; <span class="src">defaultProperties</span> if
     *         no such reference.
     * @since JWare/AntX 0.5
     **/
    public static Properties getReferencedProperties(Project project,
        String refid, Properties defaultProperties)
    {
        AntX.require_(refid!=null,IAM_,"getRefPropertiesObj- nonzro refid");
        AntX.require_(project!=null,IAM_,"getRefPropertiesObj- nonzro project");

        Properties Ps = null;
        Object o = project.getReference(refid);
        if (o!=null) {
            //NB: Extract properties against given project to ensure we
            //    resolve all ${} placeholders!
            if (o instanceof PropertiesFactoryMethod) {
                Ps = ((PropertiesFactoryMethod)o).toProperties(project);
            } else if (o instanceof PropertySet) {
                Ps = ((PropertySet)o).getProperties();
            } else if (o instanceof Properties) {
                Ps = ((Properties)o);
            }
        } else {
            Ps = defaultProperties;
        }
        return Ps;
    }



    /**
     * Looks for a top-level property or a nested property (inside a
     * global reference properties-like holder).
     * @param key the property lookuup key (non-null)
     * @param project the source project (non-null)
     * @return property value or <i>null</i> if undefined
     * @since JWare/AntX 0.5
     **/
    private static String getProperty(String key, Project project)
    {
        String value = project.getProperty(key);
        int i;
        if (value==null && (i=key.indexOf("->"))>0) {
            String holder = key.substring(0,i);
            i += 2;
            if (i<key.length()) {
                key = key.substring(i);
                Properties Ps = getReferencedProperties(project,holder,null);
                if (Ps!=null) {
                    value = Ps.getProperty(key);
                }
            }//!malformed
        }
        return value;
    }



    /**
     * Determine if given function shortcut prefix is one of the
     * AntXtras-reserved ones. Note that case is ignored when
     * checking the prefix.
     * @param name the script-supplied prefix (non-null)
     * @return <i>true</i> if reserved
     * @since JWare/AntX 0.5
     **/
    public static boolean isBuiltinFunctionShortcutScheme(String name)
    {
        if (name.charAt(0)=='$') {
            int n = name.length();
            int i = name.indexOf(':');
            if (i>0) {
                n = i;
            }
            name = name.substring(1,n);
        }

        boolean reserved = false;
        name = Tk.lowercaseFrom(name);

        if (name.length()>0) {
            switch(name.charAt(0)) {
                case 'r': {
                    if ("r".equals(name) || "ref".equals(name) || "reference".equals(name)) {
                        reserved = true;
                    }
                    break;
                }
                case 'v': {
                    if ("v".equals(name) || "var".equals(name) || "variable".equals(name)) {
                        reserved = true;
                    }
                    break;
                }
                case 'p': {
                    if ("p".equals(name) || "prop".equals(name) || "property".equals(name)) {
                        reserved = true;
                    }
                    break;
                }
                case 'g': {
                    if ("g".equals(name) || "globalproperty".equals(name)) {
                        reserved = true;
                    }
                    break;
                }
            }
        }
        return reserved || "null".equals(name);
    }



    /**
     * Looks for an iteration property or a nested iteration property.
     * @param key the property lookuup key (non-null)
     * @param project [optional] the source project
     * @return property value or <i>null</i> if undefined
     * @since JWare/AntX 0.5
     **/
    public static String getIterationProperty(String key, Project project)
    {
        Object value = Iteration.getProperty(key);
        int i;
        if (value==null && (i=key.indexOf("->"))>0) {
            String holder = key.substring(0,i);
            i += 2;
            if (i<key.length()) {
                key = key.substring(i);
                value = Iteration.getProperty(holder,key);
            }
        }
        return Iteration.strictStringifier().stringFrom(value,project);
    }



    /**
     * Determine if there is an installed function shortcut
     * interpreter in the given project.
     * @param project the source project (non-null)
     * @return <i>true</i> if installed, else <i>false</i>
     * @since JWare/AntX 0.5
     * @see org.jwaresoftware.antxtras.funcuts.ManageFuncutsTask
     **/
    public static boolean functionShortcutInterpreterInstalled(Project project)
    {
        AntX.require_(project!=null,IAM_,"funcutInstalled- nonzro project");
        Object interpreter = project.getReference(FixtureIds.FUNCUTS_INTERPRETER);
        return (interpreter instanceof PropertyHelper);
    }



    /**
     * Determine the value of a standalone (unpiped) funcut. This
     * method is used by the public API which parses for piped variants.
     * @param value full function shortcut URI (single,non-null)
     * @param obof originating property being determined (non-null)
     * @param clnt call controls (non-null)
     * @return property or function shortcut results or null if cannot determine.
     **/
    private static final String funcValue(String value, String obof,
                                          Requester clnt)
    {
        String dflt=null,key;
        Project project = clnt.getProject();

        //Hard-coded; cannot override...
        if ((key = isOneOf(value,"$v:","$var:","$variable:"))!=null) {
            int i = key.lastIndexOf(FunctionShortcut.SCHEME_DELIMITER);
            if (i>0) {
                dflt = key.substring(i+FunctionShortcut.SCHEME_DELIMITER_LEN);
                key = key.substring(0,i);
            }
            return Variables.readstring(key,dflt);
        }
        if ((key = isOneOf(value,"$p:","$prop:","$property:"))!=null) {
            int i = key.lastIndexOf(FunctionShortcut.SCHEME_DELIMITER);
            if (i>0) {
                dflt = key.substring(i+FunctionShortcut.SCHEME_DELIMITER_LEN);
                key = key.substring(0,i);
            }
            if (!key.equals(obof)) {//NB:zap circular references!
                String match = getProperty(key,project);
                return match==null ? dflt : match;
            }
        }
        if ((key = isOneOf(value,"$r:","$ref:","$reference:"))!=null) {
            int i = key.lastIndexOf(FunctionShortcut.SCHEME_DELIMITER);
            if (i>0) {
                dflt = key.substring(i+FunctionShortcut.SCHEME_DELIMITER_LEN);
                key = key.substring(0,i);
            }
            Object o = project.getReference(key);
            String s =  Iteration.lenientStringifer().stringFrom(o,project);
            return s==null ? dflt : s;
        }
        if ((key = isOneOf(value,"$g:",null,"$globalproperty:"))!=null) {
            return getIterationProperty(key,project);
        }
        //User-coded; whatever...
        int i = value.indexOf(":");
        if (i>1) {
            String scheme = value.substring(1,i);
            return Iteration.funcutHandler(scheme).valueFrom
                (value.substring(i+1), value, clnt);
        }
        return null;
    }



    /**
     * Converts any nested funcut URIs in given value. Called by AntX's
     * function shortcut interpreter and explicitly by a select set of
     * components like &lt;overlay&gt;.
     * @param value the encoded value to lookup (prefixed w/ '$type:')
     * @param obof [optional] originating property source (used to
     *             ensure no circular definitions in property lookups)
     * @param clnt originating call controls (non-null)
     * @since JWare/AntX 0.5
     * @see FunctionShortcut
     **/
    public static final String findValue(String value, String obof,
                                         Requester clnt)
    {
        AntX.require_(value!=null,IAM_,"findValue- nonzro values");
        AntX.require_(clnt!=null && clnt.getProject()!=null,IAM_,
                      "findValue- nonzro project");

        //@since AntX 0.5 (supports custom funcut handlers and pipes)
        String result = null;
        while (value.length()>2 && value.charAt(0)=='$') {
            int colon = value.indexOf(":");
            if (colon <= 1) {
                break;
            }
            String scheme = value.substring(1,colon);
            String singleuri = value;
            int piped = value.indexOf("|$",colon+1);
            String fragment = null;
            if (piped>colon) {
                fragment = value.substring(colon+1,piped);
                singleuri = "$"+scheme+":"+fragment;
            } else {
                fragment = value.substring(colon+1);
            }
            //clnt.log("Evaluating funcut URI '"+singleuri+"'");
            String nextresult = funcValue(singleuri,obof,clnt);
            result = nextresult;
            if (result==null || singleuri==value) {
                break;
            }
            colon = value.indexOf(':',piped+2);
            if (colon<0) {
                result = null;//NB:malformed
                break;
            }
            String nextvalue = "$"+value.substring(piped+2,colon+1)+result;
            if (colon<value.length()-1) {
                nextvalue += value.substring(colon+1);
            }
            value = nextvalue;
            //clnt.log("  Next funcut URI is '"+value+"'");
        }
        return result;
    }



    /**
     * Like {@linkplain #findValue(String,String,Requester)
     * findValue(String,String,&#8230;)} for anonymous utility-based
     * lookups.
     * @param project the source project (non-null)
     * @param value the encoded value to lookup (prefixed w/ '$type:')
     * @param obof [optional] originating property source (used to
     *             ensure no circular definitions in property lookups)
     * @since JWare/AntX 0.4
     **/
    public static final String findValue(Project project,
                                         String value, String obof)
    {
        Requester clnt=null;
        if (project!=null) {
            Task t = project.getThreadTask(Thread.currentThread());
            if (t!=null) {
                clnt = new Requester.ForComponent(t);
            }
        }
        if (clnt==null) {
            clnt = new Requester.ForProject(project);
        }
        return findValue(value,obof,clnt);
    }



    /**
     * Check whether a project property already exists and optionally
     * barfs if it does. Always emits a warning (at least) if the property
     * does exist. Most useful for verifying that a user-specified update
     * property doesn't already exist.
     * @param project the source project
     * @param from [optional] the calling element
     * @param property name of property to check
     * @param warn <i>true</i> if only issue a warning <em>otherwise
     *             can fail</em>
     * @return <i>true</i> if property already exists
     * @throws BuildException if property exists and isn't a warning
     * @since JWare/AntX 0.3
     **/
    public static boolean checkIfProperty(Project project, Requester from,
                                          String property, boolean warn)
    {
        AntX.require_(project!=null, IAM_,"chkIfProp- nonzro project");
        AntX.require_(property!=null,IAM_,"chkIfProp- nonzro nam");

        String it = Tk.getTheProperty(project,property);
        if (it!=null) {
            //NB: side-effect is a log to console for warn or error!
            String msg = Errs.PropertyExists(property);
            Location loc = prethrow(project, from, msg,
                                    (warn ? Project.MSG_WARN : Project.MSG_ERR));
            if (!warn) {
                throw new BuildException(msg,loc);
            }
        }
        return it!=null;
    }



    /**
     * Check whether a project reference already exists and optionally
     * barfs if it does. Always emits a warning (at least) if the
     * reference does exist. Most useful for verifying that a
     * user-specified update reference doesn't already exist.
     * @param project the source project
     * @param from [optional] the calling element
     * @param refid name of reference to check
     * @param warn <i>true</i> if only issue a warning <em>otherwise
     *             can fail</em>
     * @return <i>true</i> if reference already exists
     * @throws BuildException if reference exists and isn't a warning
     **/
    public static boolean checkIfReference(Project project, Requester from,
                                           String refid, boolean warn)
    {
        AntX.require_(project!=null,IAM_,"chkIfRef- nonzro project");
        AntX.require_(refid!=null,IAM_,"chkIfRef- nonzro refid");

        boolean exists = project.hasReference(refid); 
        if (exists) {
            String msg = Errs.ReferenceExists(refid);
            Location loc = prethrow(project, from, msg,
                                    (warn ? Project.MSG_WARN : Project.MSG_ERR));
            if (!warn) {
                throw new BuildException(msg,loc);
            }
        }
        return exists;
    }



    /**
     * Special value object used to indicate a reference that
     * has yet to be determined (in other target, or out-of-scope).
     * @.pattern Fowler.SpecialValue
     * @since JWare/AntX 0.4
     **/
    public static final Object IGNORED_REFERENCE= "__ooscope_ref__";



    /**
     * Special value object used to indicate a reference that
     * could not be determined (generated errors).
     * @.pattern Fowler.SpecialValue
     * @since JWare/AntX 0.4
     **/
    public static final Object PROBLEM_REFERENCE= "__problem_ref__";



    /**
     * Special value object used to indicate a reference that
     * is about to be assigned by a subsequent factory task. Allows
     * the dynamic creation of reference id to appear atomic to
     * using tasks.
     * @.pattern Fowler.SpecialValue
     * @since JWare/AntX 0.5
     **/
    public static final Object PENDING_REFERENCE= "__pending_ref__";


    /**
     * Returns a reference only if that reference has already been
     * determined by the project. This method tries to differentiate
     * references that are defined inside out-of-scope targets or
     * after this caller's location within the current target.
     * @param P the project used to lookup references (non-null)
     * @param id the reference id (non-null)
     * @throws IllegalArgumentException if either parameter is <i>null</i>
     * @return {@linkplain #IGNORED_REFERENCE} if reference out of scope<br/>
     *    {@linkplain #PROBLEM_REFERENCE} if unable to retrieve reference<br/>
     *    <i>null</i> if no such reference in project
     * @since JWare/AntX 0.4
     **/
    public static Object trueReference(Project P, String id)
    {
        AntX.require_(P!=null && id!=null, IAM_, "trueRef- nonzro args");

        Object ref=null;
        Object ht = P.getReferences();
        Boolean B=null;
        Method m=null;
        try {
            m = ht.getClass().getDeclaredMethod("getReal",GET_REAL_METHOD);
            B = m.isAccessible() ? Boolean.TRUE : Boolean.FALSE;
            m.setAccessible(true);
            ref = m.invoke(ht, new Object[]{id});
            if (ref instanceof UnknownElement) {
                ref = IGNORED_REFERENCE;
            }
        } catch(Exception reflectX) {
            P.log("Unable to call 'Project$AntRefTable.getReal': "+reflectX.getMessage());
            //Fallback: Public way
            try {
                ref = P.getReference(id);
            } catch(Exception lookupX) {
                P.log(lookupX.getMessage(), Project.MSG_WARN);
                ref = PROBLEM_REFERENCE;
            }
        } finally {
            if (m!=null && B!=null & !B.booleanValue()) {
                try {
                    m.setAccessible(false);
                } catch(Exception anyX) {
                    /*burp*/
                }
            }
        }
        return ref;
    }



    /**
     * Returns whether the referenced item exists, has been configured,
     * and can be read. Complement to {@linkplain #trueReference trueReference}.
     * @param P the project used to lookup references (non-null)
     * @param id the reference id (non-null)
     * @since JWare/AntX 0.5
     **/
    public static boolean usableReference(Project P, String id)
    {
        Object ref = trueReference(P,id);
        if (ref==IGNORED_REFERENCE || ref==PROBLEM_REFERENCE
            || ref==PENDING_REFERENCE) {
            ref= null;
        }
        return ref!=null;
    }



    /**
     * Utility to convert a property source to a set of properties.
     * @param domain source of properties (non-null)
     * @param P [optional] project from which properties read (if needed)
     * @throws IllegalArgumentException if domain is <i>null</i>
     * @throws NullPointerException if project needed and not defined
     * @since JWare/AntX 0.4
     **/
    public static Map copyOfProperties(PropertySource domain, Project P)
    {
        AntX.require_(domain!=null,IAM_,"getProps- nonzro domain");

        Map mp=null;//shutup-compiler

        switch (domain.getIndex()) {
            case PropertySource.ALL_INDEX:
            case PropertySource.ALLlite_INDEX: {
                mp = P.getProperties();
                if (domain.getIndex()!=PropertySource.ALL_INDEX) {
                    removeImmutableJavaProperties(mp);
                }
                break;
            }
            case PropertySource.COMMAND_INDEX: {
                mp = P.getUserProperties();
                break;
            }
            case PropertySource.CONTROL_INDEX: {
                Project dumi= new Project();
                P.copyInheritedProperties(dumi);
                mp = dumi.getProperties();
                dumi = null;//gc
                break;
            }
            case PropertySource.SCRIPTlite_INDEX:
            case PropertySource.SCRIPT_INDEX: {
                //NB:inherited properties are also user properties!
                mp = P.getProperties();
                mp.keySet().removeAll(P.getUserProperties().keySet());
                if (domain.getIndex()!=PropertySource.SCRIPT_INDEX) {
                    removeImmutableJavaProperties(mp);
                }
                break;
            }
            case PropertySource.FIXTURE_INDEX: {
                mp = AntXFixture.copyOfProperties();
                break;
            }
            case PropertySource.JRE_INDEX: {
                mp = (Map)System.getProperties().clone();
                break;
            }
            default: {
                AntX.verify_(false,IAM_,"init- known domain");
            }
        }

        return mp;
    }


    /**
     * Given a non-null datatype instance, will try to return the
     * data type's name. Will return simple classname if unable to 
     * determine element name from Ant.
     * @param type data type instance to evaluate (non-null)
     * @param project [optional] source project to work against
     * @return data type's name
     * @since JWare/AntXtras 3.0.0
     **/
    public static String getTypeName(Object type, Project project)
    {
        AntX.require_(type!=null,IAM_,"getTypName- nonnull type");
        String name = null;
        try { name = ComponentHelper.getElementName(project,type,true);
        } catch(RuntimeException anyX) { /*burp*/ }
        if (name==null) {
            name = type.getClass().getSimpleName();
        }
        return name;
    }



    private static final Class[]  SIG_GET_DELEGATES= {Class.class};
    private static final Class[]  SIG_GET_INTERFACE= {Delegate.class};

    
    /**
     * Unmasks the delegated-to PropertyHelper for a AntXtras-based
     * wrapper helper. Needed if you need to get to the "real" helper
     * that is tracking things like properties, delegates, etc.
     * @param ph property helper to unwrap (non-null)
     * @return "real" property helper (or input if it's not installed)
     * @since JWare/AntXtras 3.0.0
     **/
    public static final PropertyHelper unwrap(PropertyHelper ph)
    {
        PropertyHelper phFinal = ph;
        if (ph instanceof PropertyHelperWrap) {
            boolean eol=false;
            do {
                PropertyHelperWrap phW = (PropertyHelperWrap)ph;
                if (phW.isInstalled()) {
                    phFinal = phW.getReplacedHelper();
                    if (phFinal instanceof PropertyHelperWrap) {
                        ph = phFinal;
                    } else {
                        eol = true;
                    }
                } else {
                    eol = true;
                }
            } while(!eol);
        }
        return phFinal;
    }


    /**
     * Returns the delegates of a given type installed under a property helper.
     * Needed because this information is not easily obtained from helper api.
     * @param ph the helper to check (non-null)
     * @param type interface of delegates to return (non-null)
     * @return collection of delegates of named type or the empty set
     * @since JWare/AntXtras 3.0.0
     **/
    public static final Collection getDelegatesOfType(PropertyHelper ph, Class type)
    {
        Object[] args = {type};
        Collection c = Collections.EMPTY_LIST;
        try { c = (Collection)Tk.invokeit(unwrap(ph),"getDelegates",SIG_GET_DELEGATES,args);
        } catch(Exception e) { /*burp*/ }
        return c;
    }


    /**
     * Returns the evaluators installed under a given property helper.
     * @param ph the helper to check (non-null)
     * @return collection of evaluators or the empty set
     * @since JWare/AntXtras 3.0.0
     **/
    public static final Collection getEvaluators(PropertyHelper ph)
    {
        return getDelegatesOfType(ph,PropertyHelper.PropertyEvaluator.class);
    }


    /**
     * Returns all of the Delegate-derived interfaces a particular delegate
     * instance implements. Used for uninstallation of delegates.
     * @param ph the helper to check (non-null)
     * @param delegate interface of delegates to return (non-null)
     * @return collection of delegates or the empty set
     * @since JWare/AntXtras 3.0.0
     **/
    public static final Collection getDelegateInterfaces(PropertyHelper ph, Delegate delegate)
    {
        Object[] args = {delegate};
        Collection c = Collections.EMPTY_SET;
        try { c = (Collection)Tk.invokeit(unwrap(ph),"getDelegateInterfaces",SIG_GET_INTERFACE,args);
        } catch(Exception e) { /*burp*/ }
        return c;
    }


    /**
     * Utility to remove a delegate from the given property helper.
     * This is a bit hairy because the Ant framework lets you install
     * delegates -- but does not let you remove them. This is ungood
     * for how we use delegates (evaluators/setters) with scoped 
     * tasksets, so we remove things using brute force. If no specific
     * helper is defined, this method will use the currently installed
     * helper for the caller's project.
     * @param ph [optional] PropertyHelper to be updated (non-null)
     * @param delegate delegate to be removed (non-null)
     * @param calr caller information (non-null)
     * @return the number of type sets from which delegate removed
     * @since JWare/AntXtras 3.0.0
     **/
    public static final int unsetDelegate(PropertyHelper ph, final Delegate delegate, Requester calr)
    {
        if (ph==null) {
            ph = PropertyHelper.getPropertyHelper(calr.getProject());
        }
        ph = unwrap(ph);
        int removedCount = 0;
        try {
            Map delegates = (Map)Tk.readField(PropertyHelper.class,ph,"delegates");
            synchronized(delegates) {
                Collection types = getDelegateInterfaces(ph,delegate);
                for (Iterator typesItr=types.iterator();typesItr.hasNext();) {
                    Object ofType = typesItr.next();
                    List list = (List)delegates.get(ofType);
                    if (list!=null && !list.isEmpty()) {
                        boolean ofTypeRemoved=false;
                        List editedList = AntXFixture.newList(list.size());
                        for (Iterator objItr=list.iterator();objItr.hasNext();) {
                            Delegate test = (Delegate)objItr.next();
                            if (test==delegate) {
                                ofTypeRemoved = true;
                                removedCount++;
                            } else {
                                editedList.add(test);
                            }
                        }
                        if (ofTypeRemoved) {
                            delegates.put(ofType,Collections.unmodifiableList(editedList));
                        }
                    }
                }//foreach-ofType
            }//lock
        } catch(Exception anyX) {
            calr.problem(anyX.getMessage(),Project.MSG_ERR);
            throw new BuildException(anyX,calr.getLocation());
        }
        return removedCount;
    }



    /**
     * Utility to create a snapshot of the current thread's &lt;local&gt;
     * scope stack; this is <em>not</em> an independent copy of the  
     * underlying local maps that track the values for each scope. So if
     * a change occurs to a particular scope, the changes are reflected
     * in the returned copy. However, new scopes (added after this method
     * returns) are not shown by this stack.
     * @param fromPH source helper (or null for currently installed one)
     * @param calr calling component (non-null)
     * @return copy of locals stack reference (non-null)
     * @since JWare/AntXtras 3.0.0 copyLocalStackLite  
     **/
    public static final LocalPropertyStack litecopyOfLocals(PropertyHelper fromPH, Requester calr)
    {
        LocalPropertyStack lps = null;
        if (fromPH==null) {
            fromPH = PropertyHelper.getPropertyHelper(calr.getProject());
        }
        lps = (LocalPropertyStack)LocalProperties.get(fromPH.getProject()).get();
        lps = lps.copy();
        return lps;
    }



    /**
     * Returns the current thread's &lt;local&gt; stack. Never returns
     * <i>null</i>; can cause the stack to be created for the thread. 
     * @param fromPH master project for the thread (non-null)
     * @return the current (even if new) local stack (never <i>null</i>)
     **/
    public static final LocalPropertyStack currentLocals(PropertyHelper fromPH)
    {
        return (LocalPropertyStack)LocalProperties.get(fromPH.getProject()).get();
    }



    /**
     * Returns the local scope (as a Map) against which the named 
     * property is resolved or <i>null</i> if there are no locals in
     * the given stack with that name.
     * @param lps the locals stack to check (non-null)
     * @param property the property name to check (non-null)
     * @param calr calling component (non-null)
     * @return controlling local scope or <i>null</i> if no match found
     * @since JWare/AntXtras 3.0.0
     **/
    public static final Map findLocalScope(LocalPropertyStack lps, String property, Requester calr)
    {
        try {
            List stack = (List)Tk.readField(LocalPropertyStack.class,lps,"stack");
            for (ListIterator itr=stack.listIterator();itr.hasNext();) {
                Map next = (Map)itr.next();
                if (next.containsKey(property)) {
                    return next;
                }
            }
        } catch(Exception anyX) {
            calr.problem(anyX.getMessage(),Project.MSG_ERR);
            throw new BuildException(anyX,calr.getLocation());
        }
        return null;
    }



    /**
     * Removes the "classic" immutable java runtime properties
     * including anything that begins with "java&#46;", 
     * "javax&#46;", and "sun&#46;".
     * @throws UnsupportedOperationException if
     *         <span class="src">map</span> is a readonly map.
     * @since JWare/AntX 0.4
     **/
    public static void removeImmutableJavaProperties(Map map)
    {
        AntX.require_(map!=null,IAM_,"zapSystemProps- nonzro map");

        Iterator itr= map.keySet().iterator();
        while (itr.hasNext()) {
            String s = itr.next().toString();
            if (s.startsWith("java.") 
                 || s.startsWith("javax.") 
                 || s.startsWith("sun.")) {
                itr.remove();
                continue;
            }
            for (int i=0;i<KEEPERS.length;i++) {
                if (KEEPERS[i].equals(s)) {
                    itr.remove();
                    continue;
                }
            }
        }
    }



    /**
     * Always look for these; do not allow them to be
     * removed in custom list.
     **/
    private static final String[] KEEPERS= {
        "os.name",   "os.arch",   "os.version",
        "user.name", "user.home", "user.dir",
        "user.language", "user.timezone", "user.country", "user.variant",
        "file.separator", "path.separator",
        "line.separator"
    };




    private static final Class[] GET_REAL_METHOD= {Object.class};


    /** Only permit generic utility methods. **/
    private FixtureExaminer()
    {
    }
}

/* end-of-FixtureExaminer.java */
