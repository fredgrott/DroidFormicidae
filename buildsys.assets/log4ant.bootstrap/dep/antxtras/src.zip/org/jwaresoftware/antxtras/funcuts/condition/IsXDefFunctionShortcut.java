/**
 * $Id: IsXDefFunctionShortcut.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.apache.tools.ant.taskdefs.condition.TypeFound;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns "true" or "false" depending on 
 * whether the named Ant component is already defined AND usable. This handler 
 * works for any Ant type (taskdef or typedef). The general form of 
 * the URI: <span class="src">$istype:<nobr>typename[?uri]</nobr></span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;do if="emma.present" false="${$istask:emma}"&gt;
 *     <i>[&#8230;Install emma task here]</i>
 *    &lt;/do&gt;
 * <b>2)</b> &lt;do if="emma.present" false="${$istask:emma?ext}"&gt;
 *     <i>[&#8230;Install emma task here]</i>
 *    &lt;/do&gt;
 *
 * <b>3)</b> -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="istask"
 *          value="${ojaf}.condition.IsXDefFunctionShortcut"/&gt;
 *     &lt;parameter name="istype"
 *          value="${ojaf}.condition.IsXDefFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @since     JWare/AntXtras 3.5.0 updated to ensure the type is actually
 *            loadable within current Ant context (leverages new typefound)
 **/

public final class IsXDefFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initalizes a new type check function shortcut.
     **/
    public IsXDefFunctionShortcut()
    {
        super();
    }


    /**
     * Returns "true" if the named item is already defined 
     * in the current Ant type system.
     * @since JWare/AntXtras 3.5.0 added support for uri after '?'
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String uri = null;
        String typename = uriFragment;
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            typename = uriFragment.substring(0,i);
            uri = uriFragment.substring(i+SCHEME_DELIMITER_LEN);
        }
        TypeFound test = new TypeFound();
        test.setProject(clnt.getProject());
        test.setURI(uri);
        test.setName(typename);
        return String.valueOf(test.eval());
    }
}

/* end-of-IsXDefFunctionShortcut.java */