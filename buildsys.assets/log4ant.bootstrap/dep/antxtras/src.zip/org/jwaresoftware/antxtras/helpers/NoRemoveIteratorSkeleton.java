/**
 * $Id: NoRemoveIteratorSkeleton.java 390 2008-03-30 17:51:32Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.util.Iterator;

/**
 * Starter Iterator implementation that throws
 * <span class="src">UnsupportedOperationException</span> for
 * <span class="src">{@linkplain #remove remove()}</span> method.
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public abstract class NoRemoveIteratorSkeleton implements Iterator
{
    /**
     * Initializes a new iterator.
     **/
    protected NoRemoveIteratorSkeleton()
    {
    }



    /**
     * Unconditionally barfs with an
     * <span class="src">UnsupportedOperationException</span>.
     **/
    public void remove()
    {
        throw new UnsupportedOperationException();
    }
}

/* end-of-NoRemoveIteratorSkeleton.java */
