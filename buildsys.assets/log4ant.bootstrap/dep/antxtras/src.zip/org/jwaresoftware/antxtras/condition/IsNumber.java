/**
 * $Id: IsNumber.java 1504 2012-09-22 23:30:22Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Simple Is-Number condition check. IsNumbern handle any number
 * up to Long.MAX_VALUE which means it can be used for timestamps as
 * well as simpler (smaller) numbers.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;isnumber value="${build.number}"/&gt;
 *   &lt;isnumber property="build.ITID"/&gt;
 *
 *   &lt;isnumber variable="_loop.count"/&gt;
 *   &lt;isnumber variable="_try.count" gte="0" lt="3"/&gt;
 *
 *   &lt;isnumber variable="_totaltime" gte="0"/&gt;
 *</pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 **/

public class IsNumber extends SimpleFlexCondition
{
    /** Constant used to signal string value that condition could not parse. **/
    public static final long NO_VALUE=Long.MIN_VALUE;


    /**
     * Initializes a new IsNumeric condition.
     **/
    public IsNumber()
    {
        super();
    }


    /**
     * Creates defined condition.
     * @param value the value against which condition checks
     **/
    public IsNumber(String value)
    {
        setValue(value);
    }


    /**
     * Sets this condition to evaluate a literal value as-is.
     * @param value the literal value to check
     **/
    public void setValue(String value)
    {
        require_(value!=null,"setValu- nonzro");
        setLiteral(value);
    }


    /**
     * Sets a "greater-than" limit requirement on checked
     * value.
     **/
    public void setGT(long gt)
    {
        m_GT = gt;
        m_isLimited = true;
    }


    /**
     * Sets a "greater-than-or-equal" limit requirement on
     * checked value.
     **/
    public void setGTE(long gte)
    {
        m_GTE = gte;
        m_isLimited = true;
    }


    /**
     * Sets a "less-than" limit requirement on checked
     * value.
     **/
    public void setLT(long lt)
    {
        m_LT = lt;
        m_isLimited = true;
    }


    /**
     * Sets a "less-than-or-equal" limit requirement on checked
     * value.
     **/
    public void setLTE(long lte)
    {
        m_LTE = lte;
        m_isLimited = true;
    }


    /**
     * Returns <i>true</i> if this condition's value is a valid
     * number (and optionally within a specified range).
     **/
    public boolean eval()
    {
        String value = getValueHelper().getValue();

        long l= Tk.longFrom(value,NO_VALUE);

        boolean ok = l!=NO_VALUE;

        if (ok && m_isLimited) { //painful to look at but it works
            if (m_GTE!=NO_VALUE) {
                if (l<m_GTE) {
                    return false;
                }
            }
            if (m_GT!=NO_VALUE) {
                if (l<=m_GT) {
                    return false;
                }
            }
            if (m_LTE!=NO_VALUE) {
                if (l>m_LTE) {
                    return false;
                }
            }
            if (m_LT!=NO_VALUE) {
                if (l>=m_LT) {
                    return false;
                }
            }
        }

        return ok;
    }


    private boolean m_isLimited;
    private long m_GTE=NO_VALUE,m_GT=NO_VALUE;
    private long m_LTE=NO_VALUE,m_LT=NO_VALUE;
}

/* end-of-IsNumber.java */
