/**
 * $Id: AllSetTrue.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Slight variant of {@linkplain AllSet} that requires all named items to contain
 * (or refer to) a positive boolean value. Exists to help inlined value URIs be more
 * selective.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 **/

public final class AllSetTrue extends CheckSetCondition implements URIable
{
    /**
     * Initializea a new all set true condition.
     **/
    public AllSetTrue()
    {
        super(AntX.rules+"AllSetTrue");
        setTruesOnly();
    }



    /**
     * Initializes a filled in AllSetTrue instance.
     * @param properties comma-delimited list of properties
     * @param project condition's project
     **/
    public AllSetTrue(String properties, final Project project)
    {
        super(AntX.rules+"AllSetTrue");
        setProject(project);
        setProperties(properties);
    }



    /**
     * Sets this condition's list of properties as part of
     * a value URI.
     * @param fragment the value uri bits (non-null)
     */
    public void xsetFromURI(String fragment)
    {
        xsetFromURIFragment(fragment);
    }
}

/* end-of-AllSetTrue.java */