/**
 * $Id: LogEnabled.java 808 2009-08-30 16:47:21Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;

import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * Mixin interface for an object that supports the two standard Ant log APIs.
 * Within AntXtras mostly used indirectly through a {@linkplain Requester}
 * object.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   n/a
 * @.group    api,infra
 * @.pattern  GoF.Strategy
 * @see       Requester
 * @see       ProblemHandler
 **/

public interface LogEnabled
{
    /**
     * Should do whatever this object does to record a
     * diagnostic message.
     * @param message the message (non-null)
     **/
    void log(String message);



    /**
     * Should do whatever this object does to record either a
     * problem or a diagnostic message. (The type or severity of
     * message is indicated by the accompanying noise level.)
     * @param message the message (non-null)
     * @param msgLevel the <em>Ant</em> noise level
     **/
    void log(String message, int msgLevel);



    /**
     * Default {@linkplain LogEnabled} adapter for the System consoles.
     * @since    JWare/AntX 0.5
     **/
    public static final LogEnabled SYSTEM= new LogEnabled() {
        public void log(String message) {
            SystemFixture.putout("",message);
        }
        public void log(String message, int msgLevel) {
            if (msgLevel<Project.MSG_INFO) {
                SystemFixture.puterr(LevelToLabel.get(msgLevel),message);
            } else {
                SystemFixture.putout(LevelToLabel.get(msgLevel),message);
            }
        }
    };



    /**
     * Default {@linkplain LogEnabled} adapter for a generic Ant
     * project component. Use this adapter to pass non AntX-based items
     * into AntX APIs.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.group   impl,helper
     **/
    public static class ForComponent implements LogEnabled
    {
        final ProjectComponent m_PC;

        /**
         * Initializes a new adapter for given project component.
         * @param pc the component being wrapped (non-null)
         * @throws IllegalArgumentException if component is <i>null</i>
         */
        public ForComponent(ProjectComponent pc) {
            if (pc==null) {
                throw new IllegalArgumentException();
            }
            this.m_PC = pc;
        }

        public void log(String message) {
            m_PC.log(message);
        }

        public void log(String message, int msgLevel) {
            m_PC.log(message,msgLevel);
        }
        /** Returns the underlying component for this adapter. **/
        public final ProjectComponent getImpl() {
            return m_PC;
        }
    }




    /**
     * Default {@linkplain LogEnabled} adapter for a utility class. If
     * at call time the utility's project is <i>null</i> this adapter will
     * delegate to one of the two {@linkplain #SYSTEM system} consoles.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.group   impl,helper
     **/
    public static class ForUtility implements LogEnabled
    {
        final ProjectDependent m_utility;

        /**
         * Initializes a new adapter for given project component.
         * @param utility the utility object being wrapped (non-null)
         * @throws IllegalArgumentException if utility is <i>null</i>
         */
        public ForUtility(ProjectDependent utility) {
            if (utility==null) {
                throw new IllegalArgumentException();
            }
            this.m_utility = utility;
        }

        public void log(String message) {
            if (m_utility.getProject()!=null) {
                m_utility.getProject().log(message);
            } else {
                SYSTEM.log(message);
            }
        }

        public void log(String message, int msgLevel) {
            if (m_utility.getProject()!=null) {
                m_utility.getProject().log(message,msgLevel);
            } else {
                SYSTEM.log(message,msgLevel);
            }
        }
        /** Returns the underlying utility for this adapter. **/
        public final ProjectDependent getImpl() {
            return m_utility;
        }
    }



    /**
     * Default {@linkplain LogEnabled} adapter for a generic Ant
     * project. Use this adapter to pass request-based project references
     * into AntX APIs. To facilitate utilities that allow <i>null</i>
     * projects, this adapter will use one of the two
     * {@linkplain #SYSTEM system} consoles if the incoming project is <i>null</i>.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.group   impl,helper
     **/
    public static class ForProject implements LogEnabled
    {
        final Project m_project;

        /**
         * Initializes a new adapter for given project.
         * @param project the project being wrapped (can be <i>null</i>)
         */
        public ForProject(Project project) {
            this.m_project = project;
        }

        public void log(String message) {
            if (m_project!=null) {
                m_project.log(message);
            } else {
                SYSTEM.log(message);
            }
        }

        public void log(String message, int msgLevel) {
            if (m_project!=null) {
                m_project.log(message,msgLevel);
            } else {
                SYSTEM.log(message,msgLevel);
            }
        }

        /**
         * Always returns <i>null</i> or the project bound at
         * creation time. Can be <i>null</i>.
         * @since JWare/AntXtras 2.0.0
         **/
        public final Project getProject() {
            return m_project;
        }

        /**
         * Returns the underlying source for this adapter.
         * We return {@linkplain #getProject the project}.
         **/
        public Object getImpl() {
            return getProject();
        }
    }
}

/* end-of-LogEnabled.java */
