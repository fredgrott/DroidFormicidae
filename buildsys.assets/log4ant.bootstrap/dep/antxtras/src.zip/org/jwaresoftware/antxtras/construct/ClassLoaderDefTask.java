/**
 * $Id: ClassLoaderDefTask.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.AntClassLoader;
import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;
import  org.apache.tools.ant.util.ClasspathUtils;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.OptionalOverwriteSupport;

/**
 * Utility to explicitly define a classloader for your components that defers some
 * loading to another loader (named as its parent). This helper is used to setup
 * class loading dependencies between AntXtras/Foundation and other packages that
 * derive from it like SAMS, Svn4Ant, and AntUnit.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;taskdef resource="org/jwaresoftware/sams/antlib.xml"
 *     loaderref="sams.loader"&gt;
 *     &lt;classpath id="sams.path"&gt;
 *       &lt;fileset dir="${tools}" includes="antxtras/lib/*.jar,sams/lib/*.jar"/&gt;
 *     &lt;/classpath&gt;
 *   &lt;/taskdef&gt;
 *   &lt;<b>classloaderdef</b> name="antunit.loader" parent="sams.loader"&gt;
 *     &lt;classpath id="antunit.path"&gt;
 *       &lt;fileset dir="${tools}" includes="antunit/lib/*.jar"/&gt;
 *     &lt;/classpath&gt;
 *     &lt;defer packages="org.jwaresoftware.internal"/&gt;
 *     &lt;defer packages="org.jwaresoftware.antxtras"/&gt;
 *     &lt;defer packages="org.jwaresoftware.sams"/&gt;
 *   &lt;/classloaderdef&gt;
 *   &lt;taskdef resource="org/jwaresoftware/antunit/antlib.xml"
 *     loaderref="antunit.loader"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.6.0
 * @author   ssmc, &copy;2006-2008,2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/
public final class ClassLoaderDefTask extends AssertableTask
    implements OptionalOverwriteSupport
{
    /**
     * Instruction that controls whether all classes under a particular package
     * hierarchy is automatically passed to a classloader's parent loader or
     * never passed to the parent.
     *
     * @since    JWare/AntX 0.6.0
     * @author   ssmc, &copy;2006 <a href="http://antxtras.sf.net/">iDare&nbsp;Media,&nbsp;Inc.</a>
     * @version  3.5.0b2
     * @see      org.apache.tools.ant.AntClassLoader#addSystemPackageRoot AntClassLoader.addSystemPackageRoot
     * @see      org.apache.tools.ant.AntClassLoader#addLoaderPackageRoot AntClassLoader.addLoaderPackageRoot
     **/
    public final class PackageInstruction
    {
        /** Initializes a new package loader instruction.
         * @param deferral <i>true</i> if this is a defer instruction.
         **/
        public PackageInstruction(boolean deferral)
        {
            super();
            m_deferral = deferral;
        }
        /** Sets the package hierarchies to passthru or block.
         *  @param names comma-delimited list of package prefixes.
         **/
        public void setPackages(String names)
        {
            if (names!=null) {
                names = names.trim();
            }
            if (Tk.isWhitespace(names) || ".".equals(names)) {
                String error = AntX.uistrs().get(Errs.TIPV,getTaskName(),names,"defer/packages");
                log(error,Project.MSG_ERR);
                throw new BuildException(error);
            }
            m_packagenames = names;
        }
        /** Verifies that at least one packages has been defined. **/
        void verifyNamed(Requester rqlink)
        {
            if (m_packagenames==null) {
                String error = AntX.uistrs().get(Errs.TNTA,getTaskName(),"defer/packages");
                log(error,Project.MSG_ERR);
                throw new BuildException(error,getLocation());
            }
        }
        /** Adds our packages to a class loader's me-only or parent-only list. **/
        void apply(AntClassLoader cl)
        {
            Iterator itr = LocalTk.splitList(m_packagenames,getProject()).iterator();
            while (itr.hasNext()) {
                String packagename = (String)itr.next();
                if (m_deferral) {
                    cl.addSystemPackageRoot(packagename);
                } else {
                    cl.addLoaderPackageRoot(packagename);
                }
            }
        }

        private String m_packagenames;
        private final boolean m_deferral;
    }

//  ---------------------------------------------------------------------------------------
//  Construction:
//  ---------------------------------------------------------------------------------------

    /**
     * Initializes a new classloader definition task.
     **/
    public ClassLoaderDefTask()
    {
        super(AntX.construct+"ClassLoaderDefTask:");
    }


//  ---------------------------------------------------------------------------------------
//  Script-facing Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Set the target reference's identifier (non-null)
     * @param dstRefId reference id to install data under (non-null)
     * @see #setHaltIfExists setHaltIfExists(&#8230;)
     **/
    public void setName(String dstRefId)
    {
        require_(dstRefId!=null, "setName- nonzro refid");
        m_dstRefId = dstRefId;
    }



    /**
     * Defines the parent of this classloader by reference. This
     * reference must exist in current project.
     * @param ref reference to an existing class loader.
     **/
    public void setParent(Reference ref)
    {
        require_(ref!=null,"setParent- nonzro refid");
        m_parentRef = ref;
    }



    /**
     * Sets whether parent class loader should be tried first. Used
     * for debugging and test scripts; rarely used in regular build
     * scripts.
     * @param first <i>false</i> if parent should be tried after me.
     **/
    public void setParentFirst(boolean first)
    {
        m_parentFirstFlag = Boolean.valueOf(first);
    }



    /**
     * Creates a new nested defer element. The new element's
     * packages parameter must be defined for it to be used.
     * @return new defer element (never <i>null</i>)
     **/
    public PackageInstruction createDefer()
    {
        PackageInstruction d = new PackageInstruction(true);
        m_packageInstructions.add(d);
        return d;
    }



    /**
     * Creates a new nested force element. The new element's
     * packages parameter must be defined for it to be used.
     * @return new defer element (never <i>null</i>)
     **/
    public PackageInstruction createForce()
    {
        PackageInstruction d = new PackageInstruction(false);
        m_packageInstructions.add(d);
        return d;
    }



    /**
     * Defines this classloader's own lookup path as a nested class
     * path element. (Only one classpath is defined but it can
     * be split into multiple sub-path elements.)
     * @return new loader classpath element (never <i>null</i>)
     **/
    public Path createClasspath()
    {
        return getDelegate().createClasspath();
    }



    /**
     * Defines this loader's classpath as a reference to another
     * existing path element. If a loader name is not explicitly
     * set, we will use "ant&#46;loader&#46;<i>&lt;classpathref&gt;</i>".
     * @param ref the path element (non-null)
     **/
    public void setClasspathRef(Reference ref)
    {
        getDelegate().setClasspathref(ref);
        if (m_dstRefId==null) {
            String aln = "ant.loader."+ref.getRefId();
            m_dstRefId = aln;
        }
    }



    /**
     * Defines this loader's classpath as a inlined path string.
     * @param classpath the classpath string (non-null)
     **/
    public void setClasspath(Path classpath)
    {
        getDelegate().setClasspath(classpath);
    }



    /**
     * Tells this task whether is should signal an error if a loader
     * with id same as our name already exists. Defaults to no.
     **/
    public void setHaltIfExists(boolean halt)
    {
        m_haltIfExists = halt ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this task's haltifexists flag. Will return <i>null</i>
     * if this option has not be defined explicitly.
     **/
    public Boolean getHaltIfExistsFlag()
    {
        return m_haltIfExists;
    }



    /**
     * Tells this task whether is should silently abort if a loader
     * with id same as our name already exists. Defaults to no; ignored
     * if {@linkplain #setHaltIfExists(boolean) haltifexists} option
     * is enabled.
     **/
    public void setOverwrite(boolean allow)
    {
        m_allowOverwrite = allow ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this task's overwrite flag. Will return <i>null</i>
     * if this option has not be defined explicitly.
     **/
    public Boolean getOverwriteFlag()
    {
        return m_allowOverwrite;
    }


//  ---------------------------------------------------------------------------------------
//  Execution:
//  ---------------------------------------------------------------------------------------

    /**
     * Verifies that we have a name, a parent loader, and a non-empty
     * classpath defined. Also checks for existing references against our
     * 'haltifexists' setting.
     * @throws BuildException if any of our required parameters are
     *         missing or invalid.
     * @throws BuildException if a nested package instruction is incomplete.
     * @throws BuildException if an object already exists with our target
     *         name and our haltifexists option is enabled.
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        String need=null;

        if (m_dstRefId==null) {
            need = "name";
        } else if (m_parentRef==null) {
            need = "parent";
            if (m_cpDelegate==null) {
                need = "parent and classpath";
            }
        } else if (m_cpDelegate==null) {
            need = "classpath";
        }
        if (need!=null) {
            String error = uistrs().get(Errs.TNTA,getTaskName(),need);
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }

        boolean halt = (m_haltIfExists==null) ? false : m_haltIfExists.booleanValue();
        checkIfReference_(m_dstRefId,!halt);

        getReferencedObject(getProject(),m_parentRef.getRefId(),ClassLoader.class);

        if (!m_packageInstructions.isEmpty()) {
            Iterator itr = m_packageInstructions.iterator();
            Requester rqlink = new Requester.ForComponent(this);
            while (itr.hasNext()) {
                ((PackageInstruction)itr.next()).verifyNamed(rqlink);
            }
        }
    }



    /**
     * Factory method for our classloader. The returned loader's deferral
     * list still needs to be updated and the classloader installed.
     * @param P associated project (non-null)
     * @return new Ant class loader (never <i>null</i>)
     **/
    private AntClassLoader newClassLoader(final Project P)
    {
        AntClassLoader cl = (AntClassLoader)m_cpDelegate.getClassLoader();
        cl.setParent((ClassLoader)P.getReference(m_parentRef.getRefId()));

        if (m_parentFirstFlag!=null/*explicitly-set*/) {
            boolean contra = !m_parentFirstFlag.booleanValue();
            cl.setParentFirst(!contra);
            if (contra) {
                cl.addJavaLibraries();
            }
        }
        cl.addSystemPackageRoot("org.apache.tools.ant");
        return cl;
    }



    /**
     * Tries to create and install a custom classloader into this task's
     * owning project.
     * @throws BuildException if
     *          {@linkplain #verifyCanExecute_(String) verifyCanExecute} does
     *          or unable to create loader for any reason.
     **/
    public void execute()
    {
        verifyCanExecute_("exec");

        final Project myproject = getProject();

        if (m_allowOverwrite==Boolean.FALSE) {
            Object there = myproject.getReference(m_dstRefId);
            if (there!=null && there!=FixtureExaminer.PENDING_REFERENCE) {
                return;
            }
        }

        AntClassLoader cl = newClassLoader(myproject);
        if (!m_packageInstructions.isEmpty()) {
            Iterator itr = m_packageInstructions.iterator();
            while (itr.hasNext()) {
                PackageInstruction passthru = (PackageInstruction)itr.next();
                passthru.apply(cl);
            }
        }
        myproject.addReference(m_dstRefId,cl);
    }


    private ClasspathUtils.Delegate getDelegate()
    {
        if (m_cpDelegate==null) {
            m_cpDelegate = ClasspathUtils.getDelegate(this);
        }
        return m_cpDelegate;
    }

    private String m_dstRefId;
    private Reference m_parentRef;
    private List m_packageInstructions = AntXFixture.newList();
    private ClasspathUtils.Delegate m_cpDelegate;
    private Boolean m_parentFirstFlag;
    private Boolean m_haltIfExists, m_allowOverwrite;
}


/* end-of-ClassLoaderDefTask.java */
