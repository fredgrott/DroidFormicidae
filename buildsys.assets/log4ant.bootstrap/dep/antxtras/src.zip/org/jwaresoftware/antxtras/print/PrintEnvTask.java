/**
 * $Id: PrintEnvTask.java 1510 2012-09-24 23:26:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.IOException;
import  java.io.OutputStream;
import  java.io.PrintStream;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Condition;
import  org.apache.tools.ant.types.Path;

import  org.jwaresoftware.antxtras.behaviors.FlexStringFriendly;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.parameters.PropertySource;
import  org.jwaresoftware.antxtras.starters.EchoThingTask;

/**
 * Helper task that displays properties, variables, etc. Also acts as a 
 * stub always 'true' condition to facilitate debugging of complex rules.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>printenv</b> property="ant.version"/&gt;
 *   &lt;<b>printenv</b> ref="tools.classpath"/&gt;
 *   &lt;<b>printenv</b> references="all" typename="path" pretty="yes"/&gt;
 *   &lt;<b>printenv</b> variables="all" properties="all" if="build.debug"/&gt;
 *
 * OR (Nested as a dud-condition for debugging):
 *
 *   &lt;tally trueproperty="blastoff"&gt;
 *       &lt;tally ruleid="..." trueproperty="a.present"/&gt;
 *       &lt;<b>print</b> properties="all" if="tally.debug"/&gt;
 *       &lt;tally trueproperty="a.present"&gt;
 *          &lt;.../&gt;
 *       &lt;/tally&gt;
 *       &lt;<b>print</b> property="a.present" if="tally.debug"/&gt;
 *       &lt;.../&gt;
 *   &lt;/tally&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2007-2009,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple (once configured)
 * @.group   impl,test,helper
 **/

public class PrintEnvTask extends EchoThingTask implements Condition, FlexValueSupport
{
    /**
     * Initializes a new PrintEnvTask instance.
     **/
    public PrintEnvTask()
    {
        super(AntX.starters);
    }


    /**
     * Initializes a new CV-labeled PrintEnvTask instance.
     * @param iam CV-label (non-null)
     **/
    protected PrintEnvTask(String iam)
    {
        super(iam);
    }


    /**
     * Initialize this task's project. Also auto-sets this task's
     * referenced thing to the name of the project if it has one.
     **/
    public void setProject(Project project)
    {
        super.setProject(project);

        if (project!=null && getThingRefId()==null) {
            String name = project.getName();
            if (name==null) {
                name = project.getProperty("ant.project.name");
            }
            if (name!=null) {
                setThingRefId(name);
            }
        }
    }


    /**
     * Sets the list of project properties to include in the output.
     * Use '<i>all</i>' to display all project properties. Use '<i>user</i>'
     * to display only user properties. Use a comma-delimited list for
     * specific properties.
     * @param nameList comma-delimited list of property names (non-null)
     **/
    public void setProperties(String nameList)
    {
        require_(nameList!=null,"setProps- nonzro list");
        m_propertiesList= nameList;
    }


    /**
     * Shortcut for setting a single property.
     **/
    public final void setProperty(String property)
    {
        setProperties(property);
    }


    /**
     * Returns list of project properties to be output. Returns
     * <i>null</i> if never set (nothing displayed).
     **/
    public final String getPropertiesNameList()
    {
        return m_propertiesList;
    }


    /**
     * Sets the by-prefix filter for echoed properties or variables.
     **/
    public void setPrefix(String prefix)
    {
        require_(prefix!=null && prefix.length()>0,"setPfx- valid str");
        m_prefix = prefix;
    }


    /**
     * Returns the by-prefix filter for echoed properties or variables.
     * Returns <i>null</i> if never set.
     **/
    public final String getPrefix()
    {
        return m_prefix;
    }


    /**
     * Sets the list of exported properties to include in the output.
     * Use '<i>all</i>' to display all exported properties. Use a
     * comma-delimited list for specific exported properties.
     * @param nameList comma-delimited list of variable names (non-null)
     **/
    public void setVariables(String nameList)
    {
        require_(nameList!=null,"setVars- nonzro list");
        m_variablesList= nameList;
    }


    /**
     * Shortcut for setting a single exported property.
     **/
    public final void setVariable(String variable)
    {
        setVariables(variable);
    }


    /**
     * Shortcut for setting a single exported property.
     **/
    public final void setVar(String variable)
    {
        setVariables(variable);
    }


    /**
     * Returns list of exported properties to be output. Returns
     * '<i>null</i>' if never set (nothing displayed).
     **/
    public final String getVariablesNameList()
    {
        return m_variablesList;
    }


    /**
     * Sets the list of project references to include in the output.
     * Use a comma-delimited list for specific references.
     * @param nameList comma-delimited list of references names (non-null)
     **/
    public void setReferences(String nameList)
    {
        require_(nameList!=null,"setRefs- nonzro list");
        m_refsList= nameList;
    }


    /**
     * Shortcut for setting a single reference.
     **/
    public final void setReference(String refid)
    {
        require_(refid!=null,"setRef- nonzro ref");
        setReferences(refid);
    }


    /**
     * Returns list of project references to be output. Returns
     * '<i>null</i>' if never set (nothing displayed).
     **/
    public final String getReferencesNameList()
    {
        return m_refsList;
    }


    /**
     * Sets the by-class filter for echoed references.
     **/
    public void setKindOf(Class claz)
    {
        require_(claz!=null,"setKindOf- nonzro claz");
        m_kindOfClass = claz;
    }


    /**
     * Sets the by-class filter for echoed references based 
     * on common Ant type name.
     * @param typename Ant type's name (non-null)
     * @since JWare/AntXtras 3.5.0
     **/
    public void setTypeName(String typename)
    {
        require_(typename!=null,"setType- nonzro type");
        Class wantedClass = 
            (Class)getProject().getDataTypeDefinitions().get(typename);
        if (wantedClass==null) {
            wantedClass = (Class)getProject().getTaskDefinitions().get(typename);
        }
        if (wantedClass!=null) {
            m_kindOfClass = wantedClass;
        }
    }


    /**
     * Returns the by-class filter for echoed references. Returns
     * <i>Object.class</i> if never set.
     **/
    public final Class getKindOfFilterClass()
    {
        return m_kindOfClass==null ? Object.class : m_kindOfClass;
    }


    /**
     * Sets whether reference printing will exclude out-of-scope
     * reference identifiers. Defaults <i>true</i> for backward
     * compatibility.
     * @since JWare/AntX 0.4
     **/
    public void setUnknowns(boolean yn)
    {
        m_includeUnknowns= yn;
    }


    /**
     * Returns <i>true</i> if this task will include to-be-determined
     * references in listings (true by default).
     * @since JWare/AntX 0.4
     **/
    public final boolean willIncludeUnknowns()
    {
        return m_includeUnknowns;
    }



    /**
     * Tells this printer to unmask string friendly reference instances.
     * @param yn <i>true</i> to unmask friend string references (on by default)
     * @since JWare/AntX 0.5.1
     **/
    public void setFriendlyStrings(boolean yn)
    {
        m_unmaskStringFriendly = yn;
    }



    /**
     * Return <i>true</i> if this task will output the string friendly
     * output from a 'StringFriendly' reference object.
     * @since JWare/AntX 0.5.1
     **/
    public boolean willUnmaskFriendlyStrings()
    {
        return m_unmaskStringFriendly;
    }


    /**
     * Tells this task whether to each pre-canned header strings
     * for each category of output (properties, variables, etc.)
     * @param flag <i>false</i> to disable header string
     * @since JWare/AntXtras 3.5.0
     **/
    public void setHeaders(boolean flag)
    {
        m_headers = flag;
    }


    /**
     * Tells this task whether to pretty print specific types 
     * (potentially in formats that ARE NOT PROPERTY FORMAT compatible).
     * Currently only done for pretty printing Ant paths.
     * @param flag <i>true</i> to enable custom pretty printing
     * @since JWare/AntXtras 3.5.0
     **/
    public final void setPretty(boolean flag)
    {
        m_prettyPrint = flag;
    }


    /**
     * Returns this task's project as the referenced thing.
     **/
    protected Object getReferencedThing(Class ofKind, String msgid)
    {
        return getProject();//that's-all-she-wrote
    }


    /**
     * Write the appropriate set of project properties to output stream.
     * @param P project from which properties read (non-null)
     * @param os output stream (non-null)
     * @see #setProperties
     * @return <i>true</i> if properties written
     * @throws IOException if any I/O error occurs on stream
     **/
    @SuppressWarnings("unused")
    protected boolean echoProperties(final Project P, PrintStream os)
        throws IOException
    {
        boolean touched=false;
        String list= getPropertiesNameList();
        if (!Tk.isWhitespace(list)) {

            Properties allP= new Properties();

            PropertySource domain= PropertySource.from(list);
            if (domain!=null) {
                allP.putAll(FixtureExaminer.copyOfProperties(domain,P));
                if (getPrefix()!=null) {//oye...
                    Iterator itr= allP.keySet().iterator();
                    while (itr.hasNext()) {
                        String key = itr.next().toString();
                        if (!key.startsWith(m_prefix)) {
                            itr.remove();
                        }
                    }
                }
            } else {
                List wanted = LocalTk.splitList(list,P);
                for (int i=0,N=wanted.size();i<N;i++) {
                    String key = (String)wanted.get(i);
                    allP.setProperty(key, String.valueOf(P.getProperty(key)));
                }
                wanted=null;
            }


            if (addHeaders()) {
                os.println(getAntXMsg("echo.label.properties"));
            }
            PropertiesPrinter.print(allP,os);

            allP.clear();
            allP=null;
            touched=true;
        }
        return touched;
    }


    /**
     * Write the appropriate set of exported properties to output stream.
     * @param P project information
     * @param os output stream (non-null)
     * @see #setVariables
     * @return <i>true</i> if at least one variable written
     * @throws IOException if any I/O error occurs on stream
     **/
    @SuppressWarnings("unused")
    protected boolean echoVariables(final Project P, PrintStream os)
        throws IOException
    {
        boolean touched=false;
        String list= getVariablesNameList();
        if (!Tk.isWhitespace(list)) {
            Properties allP;
            String ll= Tk.lowercaseFrom(list);

            if (Strings.ALL.equals(ll)) {
                allP= Variables.copy(null);
                if (getPrefix()!=null) {//oye...
                    Iterator itr= allP.keySet().iterator();
                    while (itr.hasNext()) {
                        String key = itr.next().toString();
                        if (!key.startsWith(m_prefix)) {
                            itr.remove();
                        }
                    }
                }
            } else {
                allP= Variables.copy(null);
                List wanted = LocalTk.splitList(list,P);
                allP.keySet().retainAll(wanted);
                if (wanted.size()>allP.size()) {//insert "null" strings
                    for (int i=0,N=wanted.size();i<N;i++) {
                        String key = (String)wanted.get(i);
                        if (allP.getProperty(key)==null) {
                            allP.setProperty(key,Strings.NULL);
                        }
                    }
                }
                wanted=null;
            }

            if (addHeaders()) {
                os.println(getAntXMsg("echo.label.variables"));
            }
            PropertiesPrinter.print(allP,os);

            allP.clear();
            allP=null;
            touched=true;
        }
        return touched;
    }



    /**
     * Returns a marker string for unresolved references (still unknown).
     **/
    protected final String unresolvedString(Project P, String key)
    {
        return P.getName()+":UnresolvedReference@"+key;
    }



    /**
     * Write the appropriate set of project references to output stream.
     * Uses each targeted reference's 'toString' method to generate output.
     * @param P project information
     * @param os output stream (non-null)
     * @see #setReferences
     * @return <i>true</i> if at least one reference written
     * @throws IOException if any I/O error occurs on stream
     * @since AntXtras/3.5.0 added special display format for filtered Paths
     **/
    @SuppressWarnings("unused")
    protected boolean echoReferences(final Project P, PrintStream os)
        throws IOException
    {
        boolean touched=false;
        String list= getReferencesNameList();
        if (!Tk.isWhitespace(list)) {

            Properties allP= new Properties();

            Iterator keysitr;
            if (Strings.ALL.equals(Tk.lowercaseFrom(list))) {
                keysitr= P.getReferences().keySet().iterator(); //?MT-safe..copy?
            } else {
                keysitr= LocalTk.splitList(list,P).iterator();
            }
            final boolean unmask = willUnmaskFriendlyStrings();
            while (keysitr.hasNext()) {
                String key = (String)keysitr.next();

                Object object = FixtureExaminer.trueReference(P,key);//@since AntX 0.4
                if (object==FixtureExaminer.IGNORED_REFERENCE) {
                    if (!willIncludeUnknowns()) {
                        continue;
                    }
                    object = unresolvedString(P,key);
                }
                if (m_kindOfClass==null/*allowAll*/ || object==null/*passthru*/ ||
                    (m_kindOfClass.isInstance(object))) {
                    String valuestring=null;
                    if (unmask && (object instanceof FlexStringFriendly)) {
                        valuestring = ((FlexStringFriendly)object).stringFrom(P);
                    } else {
                        valuestring = Tk.stringFrom(object,P);
                    }
                    allP.setProperty(key, valuestring);
                }
            }

            if (addHeaders()) {
                os.println(getAntXMsg("echo.label.references"));
            }
            if (unmask && m_kindOfClass==Path.class && m_prettyPrint) {
                PathPrinter.print(allP,os);
            } else {
                PropertiesPrinter.print(allP,os);
            }

            allP.clear();
            allP=null;
            touched=true;
        }
        return touched;
    }


    /**
     * Echoes the project items to this task's output stream.
     **/
    protected void echoThing()
    {
        OutputStream os = getOutputStream();
        try {
            final Project myProject = getProject();
            PrintStream ps = new PrintStream(os);
            boolean p= echoProperties(myProject,ps);
            boolean v= echoVariables(myProject,ps);
            boolean r= echoReferences(myProject,ps);

            if (!p && !v && !r) {
                if (getMessageId()!=null || getDefaultMessage()!=null) {
                    String s = getMsg();
                    ps.println(s);
                }
            }
            if (tryAntLog(os)) {
                log(getAntLogString(os),getNoiseLevel().getNativeIndex());
            }

        } catch(IOException ioX) {
            String ermsg = uistrs().get("task.echo.unable");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());

        } finally {
            closeOutputStream(os);
            os=null;
        }
    }


    /**
     * Echoes the list of items then always returns <i>true</i>.
     **/
    public final boolean eval()
    {
        execute();
        return true;
    }


    /**
     * Should always be able to execute if in legitimate project.
     **/
    protected final void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);
    }

    
    /**
     * Returns <i>true</i> if should add pre-canned header string.
     * @since JWare/AntXtras 3.5.0
     **/
    private boolean addHeaders() 
    {
        return m_headers && 
            (getMessageId()==null && Tk.isWhitespace(getDefaultMessage()));
    }


    private String  m_propertiesList;
    private String  m_variablesList;
    private String  m_refsList;
    private Class   m_kindOfClass = Object.class;//NB:allow 'em all!
    private String  m_prefix;//NB:allow 'em all!
    private boolean m_includeUnknowns=true;//NB:show 'em all!
    private boolean m_unmaskStringFriendly=true;
    private boolean m_headers=true;//@since AntXtras/3.5.0
    private boolean m_prettyPrint=false;//@since AntXtras/3.5.0
}

/* end-of-PrintEnvTask.java */
