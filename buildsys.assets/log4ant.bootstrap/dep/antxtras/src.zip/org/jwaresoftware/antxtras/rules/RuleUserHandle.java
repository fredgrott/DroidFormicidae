/**
 * $Id: RuleUserHandle.java 418 2008-04-26 18:25:00Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

/**
 * Luggage that carries around a shareable condition's caller's information.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,infra
 * @see      BuildRule
 * @.pattern JWare.Luggage
 **/

final class RuleUserHandle
{
    /**
     * Initializes new empty handle (done by factory).
     **/
    RuleUserHandle()
    {
    }

    /**
     * Sets the current thread's frontmost rule user.
     * @param c new frontmost caller (can be <i>null</i>)
     * @return the previous rule user (can be <i>null</i>)
     **/
    ShareableConditionUser setCaller(ShareableConditionUser c)
    {
        ShareableConditionUser old = m_ruleUser;
        m_ruleUser = c;
        return old;
    }


    /**
     * Returns the current thread's frontmost caller.
     * Can return <i>null</i>.
     **/
    ShareableConditionUser getCaller()
    {
        return m_ruleUser;
    }


    /* Seekrit member. */
    private ShareableConditionUser m_ruleUser;


    // ---------------------------------------------------------------------------------------
    /**
     * Factory of thread-specific RuleUserHandles.
     * @since    JWare/AntX 0.2
     * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    static final class Factory extends InheritableThreadLocal
    {
        /**
         * Returns a new RuleUserHandle.
         **/
        protected Object initialValue()
        {
            return new RuleUserHandle();
        }

        /**
         * Returns a new RuleUserHandle with reference to its parent's
         * rule caller.
         **/
        protected Object childValue(Object parentValue)
        {
            RuleUserHandle parentsJunk = (RuleUserHandle)parentValue;
            RuleUserHandle copy = new RuleUserHandle();
            if (parentsJunk!=null) {
                copy.setCaller(parentsJunk.getCaller());
            }
            return copy;
        }

        /**
         * Creates a new factory (only allowed from package's BuildRule).
         **/
        Factory()
        {
        }
    }
}

/* end-of-RuleUserHandle.java */
