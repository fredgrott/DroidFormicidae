/**
 * $Id: ForEachTasksMacroDef.java 431 2008-05-03 18:20:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.starters.MacroMaker;

/**
 * The macrodef builder for a single foreach taskset instance.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    impl,helper
 * @see       ForEachTaskSkeleton
 **/

final class ForEachTasksMacroDef extends MacroMaker
{
    ForEachTasksMacroDef()
    {
        super(AntX.flowcontrol+"ForEachTasksMacroDef:");
    }
}

/* end-of-ForEachTasksMacroDef.java */