/**
 * $Id: ConfigurableCaller.java 431 2008-05-03 18:20:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;

/**
 * Supplemental interface of a target caller that can call configurable
 * targets like macros and presetdefs.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   n/a
 **/

interface ConfigurableCaller
{
    /**
     * Create a new attribute to passthru to called configurable.
     **/
    InnerNameValuePair createAttribute();
}

/* end-of-ConfigurableCaller.java */