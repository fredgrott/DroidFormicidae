/**
 * $Id: OlderDateTimeFunctionShortcut.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.util.Date;

/**
 * Function shortcut that returns "<span class="src">true</span>" if 
 * the first timestamp is older than the second.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;do true="${$<b>olderdate:</b>${changelog1},,${changelog2}}"&gt;
 *     ...
 *  &lt;/do&gt;
 *
 *  -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="olderdate"
 *           value="${ojaf}.datetime.OlderDateTimeFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   guarded
 * @.group    api,helper
 * @see       EqualDateTimeFunctionShortcut
 * @see       NewerDateTimeFunctionShortcut
 **/

public final class OlderDateTimeFunctionShortcut extends EqualDateTimeFunctionShortcut
{
    /**
     * Initializes a new older datetime funcut.
     */
    public OlderDateTimeFunctionShortcut()
    {
    }


    /**
     * Returns <i>true</i> if the first timestamp is older than the second.
     */
    protected boolean compare(Date d1, Date d2)
    {
        return d1.before(d2);
    }
}

/* end-of-OlderDateTimeFunctionShortcut.java */