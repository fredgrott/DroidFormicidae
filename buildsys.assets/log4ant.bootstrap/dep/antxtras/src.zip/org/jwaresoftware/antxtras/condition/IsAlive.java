/**
 * $Id: IsAlive.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/
package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.IsReachable;

import  org.jwaresoftware.antxtras.condition.URIable;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.RecoveryEnabled;

/**
 * Adapter that allows &lt;isreachable file="&#46;&#46;&#46;" host="apache.org"/&gt;
 * to be inlined and used as a condition function shortcuts. Note that this condition
 * defaults to a max wait time of 10 seconds; the default Ant condition defaults 
 * to 30 seconds.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;assert message="Run servers alive"&gt;
 *     &lt;isalive url="ftp://ftp.examples.org/public_drop"/&gt;
 *     &lt;isalive host="examples.org"/&gt;
 *     &lt;isalive host="examples.org" timeout="5"/&gt;
 *   &lt;/assert&gt;
 *   ...
 *   &lt;do isalive="http://examples.org/?5"&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single (see IsReachable)
 * @.group    impl,helper
 * @.pattern  GoF.Adapter
 **/

public final class IsAlive extends AssertableProjectComponent implements URIable, RecoveryEnabled
{
    /**
     * Creates new IsAlive condition.
     **/
    public IsAlive()
    {
        super(AntX.conditions+"IsAlive");
        m_impl = new IsReachable();
        m_impl.setTimeout(10);
    }


    /**
     * Sets this condition's project; updates underlying reachable
     * condition too.
     **/
    public void setProject(Project p)
    {
        super.setProject(p);
        m_impl.setProject(p);
    }



    /**
     * Sets property name updated by <i>true</i> evaluation.
     * @param property the property's name (non-null)
     **/
    public void setTrueProperty(String property)
    {
        require_(!Tk.isWhitespace(property),"setProperty- nonblank name");
        m_trueProperty = property;
    }


 
    /**
     * Sets the URL containing the host to test.
     * @param url URL to be checked (non-blank)
     **/
    public void setURL(String url)
    {
        require_(!Tk.isWhitespace(url),"setURL- nonblank url");
        m_impl.setUrl(url);
        m_targetCount++;
    }


    
    /**
     * Sets the name of the host to test.
     * @param hostname host to be checked (non-blank)
     **/
    public void setHost(String hostname)
    {
        require_(!Tk.isWhitespace(hostname),"setHost- nonblank hostid");
        m_impl.setHost(hostname);
        m_targetCount++;
    }


    /**
     * Sets the max time to wait for ping to return; defaults 10seconds.
     * @param timeout the timeout duration in seconds
     **/
    public void setTimeout(int timeout)
    {
        require_(timeout>=0,"setTimeout- zero or positive");
        m_impl.setTimeout(timeout);
    }


    /**
     * Tells this condition whether to propagate a script error if
     * named URL or host is missing or malformed. Defaults NO.
     */
    public void setHaltIfError(boolean flag)
    {
        m_haltIfError = flag;
    }


    public boolean isHaltIfError()
    {
        return m_haltIfError;
    }


    private static final int UNDEFINED_TIMEOUT= Integer.MIN_VALUE;
    private static final int BAD_TIMEOUT= -1;

    
    /**
     * Sets this condition's URL as part of a function shortcut. Includes
     * support for a timeout value after the scheme delimiter as in:
     * <span class="src">ftp://ftp.example.org/?10</span>.
     * @param fragment the funcut URI bits (non-null)
     */
    public void xsetFromURI(String fragment)
    {
        int timeout = UNDEFINED_TIMEOUT;
        String urlOrHost = fragment;
        int i = fragment.indexOf(FunctionShortcut.SCHEME_DELIMITER);
        if (i>=0) {
            urlOrHost = fragment.substring(0,i);
            i += FunctionShortcut.SCHEME_DELIMITER_LEN;
            if (i<fragment.length()) {
                timeout = Tk.integerFrom(fragment.substring(i),BAD_TIMEOUT);
            }
        }
        i = urlOrHost.indexOf("://");
        if (i>0) {
            setURL(urlOrHost);
        } else {
            setHost(urlOrHost);
        }
        if (timeout!=UNDEFINED_TIMEOUT) {
            setTimeout(timeout);
        }
    }


    /**
     * Protected wrap for running underlying implementation which has a
     * high possibility of barfage. Unless our haltIfError is set ON 
     * a malformed or error pinging host results in a "false" response.
     **/
    private boolean safeEval()
    {
        try {
            return m_impl.eval();
        } catch(BuildException runX) {
            if (isHaltIfError())
                throw runX;
        }
        return false;
    }


    /**
     * Checks whether given location is a readable host or not.
     * @throws BuildException if incomplete set or unable to check condition
     **/
    public boolean eval() throws BuildException
    {
        verifyCanEvaluate_();

        boolean alive = safeEval();

        if (alive && m_trueProperty!=null) {
            log("isAlive was true; setting true-property '"+m_trueProperty+
                "' property",  Project.MSG_DEBUG);
            getProject().setNewProperty(m_trueProperty,Strings.TRUE);
        }

        return alive;
    }


    private void verifyCanEvaluate_() throws BuildException
    {
        verifyInProject_("eval");
        if (m_targetCount!=1) {
            String error = Errs.NeedsThisAttribute(getDeclaredTypeName(),"url|host");
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
    }


    private IsReachable m_impl;
    private String m_trueProperty;//Optional
    private boolean m_haltIfError;//OFF
    private int m_targetCount=0;
}


/* end-of-IsAlive.java */
