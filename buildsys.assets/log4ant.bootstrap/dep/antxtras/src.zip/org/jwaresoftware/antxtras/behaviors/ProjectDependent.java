/**
 * $Id: ProjectDependent.java 388 2008-03-30 15:44:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Project;

/**
 * Mixin interface for an object that depends on a
 * <span class="src">{@linkplain Project Project}</span> to perform its responsibilities.
 * Coincidently like a <span class="src">ProjectComponent</span>;
 * however a dependent does not have to be <em>part of</em> a project.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,infra
 * @see      LogEnabled
 **/

public interface ProjectDependent
{
    /**
     * (Re)initialize this dependent's target project.
     * @param project the project
     **/
    void setProject(Project project);


    /**
     * Returns this object's targeted project. Can return
     * <i>null</i> if this attribute is not defined currently.
     **/
    Project getProject();
}

/* end-of-ProjectDependent.java */
