/**
 * $Id: Responses.java 808 2009-08-30 16:47:21Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.ProjectComponent;

/**
 * A collection of predefined problem handlers.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/

public final class Responses
{
    /**
     * Stops the build-iteration with a build error.
     * @since    JWare/AntX 0.3
     * @see      BuildError
     **/
    public static final ProblemHandler DEATH=
        new ProblemHandler() {
                public void problem(Object nugget, int nl) {
                    throw new BuildError(Tk.stringFrom(nugget,null));
                }
            };



    /**
     * Generates a build-iteration exception.
     * @since    JWare/AntX 0.3
     **/
    public static final ProblemHandler ERROR=
        new ProblemHandler() {
                public void problem(Object nugget, int nl) {
                    throw new BuildException(Tk.stringFrom(nugget,null));
                }
            };



    /**
     * Silently ignores the problem; no-op.
     * @since    JWare/AntX 0.3
     **/
    public static final ProblemHandler SILENCE=
        new ProblemHandler() {
                public void problem(Object nugget, int nl) {
                    //nada
                }
            };



    /**
     * Simple problem handler that just records whether a problem was
     * reported back to the original caller as a boolean.
     * @since   JWare/AntX 0.4
     * @author  ssmc, &copy;2003-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version 3.5.0b2
     * @.safety single
     * @.group  impl,helper
     **/
    public static final class LitmusResult implements ProblemHandler {
        /** Reflects the result of the operation. True means a
            problem occured. **/
        public boolean hadProblem;

        /** Reflects the details of the encountered problem. Empty string
         *  if no problem. **/
        public String what="";

        /** Initializes a new "no" problem result. **/
        public LitmusResult() {
        }

        /** Records operation has had some kind of problem. **/
        public void problem(Object nugget, int nl) {
            this.hadProblem = true;
            this.what = Tk.stringFrom(nugget,null);
        }
        /** Resets this response object for reuse. **/
        public void reset() {
            hadProblem = false;
            what = "";
        }
    }



    /**
     * Logs problem via its controlling log enabled component.
     * @since   JWare/AntX 0.3
     * @author  ssmc, &copy;2003-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version 3.5.0b2
     * @.safety single
     * @.group  impl,helper
     **/
    public static class LogUsing implements ProblemHandler {
        /** Initializes new handler that logs to standard Ant component.
         *  @see org.jwaresoftware.antxtras.behaviors.LogEnabled.ForComponent
         **/
        public LogUsing(ProjectComponent pc) {
            logSpi = new LogEnabled.ForComponent(pc);
        }
        /** Initializes new handler that delegates to log enabled component.
         *  @since JWare/AntX 0.5
         *  @throws IllegalArgumentException if impl is <i>null</i>.
         **/
        public LogUsing(LogEnabled impl) {
            if (impl==null) {
                throw new IllegalArgumentException();
            }
            logSpi = impl;
        }
        /** Logs problem via this response's component. **/
        public void problem(Object nugget, int nl) {
            logSpi.log(Tk.stringFrom(nugget,null),nl);
        }
        final LogEnabled logSpi;
    }



    /**
     * Logs problem via its controlling project component and
     * remembers whether a problem was recorded for future use.
     * @since   JWare/AntX 0.4
     * @author  ssmc, &copy;2003-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version 3.5.0b2
     * @.safety single
     * @.group  impl,helper
     **/
    public static class LogAndRemember extends LogUsing {
        /** Reflects the result of the operation. True means a
            problem occured. **/
        public boolean hadProblem;

        /** Reflects the details of the encountered problem. Empty string
         *  if no problem. **/
        public String what="";

        /** Initializes new handler that logs to standard Ant component and
         *  remembers whether had problem.
         **/
        public LogAndRemember(ProjectComponent pc) {
            super(pc);
        }
        /** Initializes new handler that delegates to log enabled component
         *  and remembers problem occured.
         *  @since JWare/AntX 0.5
         **/
        public LogAndRemember(LogEnabled impl) {
            super(impl);
        }
        /** Records there was a problem and logs problem via  this
         *  handler's log enabled component.
         **/
        public void problem(Object nugget, int nl) {
            this.hadProblem = true;
            this.what = Tk.stringFrom(nugget,null);
            logSpi.log(this.what,nl);
        }
        /** Resets this response object for reuse. **/
        public void reset() {
            hadProblem = false;
            what = "";
        }
    }


    /** Prevent; only static APIs and classes. **/
    private Responses()
    {}
}

/* end-of-Responses.java */
