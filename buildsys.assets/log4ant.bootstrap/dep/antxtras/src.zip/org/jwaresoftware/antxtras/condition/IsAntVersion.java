/**
 * $Id: IsAntVersion.java 1330 2012-07-14 23:04:02Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.go.IffAnt;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.TrueFalsePropertySetter;

/**
 * Condition that checks the current Ant runtime's version information
 * against a regular expression. If you can guarantee that the project property
 * "<span class="src">ant.version</span>" is always defined, you can get this
 * condition's basic test by using the standard AntXtras Matches rule.
 * However, this condition adds the ability to set properties and use short
 * hand (not RE) version strings.
 * <p>
 * <b>Example Usage:</b><pre>
 *  &lt;isantversion like="^.*version 1\.[5-7].*"/&gt;
 *  &lt;isantversion equal="1.6"/&gt;
 *  &lt;isantversion equal="1.5.4" trueproperty="old.ant.present"/&gt;
 *  &lt;isantversion equal="1.6+"/&gt;
 *  &lt;isantversion like="1234" property="local.ant.version"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 * @.caveat  If this condition is part of a rule, you should not set
 *           either update property unless you only execute the rule once.
 **/

public class IsAntVersion extends AssertableProjectComponent
    implements Condition, TrueFalsePropertySetter, URIable
{
    /**
     * Initializes a new antversion condition.
     **/
    public IsAntVersion()
    {
        super(AntX.conditions);
    }


    /**
     * Initializes a new antversion condition bound to a
     * project and pattern.
     **/
    public IsAntVersion(Project P, String pattern)
    {
        super(AntX.conditions);
        setProject(P);
        setLike(pattern);
    }

// ---------------------------------------------------------------------------------------
// Parameters:
// ---------------------------------------------------------------------------------------

    private static final String VERSION_RE_0= "^.*version ";
    private static final String VERSION_RE_N= " compiled .*$";


    /**
     * Sets this condition's regular expression pattern.
     * @param pattern pattern against which value matched (non-null)
     **/
    public void setLike(String pattern)
    {
        require_(pattern!=null,"setLike- nonzro pattern");
        m_pattern = pattern;
    }


    /**
     * Sets this condition's version string as a simple
     * <em>exact</em> number string like:
     * "<span class="src">1.6.1</span>". This method basically
     * builds the match pattern for caller.
     * @param version exact version to look for (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setEqual(String version)
    {
        require_(!Tk.isWhitespace(version),"setEqual- nonzro version");

        StringBuffer sb = AntXFixture.newStringBuffer();
        sb.append(VERSION_RE_0);

        int N= version.length();
        for (int i=0;i<N;i++) {
            char c = version.charAt(i);
            if (c=='.') {
                sb.append("\\.");
            } else if (c=='+' && i==N-1) {
                sb.append("(\\.[0-9]+)?(RC[1-9]+)?(beta[1-9]+)?");
            } else {
                sb.append(c);
            }
        }

        sb.append(VERSION_RE_N);
        setLike(sb.substring(0));

        log("[antversion] looking for version pattern='"+m_pattern+"'",
            Project.MSG_DEBUG);
        sb = null;
    }



    /**
     * Returns pattern against which values matched. Returns
     * <i>null</i> if never set.
     **/
    public final String getPattern()
    {
        return m_pattern;
    }



    /**
     * Sets the property to be created on a negative evaluation.
     * Property will be set to the string "<i>true</i>."
     * @param property the property to create (non-null)
     **/
    public void setFalseProperty(String property)
    {
        require_(property!=null,"setFalsP- nonzro nam");
        m_falseProperty = property;
    }


    /**
     * Returns the property to be created/set on a negative
     * evaluation. Returns <i>null</i> if never set.
     **/
    public final String getFalseProperty()
    {
        return m_falseProperty;
    }


    /**
     * Sets the property to be created on a positive evaluation.
     * Property will be set to the string "<i>true</i>."
     * @param property the property to create (non-null)
     **/
    public void setTrueProperty(String property)
    {
        require_(property!=null,"setTrueP- nonzro nam");
        m_trueProperty = property;
    }


    /**
     * Returns the property to be created/set on a positive
     * evaluation. Returns <i>null</i> if never set.
     **/
    public final String getTrueProperty()
    {
        return m_trueProperty;
    }


    /**
     * Sets a custom source property for the version string. This
     * parameter is useful for test scripts and other situations
     * where you want to read version string from source other than
     * default Ant property.
     * @param property name of property containing version string
     **/
    public void setProperty(String property)
    {
        m_versionProperty = property;
    }



    /**
     * Sets this condition's pattern (like) as part of a value URI.
     * @param fragment the value uri bits (non-null)
     * @since JWare/AntX 0.5
     */
    public void xsetFromURI(String fragment)
    {
        setLike(fragment);
    }


// ---------------------------------------------------------------------------------------
// Evaluation:
// ---------------------------------------------------------------------------------------

    /**
     * Returns <i>true</i> if the Ant version matches the pattern.
     * @.sideeffect Will update true and/or false properties
     *              if defined.
     **/
    public boolean eval()
    {
        verifyCanEvaluate_("eval");

        boolean istrue;

        if (m_versionProperty==null) {
            istrue = IffAnt.pass(getPattern(),getProject(),false);
        } else {
            istrue = IffAnt.pass(getPattern(),m_versionProperty,getProject(),false);
        }

        if (m_trueProperty!=null && istrue) {
            log("[isantversion] was true; setting true-property '"+
                m_trueProperty+
                "' property",  Project.MSG_DEBUG);
            getProject().setNewProperty(m_trueProperty,Strings.TRUE);
        }

        if (m_falseProperty!=null && !istrue) {
            log("[isantversion] was false; setting false-property '"+
                m_falseProperty+
                "' property",  Project.MSG_DEBUG);
            getProject().setNewProperty(m_falseProperty,Strings.TRUE);
        }

        return istrue;
    }


    /**
     * Call to verify that this condition is in valid project
     * and has its pattern defined.
     * @param calr caller's identifier
     * @throws BuildException if not in project or all bits not defined
     **/
    protected void verifyCanEvaluate_(String calr)
    {
        super.verifyInProject_(calr);

        if (getPattern()==null) {
            String error = Errs.NeedsThisAttribute("isantversion", "like|equal");
            log(error,Project.MSG_ERR);
            throw new BuildException(error);
        }
    }


    private String m_falseProperty;
    private String m_trueProperty;
    private String m_pattern;
    private String m_versionProperty;
}

/* end-of-IsAntVersion.java */
