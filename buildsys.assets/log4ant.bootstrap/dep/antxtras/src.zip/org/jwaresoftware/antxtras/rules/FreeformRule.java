/**
 * $Id: FreeformRule.java 418 2008-04-26 18:25:00Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.parameters.FreeFormEnabled;

/**
 * Marker interface for a boolean rule that allows arbitrary application-defined
 * conditions to nest within its definition. Compatible with Ant 1.5.x and 1.6. When
 * run under Ant 1.6 tasks and types can automatically nest application-defined
 * conditions (as per the Antlib auto-installed "role" implementations guidelines).
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface FreeformRule extends FreeFormEnabled
{
    /**
     * API called manually or by Ant 1.6 task builder to add
     * application defined conditions to this rule. It is up to your
     * application to ensure that all nested condition requirements are
     * met by your Condition's implementation before adding instances
     * to this rule.
     * @param c the condition (non-null)
     **/
    public void addConfigured(Condition c);
}

/* end-of-FreeformRule.java */
