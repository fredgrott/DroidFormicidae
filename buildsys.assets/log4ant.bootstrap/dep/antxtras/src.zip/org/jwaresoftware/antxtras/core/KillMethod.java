/**
 * $Id: KillMethod.java 1034 2010-03-20 15:05:26Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;

/**
 * Fixture administrator cleanup callback method. Kill methods are 
 * installed by every {@linkplain FixtureAdministrator fixture administrator}
 * to help execution harnesses reset the runtime environment before
 * (re)launching a new execution cycle. This is their only purpose.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,helper
 * @see      AntXFixture#setKillMethod AntXFixture.setKillMethod(&#8230;)
 **/

public interface KillMethod
{
    /**
     * Do whatever is necessary to "kill" fixture component so that
     * an execution harness can kick off a new cycle.
     * @param from controlling task or test (non-null)
     * @return <i>true</i> if fixture cleanup was successful
     **/
    boolean kill(ProblemHandler from);


    /**
     * Do whatever is necessary to "kill" a particular aspect of
     * a fixture component so that an execution harness can kick 
     * off a new cycle.
     * @param aspect symbolic name of aspect to be killed
     * @param from controlling task or test (non-null)
     * @return <i>true</i> if fixture cleanup was successful
     **/
    boolean kill(String aspect, ProblemHandler from);
}

/* end-of-KillMethod.java */
