/**
 * $Id: TallySet.java 1225 2011-08-13 19:15:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  java.util.Iterator;
import  java.util.Stack;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.Available;
import  org.apache.tools.ant.taskdefs.Checksum;
import  org.apache.tools.ant.taskdefs.UpToDate;
import  org.apache.tools.ant.taskdefs.condition.Condition;
import  org.apache.tools.ant.taskdefs.condition.Http;
import  org.apache.tools.ant.taskdefs.condition.Socket;

import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.condition.AllSet;
import  org.jwaresoftware.antxtras.condition.AllSetTrue;
import  org.jwaresoftware.antxtras.condition.AnySet;
import  org.jwaresoftware.antxtras.condition.AnySetTrue;
import  org.jwaresoftware.antxtras.condition.FileNotEmpty;
import  org.jwaresoftware.antxtras.condition.IsAntVersion;
import  org.jwaresoftware.antxtras.condition.IsClass;
import  org.jwaresoftware.antxtras.condition.IsDirectory;
import  org.jwaresoftware.antxtras.condition.IsFile;
import  org.jwaresoftware.antxtras.condition.IsReference;
import  org.jwaresoftware.antxtras.condition.IsResource;
import  org.jwaresoftware.antxtras.condition.NoneSet;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.NoiseLevel;

/**
 * A shareable set of availability checks. A TallySet evaluates all of
 * its nested checks regardless of their individual results.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>tallyset</b> id="tally.j2se.libs"&gt;
 *      &lt;isclass name="java.lang.StrictMath" trueproperty="atleast-j2se12-present"/&gt;
 *      &lt;isclass name="java.sql.Clob" trueproperty="atleast-j2se13-present"/&gt;
 *      &lt;isclass name="java.nio.ReadOnlyBufferException" trueproperty="atleast-j2se14-present"/&gt;
 *      &lt;isclass name="java.lang.Enum" trueproperty="atleast-j2se15-present"/&gt;
 *      &lt;isclass name="java.util.Deque" trueproperty="atleast-j2se16-present"/&gt;
 *      &lt;isclass name="java.nio.file.FileSystem" trueproperty="atleast-j2se17-present"/&gt;
 *   &lt;/tallyset&gt;
 *
 *   &lt;<b>tallyset</b> id="tally.testing.thirdparty.libs"&gt;
 *      &lt;isclass name="junit.framework.Assert" trueproperty="junit-present"/&gt;
 *      &lt;isclass name="org.slf4j.Logger" trueproperty="slf4j-present"/&gt;
 *      &lt;isclass name="org.testng.Assert" trueproperty="testng-present"/&gt;
 *      &lt;isclass name="org.apache.log4j.Logger" trueproperty="log4j-present"/&gt;
 *   &lt;/tallyset&gt;
 *
 *   &lt;<b>tallyset</b> id="tally.libs"&gt;
 *      &lt;<b>tallyset</b> refid="tally.j2se.libs"/&gt;
 *      &lt;<b>tallyset</b> refid="tally.testing.thirdparty.libs"/&gt;
 *   &lt;/tallyset&gt;
 *
 *   &lt;<b>tallyset</b> id="tally.test.env"&gt;
 *      &lt;<b>tallyset</b> refid="tally.j2se.libs"/&gt;
 *      &lt;<b>tallyset</b> refid="tally.testing.thirdparty.libs"/&gt;
 *      &lt;allset trueproperty="base-test-env-present"&gt;
 *        &lt;property name="atleast-j2se14-present"/&gt;
 *        &lt;property name="testng-present"/&gt;
 *      &lt;/allset&gt;
 *   &lt;/tallyset&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2002-2004,2008,2010-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 * @see      TallyTask
 **/

public class TallySet extends RuleType implements FreeformRule
{
    /**
     * Initializes a new tallyset.
     **/
    public TallySet()
    {
        super(AntX.rules+"tally");
        setStopQuickEvaluation(false);
    }


    /**
     * Initializes a new CV-labeled tallyset.
     * @param iam CV-label (non-null)
     **/
    public TallySet(String iam)
    {
        super(iam);
        setStopQuickEvaluation(false);
    }


    /**
     * Returns a clone of this tallyset. If this tallyset is a reference
     * to another set, that object's clone method is invoked.
     **/
    public Object clone()
    {
        if (isReference()) {
            return getReference().clone();
        }
        return super.clone();
    }


    /**
     * Set this tallyset to evaluate as its own definition another tallyset.
     * Saves the reference for conversion to a livin' tallyset when needed.
     * @param r reference to other tallyset (non-null)
     * @throws BuildException if this tallyset already has own conditions
     **/
    public void setRefId(Reference r)
    {
        require_(r!=null,"setRefId- nonzro ref");
        checkModify("setRefId");
        if (!isEmpty()) {
            throw new BuildException(uistrs().get("task.too.many.attrs",getId()));
        }
        m_ref = r;
    }


    /**
     * Returns this tallyset's reference. Returns <i>null</i> if no
     * reference has been set.
     **/
    public final Reference getRefId()
    {
        return m_ref;
    }


    /**
     * Returns <i>true</i> if this tallyset is setup as a reference to
     * another tallyset.
     */
    public boolean isReference()
    {
        return getRefId()!=null;
    }


    /**
     * Returns the effect if this a tallyset; by default returns
     * WARNING (no build stop).
     **/
    public NoiseLevel getFailureEffect()
    {
        return NoiseLevel.WARNING;
    }


// ---------------------------------------------------------------------------------------
// Nestable Elements:
// ---------------------------------------------------------------------------------------

    /**
     * Adds an arbitrary application-defined condition to
     * this tallyset.
     * @param c custom condition definition (non-null)
     * @since JWare/AntX 0.3
     **/
    public void addConfigured(Condition c)
    {
        require_(c!=null,"add- nonzro condition");
        xaddCondition(c);
    }


    /**
     * Adds a sub-tally &lt;tallyset&gt; to this tallyset.
     **/
    public void addTallyset(TallySet tt)
    {
        xaddCondition(tt);
    }


    /**
     * Adds an &lt;isclass&gt; condition to this tallyset.
     **/
    public void addIsClass(IsClass isc)
    {
        xaddCondition(isc);
    }


    /**
     * Adds an &lt;isreference&gt; condition to this tallyset.
     * @since JWare/AntXtras 3.0.0
     **/
    public void addIsReference(IsReference isR)
    {
        xaddCondition(isR);
    }


    /**
     * Synonymn for {@linkplain #addIsReference(IsReference) addIsReference()}.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void addIsRef(IsReference isR)
    {
        addIsReference(isR);
    }


    /**
     * Adds an &lt;isresource&gt; condition to this tallyset.
     **/
    public void addIsResource(IsResource isr)
    {
        xaddCondition(isr);
    }


    /**
     * Adds an &lt;isfile&gt; condition to this tallyset.
     * @since JWare/AntXtras 2.0.0
     **/
    public void addIsFile(IsFile isf)
    {
        xaddCondition(isf);
    }


    /**
     * Adds an &lt;isdirectory&gt; condition to this tallyset.
     * @since JWare/AntXtras 2.0.0
     **/
    public void addIsDirectory(IsDirectory isD)
    {
        xaddCondition(isD);
    }


    /**
     * Synonymn for {@linkplain #addIsDirectory(IsDirectory) addIsDirectory()}.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void addIsDir(IsDirectory isD)
    {
        addIsDirectory(isD);
    }


    /**
     * Adds a &lt;filenotempty&gt; condition to this tallyset.
     **/
    public void addFileNotEmpty(FileNotEmpty fne)
    {
        xaddCondition(fne);
    }


    /**
     * Adds an &lt;allset&gt; condition to this tallyset.
     **/
    public void addAllSet(AllSet allset)
    {
        xaddCondition(allset);
    }


    /**
     * Adds an &lt;alltrue&gt; condition to this tallyset.
     * @since JWare/AntX 0.5
     **/
    public void addAllSetTrue(AllSetTrue allset)
    {
        xaddCondition(allset);
    }


    /**
     * Adds an &lt;anyset&gt; condition to this tallyset.
     **/
    public void addAnySet(AnySet anyset)
    {
        xaddCondition(anyset);
    }


    /**
     * Adds an &lt;anytrue&gt; condition to this tallyset.
     * @since JWare/AntX 0.5
     **/
    public void addAnySetTrue(AnySetTrue anyset)
    {
        xaddCondition(anyset);
    }


    /**
     * Adds a &lt;noneset&gt; condition to this tallyset.
     **/
    public void addNoneSet(NoneSet noneset)
    {
        xaddCondition(noneset);
    }


    /**
     * Adds an &lt;ismatch&gt; (task) condition to this rule.
     * We use the MatchesTask to get flexibility of true/false
     * property side-effects (missing from simpler IsMatch
     * condition).
     * @since JWare/AntX 0.3
     **/
    public void addIsMatch(MatchesTask matches)
    {
        xaddCondition(matches);
    }


    /**
     * Adds an &lt;available&gt; condition to this tallyset.
     **/
    public void addAvailable(Available av)
    {
        xaddCondition(av);
    }


    /**
     * Adds an &lt;httpalive&gt; condition to this tallyset.
     * @since JWare/AntXtras 2.0.0
     **/
    public void addHttpAlive(Http hta)
    {
        xaddCondition(hta);
    }


    /**
     * Adds a &lt;checksum&gt; condition to this tallyset.
     **/
    public void addChecksum(Checksum cs)
    {
        xaddCondition(cs);
    }


    /**
     * Adds an &lt;uptodate&gt; condition to this tallyset.
     **/
    public void addUpToDate(UpToDate up)
    {
        xaddCondition(up);
    }


    /**
     * Adds an &lt;isantversion&gt; condition to this tallyset.
     * @since JWare/AntXtras 3.0.0
     **/
    public void addIsAntVersion(IsAntVersion vc)
    {
        xaddCondition(vc);
    }


    /**
     * Adds an &lt;socketalive&gt; condition to this tallyset.
     * @since JWare/AntX 2.0.0
     **/
    public void addSocketAlive(Socket ska)
    {
        xaddCondition(ska);
    }

// ---------------------------------------------------------------------------------------
// Managing Referrals:
// ---------------------------------------------------------------------------------------

    /**
     * Appends new condition to this tallyset's conditions sequence if
     * its not a reference.
     * @throws BuildException if tallyset is a reference or is frozen
     **/
    public void xaddCondition(Condition c)
    {
        if (isReference()) {
            throw new BuildException(uistrs().get("task.too.many.attrs",getId()));
        }
        super.xaddCondition(c);
    }


    /**
     * Appends the only condition allowed for this tallyset.
     * @param c new root conditon (non-null)
     * @return <i>true</i> if could add as only condition
     * @throws BuildException if tallyset is a reference or is frozen
     **/
    public boolean xaddRootCondition(Condition c)
    {
        if (isReference()) {
            throw new BuildException(uistrs().get("task.too.many.attrs",getId()));
        }
        return super.xaddRootCondition(c);
    }


    /**
     * Returns the strongly-typed tallyset to which we refer. Must be
     * a reference. Does not verify reference other than to check its type.
     **/
    protected final TallySet getReference()
    {
        verify_(m_ref!=null,"getReference- has refid");
        Object robj = m_ref.getReferencedObject(getProject());

        if (!(robj instanceof TallySet)) {
            String ermsg = uistrs().get("brul.bad.ruleid",m_ref.getRefId());
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg);
        }
        return (TallySet)robj;
    }


// ---------------------------------------------------------------------------------------
// Evaluation:
// ---------------------------------------------------------------------------------------


    /**
     * Ensure this tallyset does not contain any circular references
     * in its definition. Checks references as well as tallyset's
     * nested elements.
     * @param stk stack of referred-to (or used) rules (non-null)
     * @param clnt call controls (non-null)
     * @throws BuildException if circular dependency discovered
     * @.impl sets latch after 1st successful call
     **/
    public void verifyNoCircularDependency(Stack stk, Requester clnt)
    {
        if (!m_circularityChecked) {
            if (isReference()) {
                Object robj = m_ref.getReferencedObject(getProject());
                if (stk.contains(robj)) {
                    String ermsg = uistrs().get("brul.circular.referals",m_ref.getRefId());
                    clnt.problem(ermsg,Project.MSG_ERR);
                    throw new BuildException(ermsg,clnt.getLocation());
                }
                if (robj instanceof BooleanRule) {
                    stk.push(robj);
                    ((BooleanRule)robj).verifyNoCircularDependency(stk,clnt);
                    stk.pop();
                }
                m_circularityChecked = true;
            }
            else if (!isEmpty()) {
                Stack itemstk= new Stack();
                Iterator itr= getConditions().iterator();
                int I=0;
                while (itr.hasNext()) {
                    Object oc = itr.next();
                    I++;
                    if (oc instanceof BooleanRule) {
                        if (stk.contains(oc)) {
                            String posI = getId()+"["+String.valueOf(I)+"]";
                            String ermsg = uistrs().get("brul.circular.referals",posI);
                            clnt.problem(ermsg,Project.MSG_ERR);
                            throw new BuildException(ermsg,clnt.getLocation());
                        }
                        itemstk.addAll(stk);
                        itemstk.push(oc);
                        ((BooleanRule)oc).verifyNoCircularDependency(itemstk,clnt);
                        itemstk.clear();
                    }
                }
                m_circularityChecked = true;
            }
        }//!checked
    }


    /**
     * Evaluates this tallyset as a root instance. If is reference
     * calls referred-to-tallyset's evaluation method.
     * @throws BuildException if an error occurs during evaluation
     **/
    public boolean eval(ShareableConditionUser calr)
        throws BuildException
    {
        if (isReference()) {
            return getReference().eval(calr);
        }
        return super.eval(calr);
    }


    /**
     * Evaluates this tallyset as a nested component of another
     * tallyset. If is reference calls referred-to-tallyset's eval
     * method.
     * @throws BuildException if an error occurs during evaluation
     **/
    public boolean eval()
        throws BuildException
    {
        if (isReference()) {
            return getReference().eval();
        }
        return super.eval();
    }


    /**
     * Default evaluation result handler method does nothing except
     * log diagnostics information.
     **/
    protected boolean setEvalResult(final boolean istrue, String listing)
    {
        if (istrue) {
            log("TallySet ("+getId()+") evaluates TRUE",Project.MSG_DEBUG);
        } else {
            log("TallySet ("+getId()+") evaluates FALSE; condition in order "+listing,
                Project.MSG_DEBUG);
        }
        return istrue;
    }


    private Reference m_ref;
}

/* end-of-TallySet.java */
