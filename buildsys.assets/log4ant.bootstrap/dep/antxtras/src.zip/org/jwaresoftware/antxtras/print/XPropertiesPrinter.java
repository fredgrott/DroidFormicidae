/**
 * $Id: XPropertiesPrinter.java 1419 2012-07-31 16:13:43Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.PrintStream;
import  java.util.Collections;
import  java.util.List;
import  java.util.Properties;

import  org.jwaresoftware.antxtras.core.AntXFixture;

/**
 * Helper to print a properties object without encoding. Useful for a diagnostic
 * view of a properties object (as opposed to a store-it view).
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

public class XPropertiesPrinter
{
    public interface LineOutput {
        void println(String name, Object value, PrintStream out);
    }

    public static final LineOutput PlainLine = new LineOutput() {
        public void println(String name, Object value, PrintStream out) {
            out.print(name);
            out.print("=");
            out.println(value);
        }
    };

    public static final LineOutput HeaderLine = new LineOutput() {
        public void println(String name, Object value, PrintStream out) {
            out.print(name);
            out.print(": ");
            out.println(value);
        }
    };

    public final static void print(Properties p, PrintStream out, LineOutput liner)
    {
        if (p==null) {
            out.println("NULL");
        } else {
            List namelist = AntXFixture.newList(p.size());
            namelist.addAll(p.keySet());
            Collections.sort(namelist);
            for (int i=0,n=namelist.size();i<n;i++) {
                String property = namelist.get(i).toString();
                String value = p.getProperty(property);
                liner.println(property,value,out);
            }
        }
    }

    public final static void header(String name, Object value, PrintStream out)
    {
        HeaderLine.println(name, value, out);
    }

    protected XPropertiesPrinter()
    {
        super();
    }
}

/* end-of-XPropertiesPrinter.java */
