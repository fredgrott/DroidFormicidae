/**
 * $Id: MillisecsFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.text.NumberFormat;
import  java.text.ParsePosition;
import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that converts a (more) human-readable duration 
 * string specifier into the actual millisecs represented. Milliseconds
 * are returned as a string like '12345670'.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;property name="timeout" 
 *       value="${<b>$millis:300sec</b>}"/&gt;
 *
 * <b>2)</b> &lt;property name="max.calculation.duration"
 *       value="${<b>$millis:1hr+30min</b>}"/&gt;
 *
 * <b>3)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="millis"
 *           value="${ojaf}.datetime.MillisecsFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class MillisecsFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new $millis: shortcut handler.
     **/
    public MillisecsFunctionShortcut()
    {
        super();
    }



    /**
     * Returns milliseconds are string if able to interpret the
     * user-supplied duration format string. Otherwise, returns
     * <i>null</i>. Note that an empty string is interpreted as
     * zero milliseconds!
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String description = uriFragment;
        int end = uriFragment.indexOf(SCHEME_DELIMITER);
        if (end>=0) {
            description = uriFragment.substring(0,end);
        }
        String out = "0";
        List parts = Tk.splitList(description,"+");
        if (!parts.isEmpty()) {
            long ms = 0L;
            NumberFormat nf = NumberFormat.getIntegerInstance();
            for (int i=0,N=parts.size();i<N;i++) {
                long next = millisFrom(parts.get(i).toString(),nf,clnt);
                if (next<0L) {
                    ms = -1L;
                    break;
                }
                ms += next;
            }
            if (ms>=0L) {
                out = String.valueOf(ms);
            } else if (isHaltIfError(clnt)) {
                String error = AntX.uistrs().get("fc.millis.bad.format", uriFragment);
                clnt.problem(error, Project.MSG_ERR);
                throw new BuildException(error, clnt.getLocation());
            } else {
                out = null;
            }
        }
        return out;
    }


    /** Multipliers used to convert final value to millis. **/
    private final static long[] MULTIPLIERS= {
        -1L/*unknown*/, 
        1L/*millis*/, 1000L/*secs*/,
        60L*1000L/*mins*/, 3600L*1000L/*hours*/,
        24L*3600L*1000L/*days*/
    };

    /** Threadsafe parser of time unit strings. **/
    private final static TimeUnitFormat UnitParser = new TimeUnitFormat();

    /** Returns true if value is a positive integer value. **/
    private static boolean isValid(Number n)
    {
        return n!=null && !Double.isNaN(n.doubleValue()) && n.intValue()>=0;
    }

    /**
     * Extracts the milliseconds encoded by a [sub]part of a
     * full duration string.
     * @param part duration string (usually a section of final string)
     * @param nf shared number formatter (non-null)
     * @param clnt callback for errors (non-null)
     * @return milliseconds or -1L if unable to parse for any reason.
     **/
    final static long millisFrom(String part, NumberFormat nf, Requester clnt)
    {
        long ms = -1L;
        ParsePosition cursor = new ParsePosition(0);
        Number n = nf.parse(part,cursor);
        if (isValid(n)) {
            int multiplier = 1;//=> millis if not set!
            int unit = cursor.getIndex();
            if (unit<part.length()) {
                Number index = UnitParser.parse(part,cursor);
                if (isValid(index) && cursor.getIndex()==part.length()) {
                    multiplier = index.intValue();
                } else {
                    String warning = "Unknown unit="+part.substring(unit);
                    clnt.problem(warning, Project.MSG_WARN);
                    multiplier = 0;
                }
            }
            ms = n.longValue() * MULTIPLIERS[multiplier];
        } else {
            String warning = "Invalid number="+part;
            clnt.problem(warning, Project.MSG_WARN);
        }
        return ms;
    }
}

/* end-of-MillisecsFunctionShortcut.java */
