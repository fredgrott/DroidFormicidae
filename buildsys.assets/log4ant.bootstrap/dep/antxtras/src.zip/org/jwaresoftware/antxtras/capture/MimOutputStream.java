/**
 * $Id: MimOutputStream.java 1510 2012-09-24 23:26:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.capture;

import  java.io.IOException;
import  java.io.OutputStream;
import  java.io.PrintStream;

/**
 * An output stream wrapper which saves output to task's buffer
 * before sending on to original stream target (Ant|System).
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003,2005,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded
 * @.group   impl,helper
 * @see      CaptureStreamsTask
 * @see      CopyLoggedTask
 **/

class MimOutputStream extends OutputStream
{
    /**
     * Creates a new filter stream for real system stream.
     **/
    MimOutputStream(PrintStream dest, StringBuffer allBuffer)
    {
        m_outBuffer = new StringBuffer(1000);
        m_finalDest = dest;
        m_allBuffer = allBuffer;
    }


    /**
     * Capture the byte to task-related buffer.
     **/
    public void write(int b) throws IOException
    {
        m_outBuffer.append((char)b);
        if (m_allBuffer!=null) {
            m_allBuffer.append((char)b);
        }
        m_finalDest.write(b);
    }


    /**
     * Returns a copy of this filter's current contents.
     **/
    String copyBuffer()
    {
        return m_outBuffer.substring(0);
    }


    /**
     * Resets this filter's buffered contents.
     **/
    void clearBuffer()
    {
        m_outBuffer.delete(0,m_outBuffer.length());
    }

    private final PrintStream m_finalDest;
    private final StringBuffer m_outBuffer, m_allBuffer;
}

/* end-of-MimOutputStream.java */
