/**
 * $Id: IsReachableFunctionShortcut.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.condition.ConditionFunctionShortcuts;
import  org.jwaresoftware.antxtras.condition.IsAlive;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that allows the standard Ant condition like
 * &lt;isreachable host="apache.org" timeout="10"/&gt;
 * to be inlined as a condition function shortcut.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;domatch value="${$isalive:${uploads.ftp.url}}"&gt;
 *     &lt;true&gt;...&lt;/true&gt;
 *   &lt;/domatch&gt;
 *   ...
 *   &lt;do isalive="examples.org?10"&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single (see IsReachable)
 * @.group    impl,helper
 * @.pattern  GoF.Adapter
 **/

public final class IsReachableFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new isalive function shortcut.
     **/
    public IsReachableFunctionShortcut()
    {
        super();
    }


    /**
     * Returns "true" if the specified host (URL or hostname) is
     * reachable from current Ant environment context (proxy setup etc.)
     * Note that if the ping generates an exception this funcut 
     * would return "false" unless it's set to stop on error.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        IsAlive test = new IsAlive();
        test.setProject(clnt.getProject());
        test.setHaltIfError(isHaltIfError(clnt));
        test.xsetFromURI(uriFragment);
        return String.valueOf(test.eval());
    }


    /**
     * Automatically registers this as a generic true/false condition
     * accessed via builtin shorthand condition framework for 
     * components like [do], etc.
     * Installs under schemes: "<span class="src">$isalive:</span>" and
     * "<span class="src">$isreachable:</span>"
     **/
    static {
        ConditionFunctionShortcuts.addMapping("$isalive:",IsAlive.class);
        ConditionFunctionShortcuts.addMapping("$isreachable:",IsAlive.class);
    }
}

/* end-of-IsReachableFunctionShortcut.java */
