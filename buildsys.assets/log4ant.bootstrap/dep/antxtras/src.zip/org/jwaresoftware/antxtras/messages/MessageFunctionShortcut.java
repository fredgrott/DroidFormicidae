/**
 * $Id: MessageFunctionShortcut.java 1372 2012-07-26 15:03:02Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.util.List;

import  org.jwaresoftware.internal.apis.UIStringManager;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.core.UISMContext;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns the named message from an AntXtras
 * resource bundle. The messages resource bundle should be activated before 
 * any URI refers to it (see <span class="src">&lt;managemessages&gt;</span> 
 * or <span class="src">&lt;overlaymessages&gt;</span>). This funcut is 
 * not installed automatically by the AntXtras runtime, you must install 
 * it explicitly like the example below. Message funcuts are often linked 
 * to the <span class="src">$message:</span> scheme.
 * <p/>
 * You can specify up to eight message template arguments (for locations
 * {2} thru {9}) by using a simple URI form like: 
 * <span class="src">$message:strid[?arg2[,,arg3]]</span>.
 * Everything after the <span class="src">strid</span> is optional.
 * <p/>
 * To allow you to specify the optional message arguments from property 
 * values, the message funcut understands nested property 
 * "<span class="src">%{propertyname}</span>" format in its fragment's 
 * query portion; see example below. Note that message arguments
 * are separated by two commas like "<span class="src">,,</span>" 
 * <em>not</em> an ampersand. This allows XML-based scripts to define 
 * arguments without the need to encode the ampersand reserved for 
 * use with XML entities.
 * <p/>
 * To allow you to specify a fallback message inline, this funcut will
 * return the special 'fall-forward-marker' string "-" if the message
 * id is not found <em>AND</em> message id substitution is currently
 * disabled (in surrounding project or globally).
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;macrodef name="api-docs"&gt;
 *     &lt;attribute name="id"
 *          default="${<b>$message:</b>label.id?${module}}"/&gt;
 *     &lt;attribute name="label"
 *          default="${<b>$message:</b>label.main?${module},,${version}}"/&gt;
 *  ...
 *  -- To Install and Enable --
 *    &lt;managefuncuts action="install"&gt;
 *       &lt;parameter name="message"
 *             value="${oja}.messages.MessageFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class MessageFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new message function shortcut.
     **/
    public MessageFunctionShortcut()
    {
        super();
    }


    /**
     * Tries to load+form the named message string from the nearest
     * string manager. If no string manager is installed, this method
     * will use the default string manager.
     * @see org.jwaresoftware.antxtras.core.Defaults#isMessageIdSubstAllowed
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String msgid = uriFragment;

        String arg0= clnt.getName();
        if (arg0==null) {
            arg0= Strings.UNDEFINED;
        }

        boolean shorten= Iteration.defaultdefaults().isShortLocationsEnabled();
        String arg1= Tk.shortStringFrom(shorten, clnt.getLocation());

        Object[] args = new Object[]{arg0,arg1};
        int i = uriFragment.lastIndexOf(SCHEME_DELIMITER);
        if (i>0){
            msgid = uriFragment.substring(0,i);
            i += SCHEME_DELIMITER_LEN;
            if (i<uriFragment.length()) {
                args = getMessageArgs(uriFragment.substring(i),args,clnt);
            }

        }
        UIStringManager sm = UISMContext.getStringManagerNoNull();
        String msg = sm.mget(msgid,args,null);
        if (msgid==msg) {
            msg=null;
        }
        if (msg==null || ""==msg) {//NB: must differentiate constant "" from an empty msg!
            if (!Iteration.defaultdefaults().isMessageIdSubstAllowed(clnt.getProject())) {
                msg = FALL_FORWARD_MARKER;
            } else {
                msg = msgid;
            }
        }
        return msg;
    }


    /**
     * Factory method for the parameter list to pass to the 
     * string manager. Will add dynamic message parameters (up to
     * ten of them) as well as the required first two: name, location.
     * @param fragment funcut URI fragment
     * @param args01 required arguments (name,location)
     * @return final argument array (never <i>null</i>)
     * @since JWare/AntXtras 2.0.0
     **/
    private Object[] getMessageArgs(String fragment, Object[] args01, Requester clnt)
    {
        Object[] args = args01;
        List userargs = splitArgs(fragment,true,clnt);
        if (!userargs.isEmpty()) {
            args = new Object[args01.length+userargs.size()];
            for (int i=0;i<args01.length;i++) {
                args[i] = args01[i];
            }
            int N = Math.min(userargs.size(),8);
            for (int i=0;i<N;i++) {
                args[args01.length+i] = userargs.get(i);
            }
        }
        return args;
    }
}

/* end-of-MessageFunctionShortcut.java */
