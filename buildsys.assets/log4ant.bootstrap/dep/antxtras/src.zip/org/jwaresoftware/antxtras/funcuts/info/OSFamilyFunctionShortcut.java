/**
 * $Id: OSFamilyFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/
package org.jwaresoftware.antxtras.funcuts.info;

import  java.lang.reflect.Field;
import  java.lang.reflect.Modifier;
import  java.util.List;

import  org.apache.tools.ant.taskdefs.condition.Os;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns the name of the current OS 
 * family as per Ant. For families that have a plethora of variants
 * you can pass a single 'general' filter to get the family family
 * name; for example it will return 'windows' for all windows
 * varieties.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;property name="conf"
 *          value="${conf.d}/build-${<b>$osfamily:</b>}"/&gt;
 *
 *    &lt;property name="conf"
 *          value="${conf.d}/build-${<b>$osfamily:general</b>}"/&gt;

 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="osfamily"
 *             value="${ojaf}.info.OSFamilyFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since    JWare/AntXtras 2.0.0
 * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/

public final class OSFamilyFunctionShortcut extends FunctionShortcutSkeleton
{
    /*
     * Preload the list of all Ant's known OS families once. For each
     * query we just iteration the list asking Ant "is this it?". Note
     * that as-of Feb-2009, only Windows has a set of related family
     * names that we can bunch under the general 'windows' moniker.
     */
    private static final int PUBLIC_STATIC_FINAL = 
        Modifier.PUBLIC & Modifier.STATIC & Modifier.FINAL;

    private static boolean isPublicStaticFinal(Field f) {
        return (f.getModifiers()&PUBLIC_STATIC_FINAL)==PUBLIC_STATIC_FINAL;
    }

    private static final List FAMILIES = AntXFixture.newList(20);
    private static final String OSFAMILY;
    private static final String GENERAL_OSFAMILY;
    static {
        String oswindows = null;
        String osfamily  = null;
        Field[] allfields = Os.class.getDeclaredFields();
        for (int i=0,n=allfields.length;i<n;i++) {
            Field f = allfields[i];
            if (f.getName().startsWith("FAMILY_") && isPublicStaticFinal(f)) {
                try {
                    Object fn = f.get(null);
                    //ignore non-unique DOS (all winxx==dos)
                    if (!Os.FAMILY_DOS.equals(fn)) { 
                        FAMILIES.add(fn);
                    }
                } catch(Exception Xignored) {/*burp*/}
            }
        }
        for (int i=0,n=FAMILIES.size();i<n;i++) {
            String next = FAMILIES.get(i).toString();
            if (Os.isFamily(next)) {
                if (Os.FAMILY_WINDOWS.equals(next)) {
                    oswindows = next; //Look for more specific Winxx
                } else {
                    osfamily  = next;
                    //DONT BREAK-- We want to iterate all!!!
                }
            }
        }
        if (osfamily==null) {
            if (oswindows!=null) {
                osfamily = oswindows;
            } else {
                osfamily = Strings.UNDEFINED;
            }
        }
        OSFAMILY = osfamily;
        GENERAL_OSFAMILY = oswindows!=null ? oswindows : OSFAMILY;
    }


    /**
     * Initializes a new $osfamily: function shortcut.
     **/
    public OSFamilyFunctionShortcut()
    {
        super();
    }



    /**
     * Returns the name of the os family.
     */
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i==0) {
            uriFragment= "";
        } else if (i>0) {
            uriFragment= uriFragment.substring(0,i);
        }
        String osfamily = OSFAMILY;
        if ("general".equals(uriFragment)) {
            osfamily = GENERAL_OSFAMILY;
        }
        return osfamily;
    }
}


/* end-of-OSFamilyFunctionShortcut.java */
