/**
 * $Id: FixturePassthru.java 1146 2010-05-23 13:35:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Enumeration that represents the various fixture elements that 
 * an execution context can pass-along to a subcontext. The following
 * list explains what the various settings <em>typically</em> mean 
 * (refer to a task's description to get task-specific details):<ul>
 *    <li><span class="src">none</span>: No fixture information 
 *       should be passed on.</li>
 *    <li><span class="src">all</span>: All relevant fixture 
 *       information should be passed on.</li>
 *    <li><span class="src">properties</span>: Only project properties
 *        should be passed on. Similar to the common 
 *        "<span class="src">inheritAll</span>" parameter.</li>
 *    <li><span class="src">references</span>: Only project references
 *        should be passed on. Similar to the common 
 *        "<span class="src">inheritRefs</span>" parameter.</li>
 * </ul>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   api,helper
 **/

public final class FixturePassthru extends EnumSkeleton
{
    /** Index of {@linkplain #ALL ALL}. **/
    public static final int ALL_INDEX = 0;
    /** Index of {@linkplain #NONE NONE}. **/
    public static final int NONE_INDEX = ALL_INDEX+1;
    /** Index of {@linkplain #PROPERTIES PROPERTIES}. **/
    public static final int PROPERTIES_INDEX = NONE_INDEX+1;
    /** Index of {@linkplain #REFERENCES REFERENCES}. **/
    public static final int REFERENCES_INDEX = PROPERTIES_INDEX+1;


    /** Singleton "<span class="src">all</span>" choice. **/
    public static final FixturePassthru ALL=
        new FixturePassthru("all",ALL_INDEX);

    /** Singleton "<span class="src">none</span>" choice. **/
    public static final FixturePassthru NONE=
        new FixturePassthru("none",NONE_INDEX);

    /** Singleton "<span class="src">properties</span>" choice. **/
    public static final FixturePassthru PROPERTIES=
        new FixturePassthru("properties",PROPERTIES_INDEX);

    /** Singleton "<span class="src">references</span>" choice. **/
    public static final FixturePassthru REFERENCES=
        new FixturePassthru("references",REFERENCES_INDEX);


    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public FixturePassthru()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensures this enum is
     * initialized as if with the default Ant Introspector
     * helper thingy.
     **/
    private FixturePassthru(String v, int i)
    {
        super(v);
    }


    /**
     * Returns copy of all possible source values as an ordered
     * string array. Note: ordering should be same as our
     * singleton indices.
     **/
    public String[] getValues()
    {
        return new String[] {"all", "none",
                             "properties", "references"};
    };


    /**
     * Helper that converts a string to a known FixturePassthru
     * singleton. Returns <i>null</i> if string unrecognized. String
     * can be either FixturePassthru's symbolic name or its index.
     **/
    public static FixturePassthru from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            if (ALL.value.equals(s))        { return ALL; }
            if (PROPERTIES.value.equals(s)) { return PROPERTIES; }
            if (REFERENCES.value.equals(s)) { return REFERENCES; }
            if (Strings.DEFAULT.equals(s))  { return PROPERTIES; }/*std*/
            if (NONE.value.equals(s))       { return NONE; }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(String) from(String)} but with a
     * default value if supplied value does not match any known
     * FixturePassthru's name.
     * @param s the symbolic name to be matched
     * @param dflt the default FixturePassthru if necessary
     **/
    public static FixturePassthru from(String s, FixturePassthru dflt)
    {
        FixturePassthru choice= from(s);
        return (choice==null) ? dflt : choice;
    }
}

/* end-of-FixturePassthru.java */
