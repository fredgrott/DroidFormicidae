/**
 * $Id: NoneSet.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Shortcut condition that returns <i>true</i> if none of the nested
 * items (properties, variables, references, etc.) are set in the
 * project's environment.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;tally&gt;
 *     &lt;<b>noneset</b> trueproperty="clean.beginning"&gt;
 *       &lt;property name="build.number/&gt;
 *       &lt;property name="scrub.disable/&gt;
 *     &lt;/noneset&gt;
 *   &lt;/tally&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 * @see      IsNotSet
 * @see      AnySet
 **/

public final class NoneSet extends CheckSetCondition implements URIable
{
    /**
     * Initializes new NoneSet condition; defaults to
     * returning <i>false</i>.
     **/
    public NoneSet()
    {
        super(AntX.rules+"noneset");
        setNegate(true);
    }



    /**
     * Initializes a filled-in NoneSet instance.
     * @param properties comma-delimited list of properties (non-null)
     * @param P condition's project
     **/
    public NoneSet(String properties, Project P)
    {
        super(AntX.rules+"noneset",properties,P);
        setNegate(true);
    }



    /**
     * Sets this condition's list of properties as part of
     * a value URI.
     * @param fragment the value uri bits (non-null)
     * @since JWare/AntX 0.5
     */
    public void xsetFromURI(String fragment)
    {
        xsetFromURIFragment(fragment);
    }
}

/* end-of-NoneSet.java */
