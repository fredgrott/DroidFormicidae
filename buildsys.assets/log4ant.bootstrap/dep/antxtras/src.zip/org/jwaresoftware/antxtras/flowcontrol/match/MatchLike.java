/**
 * $Id: MatchLike.java 1335 2012-07-16 20:45:18Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.match;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.ownhelpers.StringEquality;

/**
 * Switch choice that matches value-under-test against a predefined
 * regular expression.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,infra
 * @see      DoMatchTaskSet
 **/

public final class MatchLike extends MatchString
{
    /**
     * Set our string equality check to be RE-based.
     **/
    private void configureTestForRE()
    {
        StringEquality eqT= getTest();
        eqT.setOperator(StringEquality.OP_MATCHES);
    }


    /**
     * Creates new nested MatchLike instance.
     **/
    public MatchLike()
    {
        super(AntX.flowcontrol+"DoMatchTaskSet:");
        configureTestForRE();
    }


    /**
     * Set the will-trim option of the switch value. The choice's
     * regular expression will <em>not</em> be touched.
     * @param trim <i>true</i> if switch value should be trimmed before test
     **/
    public void setTrim(boolean trim)
    {
        getTest().getUnknownValueGetter().setTrim(trim);
    }


    /**
     * Set the case-sensitivity of the switch value. The choice's
     * regular expression will <em>not</em> be touched.
     * @param ignore <i>true</i> if comparision should be case insensitive
     **/
    public void setIgnoreCase(boolean ignore)
    {
        getTest().getUnknownValueGetter().setIgnoreCase(ignore);
    }
}

/* end-of-MatchLike.java */
