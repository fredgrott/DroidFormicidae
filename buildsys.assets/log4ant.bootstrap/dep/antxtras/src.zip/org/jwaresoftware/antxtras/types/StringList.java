/**
 * $Id: StringList.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.types;

import  java.io.File;
import  java.util.Iterator;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.ResourceCollection;
import  org.apache.tools.ant.types.resources.StringResource;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.helpers.NoRemoveIteratorSkeleton;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.ListFriendly;
import  org.jwaresoftware.antxtras.starters.StringItemList;
import  org.jwaresoftware.antxtras.starters.StringItemListHandle;

/**
 * A list of strings as a formal Ant type. Useful to minimize those
 * "comma-delimited" lists of string, filenames, etc. that seem to
 * sprout up everywhere. Usable where a generic Ant ResourceCollection
 * of strings is useful.
 * <p>
 * <b>Examples:</b><pre>
 *     &lt;<b>strings</b> id="default.exts" prefix="*."&gt;
 *       &lt;string value="java"/&gt;
 *       &lt;string value="xml"/&gt;
 *       &lt;string value="ent"/&gt;
 *       &lt;string value="properties"/&gt;
 *     &lt;/strings&gt;
 *
 *     &lt;<b>strings</b> id="my.exts" prefix="*." file="${user.home}/.exts"/&gt;
 *
 *     &lt;<b>strings</b> id="my.exts" prefix="*." file="${user.home}/.exts"&gt;
 *        &lt;string value="xsl"/&gt;
 *        &lt;string value="php"/&gt;
 *        &lt;strings listref="defaults.exts" raw="yes"/&gt;
 *     &lt;/strings&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2005,2008,2010-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple (after fully configured)
 * @.group   api,helper
 **/

public final class StringList extends StringItemList
    implements ListFriendly, AntLibFriendly, ResourceCollection
{
    /**
     * Initializes a new StringList instance.
     **/
    public StringList()
    {
        super(AntX.fixture+"StringList:");
    }


    /**
     * Initializes a new pre-initialized StringList instance.
     **/
    public StringList(String list)
    {
        super(AntX.fixture+"StringList:",list);

    }


    /**
     * Sets a custom delimiter for this string list. This
     * delimiter is used by stringification(TM) methods.
     * @param delimiter new delimiter
     **/
    public void setDelim(String delimiter)
    {
        require_(delimiter!=null,"setDelim- nonzro delim");
        if (isReference()) {
            throw tooManyAttributes();
        }
        m_delim = delimiter;
        edited();
    }


    /**
     * Returns the delimiter this strings list will use for
     * any stringification(TM) of its contents. Defaults
     * to a comma. Never returns <i>null</i>.
     * @see AntX#DEFAULT_DELIMITER
     * @see org.jwaresoftware.antxtras.core.Defaults#delimiter()
     **/
    public String getDelim(Project fromproject)
    {
        if (isReference()) {
            return getOtherList().getDelim(fromproject);
        }
        String delim = m_delim;
        if (delim==null) {
            if (fromproject==null) fromproject = getProject();
            delim = Iteration.defaultdefaults().delimiter(fromproject,"list",true,null);
        }
        return delim;
    }


    /**
     * Sets a prefix that will be prepended to all strings
     * returned by this type.
     * @param prefix the prefix (non-null)
     * @throws BuildException if this item is a reference
     **/
    public void setPrefix(String prefix)
    {
        setPrefixString(prefix);
    }


    /**
     * Returns this string list's prefix or the empty
     * string if never set. Never returns <i>null</i>.
     **/
    public String getPrefix()
    {
        if (isReference()) {
            return getOtherList().getPrefix();
        }
        return getPrefixString();
    }


    /**
     * Set a suffix that will be appended to all strings
     * returned by this type.
     * @param suffix the suffix (non-null)
     * @throws BuildException if this item is a reference
     **/
    public void setSuffix(String suffix)
    {
        setSuffixString(suffix);
    }


    /**
     * Returns this string list's suffix or the empty
     * string if never set. Never returns <i>null</i>.
     **/
    public String getSuffix()
    {
        if (isReference()) {
            return getOtherList().getSuffix();
        }
        return getSuffixString();
    }


    /**
     * Appends the contents of a newline-delimited file to
     * this string list. No-op if file is missing or empty.
     * @param f the file (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setFile(File f)
    {
        require_(f!=null,"setfil- nonzro fil");
        addFileOrURL(f.getPath());
    }


    /**
     * Appends the contents of a newline-delimited resource
     * file to this string list. No-op if file is missing or
     * empty.
     * @param rn the resource path (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setResource(String rn)
    {
        require_(rn!=null,"setRez- nonzro reznam");
        addResource(rn);
    }


    /**
     * Appends given string (with property substitution) to
     * this string list.
     * @param string new string
     **/
    public void addConfiguredString(InnerString string)
    {
        require_(string!=null,"addStr- nonzro itm");
        addItem(string,getProject());
    }



    /**
     * Appends (in place) the strings referred to be the
     * given handle. The strings are immediately inserted!
     * @param listH reference to another list-friendly data object.
     * @since JWare/AntX 0.5
     **/
    public void addConfiguredStrings(StringItemListHandle listH)
    {
        require_(listH!=null,"addStrings- nonzro listref");
        if (isReference()) {
            throw tooManyAttributes();
        }
        Iterator itr = listH.readonlyStringIterator(getProject());
        while (itr.hasNext()) {
            String value = itr.next().toString();
            addItemFinal(value);
            edited();
        }
    }



    /**
     * Returns a delimited list of this list's contents.
     **/
    public String stringFrom(Project fromproject)
    {
        if (isReference()) {
            return getOtherList().stringFrom(fromproject);
        }
        Iterator itr= readonlyStringIterator(fromproject);
        return Tk.stringFrom(itr,getDelim(fromproject));
    }


    /**
     * Synonym for {@linkplain #stringFrom stringFrom()}.
     **/
    public String toString()
    {
        return stringFrom(getProject());
    }


    /**
     * Always returns <i>false</i> as a string list is not file
     * system bound.
     * @since JWare/AntXtras 2.0.0
     */
    public boolean isFilesystemOnly()
    {
        return false;
    }


    /**
     * Returns a ResourceCollection compatible iterator that wraps
     * each of this string list's string items in a StringResource
     * wrapper.
     * @since JWare/AntXtras 2.0.0
     */
    public Iterator iterator()
    {
        String[] strings = copyOfStrings(getProject(), PROCESSED);
        return new RCIterator(strings,getProject());
    }


    private final StringList getOtherList()
    {
        return (StringList)getOtherItemList(StringList.class);
    }


    private String m_delim = AntX.DEFAULT_DELIMITER;


    /**
     * Adapter iterator that wraps a string list's strings as
     * StringResource object.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   impl,helper
     */
    private static final class RCIterator extends NoRemoveIteratorSkeleton
    {
        private final Project myproject;
        private final String[] strings;
        private int cursor=0;

        RCIterator(String[] strings, Project project) {
            this.myproject = project;
            this.strings = strings;
        }
        public boolean hasNext() {
            return cursor<strings.length;
        }
        public Object next() {
            String nextstring = strings[cursor++];
            StringResource sr = new StringResource(nextstring);
            sr.setProject(myproject);
            return sr;
        }
    }
}

/* end-of-StringList.java */
