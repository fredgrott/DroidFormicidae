/**
 * $Id: PerformTaskTask.java 428 2008-04-27 13:12:32Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.UnknownElement;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.ownhelpers.UEContainerProxy;

/**
 * Executes a previously cached task instance. The instance's reference is automatically
 * removed from the project's reference table unless the <span class="src">keep</span>
 * option is activated.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;assign var="_junitinstance" value="${$random:string}"/&gt;
 *    &lt;createtask name="${$var:_junitinstance}"&gt;
 *       &lt;junit printsummary="yes" haltonfailure="yes"&gt;
 *          &#8230;
 *       &lt;/junit&gt;
 *    &lt;/createtask&gt;
 *    &#8230;<i>[alter task definition]</i>
 *    &lt;<b>performtask</b> name="${$var:_junitinstance}" keep="no"/&gt;
 *    &lt;unassign var="_junitinstance"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 * @see       CreateTaskTask
 **/

public final class PerformTaskTask extends AssertableTask
{
    /**
     * Initializesa new performtask task instance.
     **/
    public PerformTaskTask()
    {
        super(AntX.construct+"PerformTaskTask:");
    }



    /**
     * Tells this editor the reference id of the task under construction.
     * This task should've been installed by the AntX task creator method.
     * @param refId reference id of task under construction (non-null)
     **/
    public void setName(String refId)
    {
        require_(refId!=null,"setName- nonzro refid");
        m_itemUC = (UEContainerProxy)FixtureExaminer.getReferencedObject(getProject(),
            new Requester.ForComponent(this), refId, UEContainerProxy.class);
        m_itemUCRefId = refId;
    }



    /**
     * Tells this task whether it should clear the task under construction
     * after it's been performed (the default). Only keep components that
     * can be reset.
     * @param keepIt <i>true</i> to keep task under construction
     **/
    public void setKeep(boolean keepIt)
    {
        m_purgeRefId = !keepIt;
    }



    /**
     * Ensures the referenced item under construction's proxy is performed.
     * If the proxy is to be kept, a <em>copy</em> of the proxy is performed;
     * the original is left intact.
     * @see #setKeep setKeep(&#8230;)
     */
    public void execute()
    {
        verifyCanExecute_("exec");

        if (m_purgeRefId) {
            getProject().getReferences().remove(m_itemUCRefId);
            m_itemUCRefId = null;
        }
        UnknownElement ue = m_itemUC.getUE();
        if (!m_purgeRefId) {
            ue = TaskExaminer.copyUEProxy(ue,getProject(),null);
        }
        ue.setLocation(getLocation());
        ue.perform();
        m_itemUC = null;
    }



    /**
     * Ensures we've been given a reference to a task to perform.
     */
    protected void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);

        if (m_itemUC==null) {
            String ermsg = uistrs().get("task.needs.name", getTaskName());
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }


    private UEContainerProxy m_itemUC;//item under construction (non-null after name known)
    private String m_itemUCRefId;
    private boolean m_purgeRefId=true;//Remove task under construction from project
}

/* end-of-PerformTaskTask.java */