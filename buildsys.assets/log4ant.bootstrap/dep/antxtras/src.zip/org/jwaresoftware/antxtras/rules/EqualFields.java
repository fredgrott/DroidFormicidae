/**
 * $Id: EqualFields.java 1467 2012-08-11 23:12:04Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Diagnostics condition that verifies two fields on two different objects
 * are equivalent. Can also be configured to verify that a single object
 * field is <i>null</i>.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2002-2004,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,test,helper
 * @see      AssertTask
 **/

final class EqualFields extends AssertableProjectComponent
    implements Condition
{
    /**
     * Initializes a new EqualFields condition.
     **/
    EqualFields()
    {
        super(AntX.conditions);
    }


    /**
     * Sets the name of the first reference.
     * @param refid reference identifier (non-null)
     **/
    void setItem1(String refid)
    {
        require_(refid!=null,"setItem1- nonzro refid");
        m_item1 = refid;
    }


    /**
     * Returns project field for given reference item. Can be easily
     * genericized to look for any field if this is ever useful.
     * @throws BuildException if field not properly specified
     **/
    private Object getItemField(String refid)
    {
        if (refid==null) {
            throw new BuildException();
        }
        Object obj = getProject().getReference(refid);
        if (!(obj instanceof ProjectComponent)) {
            String have = (obj!=null) ? obj.getClass().getSimpleName() : Strings.NULL;
            String err  = Errs.BadReferenceId(refid, "ProjectComponent", have);
            log(err,Project.MSG_ERR);
            throw new BuildException(err);
        }
        return ((ProjectComponent)obj).getProject();
    }


    /**
     * Returns <i>true</i> if the two objects have equivalent projects.
     * @throws BuildException if not properly defined
     **/
    public boolean eval()
    {
        verifyInProject_("eval");
        Object P1 = getItemField(m_item1);
        return P1==getProject();
    }

    private String m_item1;
}

/* end-of-EqualFields.java */
