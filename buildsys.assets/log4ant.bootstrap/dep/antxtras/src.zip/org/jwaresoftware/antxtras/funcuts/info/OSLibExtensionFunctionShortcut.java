/**
 * $Id: OSLibExtensionFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/
package org.jwaresoftware.antxtras.funcuts.info;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.go.IffOs;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns the proper extension for a native library depending
 * on the current runtime platform. Defaults to "<span class="src">dll</span>" for 
 * Windows and "<span class="src">so</span>" for all other platforms. The general
 * format of the URI is: <span class="src">$oslibext:[default]</span> where 
 * <span class="src">[default]</span> is used if handler doesn't know what the
 * extension for current platform should be (will be the empty string if [default] 
 * is empty). Note that this funcut does <em>not</em> include the &#46;(dot) prefix
 * of the extensions!
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;property name="native.library"
 *          value="${libs}/libwidgets-1.${<b>$oslibext:</b>}"/&gt;
 *
 *    &lt;property name="native.library"
 *           value="${libs}/libwidgets-1.${<b>$oslibext:lib</b>}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="oslibext"
 *             value="${ojaf}.info.OSLibExtensionFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.6
 * @author   ssmc, &copy;2005-2006,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/

public final class OSLibExtensionFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new oslibext function shortcut.
     **/
    public OSLibExtensionFunctionShortcut()
    {
        super();
    }



    /**
     * Returns the library extension for current runtime OS.
     */
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i==0) {
            uriFragment= "";
        } else if (i>0) {
            uriFragment= uriFragment.substring(0,i);
        }
        IffOs.Is t = new IffOs.Is();
        t.setParameter("windows");
        if (t.pass(clnt.getProject())) {
            return "dll";
        }
        t.setParameter("unix");
        if (t.pass(clnt.getProject())) {
            return "so";
        }
        return uriFragment;
    }
}


/* end-of-OSLibExtensionFunctionShortcut.java */
