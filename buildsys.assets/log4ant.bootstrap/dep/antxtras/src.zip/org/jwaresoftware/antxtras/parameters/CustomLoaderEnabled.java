/**
 * $Id: CustomLoaderEnabled.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;

/**
 * Mixin interface for a component that supports custom class and
 * resource loading options. The component will use the custom
 * classpath when searching for and/or loading resources.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface CustomLoaderEnabled extends RefLoaderEnabled
{
    /**
     * Adds an existing classpath element to this component's
     * custom classpath.
     * @param r reference to an existing path item (non-null)
     **/
    void setClassPathRef(Reference r);


    /**
     * Returns this component's custom classpath. Can return
     * <i>null</i> if custom path never created.
     **/
    Path getClassPath();


    /**
     * Tells this component to use an existing classloader to
     * search and/or load resources.
     * @param r reference to an existing ClassLoader (non-null)
     **/
    void setLoaderRef(Reference r);


    /**
     * Returns this component's own loader identifier based on
     * its <em>current</em> configuration; specifically the last
     * assigned loader reference or the last classpath reference
     * assigned.
     **/
    String getLoaderRefId();
}

/* end-of-CustomLoaderEnabled.java */
