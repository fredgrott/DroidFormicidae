/**
 * $Id: RecoveryEnabled.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that can recover (or fail gracefully)
 * from an error during execution or configuration. Forces item to support
 * the "<span class="src">haltiferror=[yes|no]</span>" parameter.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,helper
 **/

public interface RecoveryEnabled
{
    /**
     * Tells this component whether it should generate a build exception
     * or try to recover from any errors.
     **/
    void setHaltIfError(boolean halt);


    /**
     * Returns <i>true</i> if this component will generate a build
     * exception if it has any problems. Usually defaults to
     * <i>true</i>.
     **/
    boolean isHaltIfError();
}

/* end-of-RecoveryEnabled.java */
