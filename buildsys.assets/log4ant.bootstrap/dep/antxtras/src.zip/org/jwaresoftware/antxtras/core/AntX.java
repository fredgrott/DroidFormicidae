/**
 * $Id: AntX.java 1311 2012-07-07 19:18:04Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.apache.tools.ant.Main;

import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.internal.apis.UIStringManager;
import  org.jwaresoftware.internal.uism.BundleStringManager;

/**
 * Collection of common AntXtras properties and constants.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2007-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/

public final class AntX
{
//----------------------------------------------------------------------------------------
// Package and configuration identifiers
//----------------------------------------------------------------------------------------
    /**
     * A fallback name of <i>AntXtras</i> package(s) when buildstrs and other
     * localized resource information is unavailable. Useful for diagnostics.
     * Defined as "<i>JWare&#46;AntXtras</i>".
     **/
    public static final String ANTX_FALLBACK_NAME =
        "JWare.AntXtras";


    /**
     * The standard package prefix for this <i>AntXtras</i> implementation.
     * Defined as "<i>org&#46;jwaresoftware&#46;antxtras</i>".
     **/
    public static final String ANTX_PACKAGE_PREFIX =
        "org.jwaresoftware.antxtras";


    /**
     * The default prefix for <i>AntXtras</i> configuration properties; usually
     * "<i>jware.antxtras</i>".  Properties within class-specific files are not
     * required to have this prefix. However, if the property can be specified
     * on the command-line it must have this identifying prefix.
     **/
    public static final String ANTX_CONFIG_ID =
        "jware.antxtras";



    /**
     * Property prefix for all AntXtras and AntXtras-dependent project's default
     * properties. Defined as {@value}. Example use: {@value}ped4ant&#46;noiselevel.
     * @since JWare/AntXtras 2.0.0
     **/
    public static final String ANTX_CONFIG_DEFAULTS_PREFIX =
        ANTX_CONFIG_ID+".defaults.";


    /**
     * The default prefix for internal <i>AntXtras</i> configuration properties.
     * These properties are used between AntXtras class implementations; they
     * should not be defined or modified by user scripts.
     **/
    public static final String ANTX_INTERNAL_ID =
        ANTX_CONFIG_ID+".internal_.";


//----------------------------------------------------------------------------------------
// AntXtras configuration properties (all fully qualified property names)
//----------------------------------------------------------------------------------------

    /** Property for default AntXtras noise-level. **/
    public final static String DEFAULT_NOISELEVEL_PROP =
        ANTX_CONFIG_DEFAULTS_PREFIX+"noiselevel";


    /** Property for default AntXtras temporary file-system object prefix. **/
    public final static String DEFAULT_TEMPOBJECT_PREFIX_PROP =
        ANTX_CONFIG_DEFAULTS_PREFIX+"tempobject.prefix";


    /** Property to control whether AntXtras tasks verify content on load. **/
    public final static String STRICT_SCRIPTCHECK_PROP=
        ANTX_CONFIG_ID+".strict.scriptcheck.enabled";


    /** Property for default AntXtras ifError feedback-level. **/
    public final static String DEFAULT_IFERROR_FEEDBACK_LEVEL_PROP =
        ANTX_CONFIG_DEFAULTS_PREFIX+"iferror.feedback";


//----------------------------------------------------------------------------------------
// AntXtras defaults for required configuration properties (source shouldn't use other)
//----------------------------------------------------------------------------------------

    /** The default diagnostics and other message noise level (<i>info</i>). **/
    public final static String DEFAULT_NOISELEVEL = "info";


    /** The default per-task feedback level (<i>normal</i>). **/
    public final static String DEFAULT_FEEDBACK_LEVEL = "normal";


    /** The default delimiter used in delimited string lists. **/
    public final static String DEFAULT_DELIMITER= ",";


//----------------------------------------------------------------------------------------
// AntXtras tracing and assertion categories
//----------------------------------------------------------------------------------------

    /** Top of JWare's AntXtras namespace for error messages and assertions. **/
    public final static String AntX= ANTX_FALLBACK_NAME+".";

    /** AntXtra's "no-package" or core module identifier. **/
    public final static String nopackage= AntX+"Core";

    /** AntXtra's UISM and messages sub-module identifier. **/
    public final static String messages= AntX+"Messages.";

    /** AntXtra's rules sub-module identifier. **/
    public final static String rules= AntX+"Rules.";

    /** AntXtra's rules conditions sub-module identifier. **/
    public final static String conditions= rules+"Conditions.";

    /** AntXtra's rules capture module identifier.
     * @since JWare/AntX 0.5
     **/
    public final static String capture= rules+"Capture.";

    /** AntXtra's construct helpers sub-module identifier.
     *  @since JWare/AntX 2.0
     **/
    public final static String construct= AntX+"Construct.";

    /** AntXtra's flowcontrol module identifier. **/
    public final static String flowcontrol= AntX+"FlowControl.";

    /** AntXtra's print sub-module identifier. **/
    public final static String print= AntX+"Print.";

    /** AntXtra's filesystem helpers sub-module identifier. **/
    public final static String filesystem= AntX+"FileSystem.";

    /** AntXtra's starters sub-module identifier. **/
    public final static String starters= AntX+"Starters.";

    /** AntXtra's feedback (emit) module identifier. **/
    public final static String feedback= AntX+"Feedback.";

    /** AntXtra's general utilities group identifier.
     *  @since JWare/AntX 0.4
     **/
    public final static String utilities= AntX+"Helpers.";

    /** AntXtra's general fixture element group identifier.
     *  @since JWare/AntX 0.5
     **/
    public final static String fixture= AntX+"Fixture.";

    /** AntXtra's function shortcuts group identifier.
     *  @since JWare/AntXtras 2.0.0
     **/
    public final static String funcuts= AntX+"Funcuts.";


//----------------------------------------------------------------------------------------
// AntXtra (project) fixed UI-Strings
//----------------------------------------------------------------------------------------

    private static UIStringManager sm_UISM=
        new BundleStringManager(ANTX_PACKAGE_PREFIX+".core.UIStrings");


    /**
     * Returns instance of the <em>internal JWare/AntXtras</em> UIStringManager.
     * This manager is <em>not</em> controlled by any task's 'messageid' attribute
     * or otherwise. The underlying bundle is part of the AntXtras class package.
     **/
    public static final UIStringManager uistrs()
    {
        return sm_UISM;
    }


    /**
     * Message id of common "clone is really broken" associated with Cloneables
     * capturing a CloneNotSupportedException. Should never happen, but&#46;&#46;&#46;
     **/
    public static final String CLONE_BROKEN_MSGID= "cv.clone.broken";


//----------------------------------------------------------------------------------------
// AntXtra global constants initialized on class-load (once)
//----------------------------------------------------------------------------------------


    /**
     * True if AntXtras tasks should verify themselves (or their contents)
     * as they're being created instead of just before they're executed.
     * Defaults <i>false</i>. This property is to counteract Ant 1.6+
     * mapping of <em>all</em> script elements to UnknownElement
     * placeholders until just before execution or referenced.
     * @since JWare/AntX 0.4
     * @see #STRICT_SCRIPTCHECK_PROP
     **/
    public static final boolean STRICT_SCRIPTS;


    /**
     * Contains the current Ant runtime's version string as best we can
     * determine without explicitly reading the version information ourselves.
     * @since JWare/AntXtras 0.5.1
     */
    public static final String ANT_VERSIONSTRING;


    /**
     * Static initializer for the Ant version related AntXtras globals.
     **/
    static {
        //NB: This is a fracking hack to deal with Ant's inability to make up
        //    its mind regarding build file parsing and component initialization!
        String versionstring= Strings.UNDEFINED;
        String av = Main.getAntVersion();
        final int _0 = av.indexOf("Ant version ");
        final int _1 = av.indexOf("Ant(TM) version ");//asof Ant 1.8.2
        final int _n = av.indexOf(" compiled");
        if (_0>=0 && _n>0) {
            versionstring = av.substring(_0+"Ant version ".length(),_n);
        } else if (_1>=0 && _n>0) {
            versionstring = av.substring(_1+"Ant(TM) version ".length(),_n);
        }
        String s = System.getProperty(STRICT_SCRIPTCHECK_PROP);
        if (s!=null) {
            STRICT_SCRIPTS = Tk.booleanFrom(s);
        } else {
            STRICT_SCRIPTS = true; //Ant 1.6,1.7
        }
        ANT_VERSIONSTRING = versionstring;
    }


//----------------------------------------------------------------------------------------
// AntXtra's general pre/post condition validation utility methods
//----------------------------------------------------------------------------------------

    /**
     * Throws an illegal argument exception if a pre-condition
     * is not met.
     * @param c the pre-condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalArgumentException if condition not met
     * @since JWare/AntX 0.4
     **/
    public static final void require_(boolean c, String iam, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.require",iam,msg);
            throw new IllegalArgumentException(ermsg);
        }
    }



    /**
     * Throws an illegal state exception if condition is not met.
     * Used for block and invariant verification.
     * @param c condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalStateException if condition not met
     * @since JWare/AntX 0.4
     **/
    public static final void verify_(boolean c, String iam, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.verify",iam,msg);
            throw new IllegalStateException(ermsg);
        }
    }



    /** -- nope nope -- prevent construction of any instances -- **/
    private AntX() { }
}

/* end-of-AntX.java */
