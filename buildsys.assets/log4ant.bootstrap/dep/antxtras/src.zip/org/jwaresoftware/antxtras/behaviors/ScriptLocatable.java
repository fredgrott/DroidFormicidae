/**
 * $Id: ScriptLocatable.java 388 2008-03-30 15:44:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Location;

/**
 * Mixin interface for an object that supports the standard Ant (parse) location
 * APIs. If a class implements this interface, it's saying it <em>knows</em> that
 * its instances are most often created from script-supplied instructions. Objects
 * like {@linkplain Requester Requesters} are not necessarily script-bound and
 * therefore do not automatically link in this interface.
 * <p/>
 * If the Ant infrastructure ever supplies components and other data types with a
 * location accessor, we can easily link this interface to that information.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   n/a
 * @.group    api,infra
 **/

public interface ScriptLocatable
{
    /**
     * Returns this object's script location information. While
     * this method could return the <span class="src">UNKNOWN_LOCATION</span>
     * marker, it usually would not. Must never return <i>null</i>.
     **/
    Location getLocation();
}


/* end-of-ScriptLocatable.java */