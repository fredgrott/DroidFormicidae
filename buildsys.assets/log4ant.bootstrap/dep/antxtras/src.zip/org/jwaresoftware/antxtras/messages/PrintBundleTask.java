/**
 * $Id: PrintBundleTask.java 1510 2012-09-24 23:26:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.io.IOException;
import  java.io.OutputStream;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.TestScriptComponent;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.starters.EchoThingTask;

/**
 * Helper task to display contents of a {@linkplain MessagesBundle}. Mostly used
 * for debugging and during unit tests.
 * <p>
 * <b>Example Usage:</b><pre>
 *  &lt;<b>printbundle</b> bundleid="default-msgs"/&gt;
 *
 *  &lt;<b>printbundle</b> bundleid="default-msgs" 
 *          message="Default messages:"
 *          tofile="/tmp/default.msgs" if="debug.bundles"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2005,2008-2009,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @see      MessagesBundle
 **/

public final class PrintBundleTask extends EchoThingTask
    implements TestScriptComponent
{
    /**
     * Initializes new PrintBundleTask.
     **/
    public PrintBundleTask()
    {
        super(AntX.print);
    }



    /**
     * Initializes enclosed CV-labeled PrintBundleTask.
     **/
    public PrintBundleTask(String iam)
    {
        super(iam);
    }



    /**
     * Initializes the MessagesBundle reference id for this task.
     **/
    public void setBundleId(String refId)
    {
        setThingRefId(refId);
    }



    /**
     * Returns the MessagesBundle's reference id; can be <i>null</i>
     * if never set. Required for task to execute properly.
     **/
    public final String getBundleRefId()
    {
        return getThingRefId();
    }



    /**
     * Returns the actual {@linkplain MessagesBundle} echoed by this
     * task. Never returns <i>null</i>.
     * @throws BuildException if bundle refid undefined or not a MessagesBundle
     **/
    public final MessagesBundle getReferencedBundle()
        throws BuildException
    {
        return (MessagesBundle)getReferencedThing
            (MessagesBundle.class,"task.uism.bad.refid");
    }



    /**
     * Ensures we're in a valid target/project and have a valid bundle
     * reference id.
     * @throws BuildException if verify fails
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);
        getReferencedBundle();//NB: ensures refid -> MessagesBundle
    }



    /**
     * Writes the referenced bundle as a properties object to this task's
     * specified output stream (file|stdout).
     * @throws BuildException if file I/O occurs
     **/
    protected void echoThing() throws BuildException
    {
        OutputStream os = getOutputStream();
        Properties msgs = getReferencedBundle().newProperties(null);

        try {
            msgs.store(os,getMsg());

            if (tryAntLog(os)) {
                log(getAntLogString(os),getNoiseLevel().getNativeIndex());
            }

        } catch(IOException ioX) {
            String ermsg = uistrs().get("task.echo.unable");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());

        } finally {
            closeOutputStream(os);
            os=null;
            msgs.clear();
            msgs=null;
        }
    }
}

/* end-of-PrintBundleTask.java */
