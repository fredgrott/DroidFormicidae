/**
 * $Id: InformationSaver.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that can write some kind of
 * captured information to the file system. The item must support
 * (at least) the standard '<span class="src">tofile=path</span>' and
 * '<span class="src">append=[yes|no]</span>' short-hand parameters.
 * Whether the parameter should specify a file, directory, or both
 * is implementation specific.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,helper
 **/

public interface InformationSaver
{
    /**
     * Sets the file path for this item's captured output.
     * Whether the path represents a full path or a project-relative
     * path is up to this interface's implementation.
     * @param outputFile the output file's path (non-null)
     **/
    void setToFile(String outputFile);


    /**
     * Returns this item's target file path for output. Can return
     * <i>null</i> if never set. Whether this is an absolute or
     * relative path is implementation defined.
     **/
    String getToFilePath();



    /**
     * Marks whether this item should try to append its new
     * information to its output stream.
     * @param append <i>true</i> if should try to append
     **/
    void setAppend(boolean append);


    /**
     * Returns <i>true</i> if this item will try to append
     * any new information to an existing output sink.
     **/
    boolean willTryAppend();
}

/* end-of-InformationSaver.java */
