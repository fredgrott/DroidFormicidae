/**
 * $Id: IsClass.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.Available;
import  org.apache.tools.ant.taskdefs.condition.Condition;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Adapter that allows &lt;available class="&#46;&#46;&#46;"/&gt; to be
 * inlined in boolean rules as &lt;require isclass="&#46;&#46;&#46;"/&gt;.
 * Delegates to a private <span class="src">Available</span> condition.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single (see Available)
 * @.group   impl,helper
 * @.pattern GoF.Adapter
 **/

public final class IsClass extends AssertableProjectComponent
    implements Condition, URIable
{
    /**
     * Creates new IsClass condition.
     **/
    public IsClass()
    {
        m_impl = new Available();
    }



    /**
     * Creates a new pre-initialized IsClass condition.
     * @param value resource name/path to be located.
     * @see #setName
     **/
    public IsClass(String value)
    {
        this();
        setName(value);
    }



    /**
     * Sets this condition's project; updates underlying available
     * condition too.
     **/
    public void setProject(Project p)
    {
        super.setProject(p);
        m_impl.setProject(p);
    }



    /**
     * Sets the name of the class to be located.
     * @param classname class name (non-null)
     **/
    public void setName(String classname)
    {
        require_(classname!=null,"setval- nonzro clazname");
        m_impl.setClassname(classname);
    }



    /**
     * Set the classpath to be used when searching for the class.
     * @param classpath an search path (non-null)
     */
    public void setClasspath(Path classpath)
    {
        require_(classpath!=null,"setCP- nonzro cp");
        m_impl.setClasspath(classpath);
    }



    /**
     * Like {@linkplain #setClasspath setClasspath} but by reference.
     * @param r a Reference to a Path instance to be used as classpath (non-null)
     */
    public void setClasspathRef(Reference r)
    {
        require_(r!=null,"setCPref- nonzro cp refid");
        m_impl.setClasspathRef(r);
    }



    /**
     * Sets whether Ant's runtime classes will be included in search
     * classpath. "<i>true</i>" by default.
     * @param include <i>false</i> if Ant's classes excluded
     */
    public void setSystemClasses(boolean include)
    {
        m_impl.setIgnoresystemclasses(!include);
    }



    /**
     * Sets property name updated by <i>true</i> evaluation.
     * @param property the property's name (non-null)
     * @since JWare/AntX 0.3
     **/
    public void setTrueProperty(String property)
    {
        require_(property!=null,"setTrueProp- nonzro name");
        m_updateProperty = property;//NB:don't use available's property
    }



    /**
     * Returns property name updated by evaluation method. Returns
     * <i>null</i> if never set or value is an exported property.
     * @since JWare/AntX 0.3
     **/
    public final String getTrueProperty()
    {
        return m_updateProperty;
    }



    /**
     * Sets this condition's target class name as part of a
     * value URI.
     * @param fragment the value uri bits (non-null)
     * @since JWare/AntX 0.5
     */
    public void xsetFromURI(String fragment)
    {
        setName(fragment);
    }



    /**
     * Checks whether given class exists (and is loadable) or not.
     * @throws BuildException if incomplete set or unable to check condition
     **/
    public boolean eval() throws BuildException
    {
        verifyInProject_("eval");

        boolean istrue = m_impl.eval();

        if (istrue && m_updateProperty!=null) {
            log("IsClass was true; setting true-property '"+m_updateProperty+
                "' property",  Project.MSG_DEBUG);
            getProject().setNewProperty(m_updateProperty,Strings.TRUE);
        }

        return istrue;
    }


    private Available m_impl;
    private String m_updateProperty;
}

/* end-of-IsClass.java */
