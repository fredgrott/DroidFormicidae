/**
 * $Id: UnassignTask.java 1349 2012-07-21 17:05:19Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.variables;

import  java.util.Collections;
import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Helper task that removes fixture elements like variables, references, and even
 * properties. You cannot remove command properties (like system and command-line
 * directives), but you can set them to the empty string. For delimited multiple
 * names, unassign pays attention to the current list delimiter that is installed
 * (either at project or system level).
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;unassign var="__bn"/&gt;
 *  &lt;unassign ref="ant.PropertyHelper" feedback="quiet"/&gt;
 *  &lt;unassign references="main.path,test.path"/&gt;
 *  &lt;unassign property="defaults.noiselevel"/&gt;
 *  &lt;unassign vars="nextfile,lasterror"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 * @see       AssignTask
 **/

public class UnassignTask extends AssertableTask
    implements FlexValueSupport, AntLibFriendly
{
    private static final int _NOTYPE= -1;//NB: must be invalid array index!


    /**
     * Initializes a new unassign task instance. This task's
     * source must be defined before it is executed.
     **/
    public UnassignTask()
    {
        super(AntX.fixture+"UnassignTask:");
    }


//  ---------------------------------------------------------------------------------------
//  Script-facing Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Sets the property which this task will unassign (set to empty
     * string). Before changing the property's value, this task will
     * check the property against the project's current list of user
     * properties. If there is a match, a build exception is thrown.
     * @param property the property to 'unassign' (non-null)
     * @throws BuildException if property is an immutable property.
     */
    public void setProperty(String property)
    {
        require_(property!=null,"setProperty- nonzro name");
        verifyNotNamed();
        if (getProject().getUserProperty(property)!=null) {
            String error = getAntXMsg("task.cant.repl.userprop",property);
            log(error,Project.MSG_ERR);
            throw new BuildException(error, getLocation());
        }
        m_name = property;
        m_type = IsA.PROPERTY_INDEX;
    }



    /**
     * Sets the delimited list of properties to set empty.
     * @param properties list of property names to set empty (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public final void setProperties(String properties)
    {
        setProperty(properties);
        m_multiple=true;
    }



    /**
     * Sets the variable which this task will unassign. The variable
     * is removed unconditionally.
     * @param variable name of variable to unassign (non-null)
     */
    public void setVariable(String variable)
    {
        require_(variable!=null,"setVariable- nonzro name");
        verifyNotNamed();
        m_name = variable;
        m_type = IsA.VARIABLE_INDEX;
    }



    /**
     * Synonym for {@linkplain #setVariable setVariable}.
     **/
    public final void setVar(String variable)
    {
        setVariable(variable);
    }



    /**
     * Sets the delimited list of variables to unassign.
     * @param variables list of variable names to unassign (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public final void setVars(String variables)
    {
        setVariable(variables);
        m_multiple=true;
    }



    /**
     * Sets the reference which this task will unassign. The reference
     * is removed unconditionally; however, references that begin with
     * "<span class="src">ant.</span>" will cause a warning to be
     * registered unless the {@linkplain #setFeedback quiet option} has
     * been set.
     * @param refid name of reference to unassign (non-null)
     */
    public void setReference(String refid)
    {
        require_(refid!=null,"setReference- nonzro name");
        verifyNotNamed();
        m_name = refid;
        m_type = IsA.REFERENCE_INDEX;
    }



    /**
     * Synonym for {@linkplain #setReference setReference}.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void setRef(String refid)
    {
        setReference(refid);
    }



    /**
     * Sets the delimited list of references to unassign.
     * @param refids list of reference names to unassign (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public final void setRefs(String refids)
    {
        setReference(refids);
        m_multiple=true;
    }



    /**
     * Instructs this unassigner whether to issue warnings when
     * told to unassign seemingly reserved fixture bits.
     * @param level feedback level (non-null).
     * @throws BuildException if unrecognized feedback level.
     **/
    public void setFeedback(String level)
    {
        require_(level!=null,"setFeedback- nonzro level");
        FeedbackLevel fb = FeedbackLevel.from(level);
        if (fb==null) {
            String e = Errs.IllegalParameterValue(getTaskName(),"feedback",level);
            log(e, Project.MSG_ERR);
            throw new BuildException(e, getLocation());
        }
        m_fbLevel = fb;
    }


//  ---------------------------------------------------------------------------------------
//  Execution:
//  ---------------------------------------------------------------------------------------

    /**
     * Verifies that a source element has been specified.
     * @param calr calling method (non-null)
     * @throws BuildException if neither a variable, reference,
     *  nor property has been specified.
     */
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);
        if (m_name==null) {
            String error = Errs.NeedsThisAttribute(getTaskName(),"property|reference|variable");
            log(error, Project.MSG_ERR);
            throw new BuildException(error, getLocation());
        }
    }



    /**
     * Removes the indicated fixture element. Note that properties
     * cannot be completely removed (no way via APIs); instead, their
     * values are (re)set to the empty string.
     */
    public void execute()
    {
        verifyCanExecute_("exec");

        final Project fromproject = getProject();
        List names;
        if (m_multiple) {
            names = LocalTk.splitList(m_name,fromproject);
        } else {
            names = Collections.singletonList(m_name);
        }
        switch(m_type) {
            case IsA.PROPERTY_INDEX: {
                PropertyHelper ph = PropertyHelper.getPropertyHelper(fromproject);
                synchronized(ph) {
                    for (int i=0,n=names.size();i<n;i++) {
                        String name = names.get(i).toString();
                        if (ph.getProperty(name)!=null) {
                            ph.setProperty(name,"",false);
                        }
                    }
                }
                break;
            }
            case IsA.VARIABLE_INDEX: {
                Requester rqlink = new Requester.ForComponent(this);
                for (int i=0,n=names.size();i<n;i++) {
                    Variables.delete(names.get(i).toString(),rqlink);
                }
                break;
            }
            case IsA.REFERENCE_INDEX: {
                for (int i=0,n=names.size();i<n;i++) {
                    String name = names.get(i).toString();
                    if (name.startsWith("ant.") &&
                        !FeedbackLevel.isQuietish(m_fbLevel,true)) {
                        String warning = getAntXMsg("unassign.warn.ant.runtime.ref",name);
                        log(warning, Project.MSG_VERBOSE);
                    }
                    fromproject.getReferences().remove(name);
                }
                break;
            }
        }
    }



    /**
     * Ensures this task has not been assigned a fixture data
     * source already.
     * @param errid [optiona] id of error message to use
     **/
    protected final void verifyNotNamed(String errid)
    {
        if (m_name!=null) {
            if (errid==null) {
                errid = Errs.TooManyFlexibleAttributes();
            }
            String error = getAntXMsg(errid);
            log(error, Project.MSG_ERR);
            throw new BuildException(error, getLocation());
        }
    }


    private void verifyNotNamed()
    {
        verifyNotNamed(null);
    }


    private String m_name;
    private int m_type=_NOTYPE;
    private boolean m_multiple=false;
    private FeedbackLevel m_fbLevel=FeedbackLevel.NORMAL;
}

/* end-of-UnassignTask.java */