/**
 * $Id:$
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.install;

import  java.util.Properties;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.internal.apis.Buildstrs;

/**
 * BuildInfo implementation that gets its information from a single properties file.
 * How the file is loaded is determined by user of this class.
 *
 * @since     JWare/AntX 0.6
 * @author    ssmc, &copy;2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    impl,helper
 * @see       VendorInfoTask
 **/

public final class PropertiesBasedBuildInfo implements Buildstrs
{
    private static final String IAM_= "PropertiesBasedBuildInfo:";

    public PropertiesBasedBuildInfo()
    {
    }

    public PropertiesBasedBuildInfo(Properties information)
    {
        this.setProperties(information);
    }

    public void setProperties(Properties information) 
    {
        AntX.require_(information!=null,IAM_,"setProperties- nonzro source");
        m_versionInfo = information;
    }

    public String getAbbrDate()
    {
        return getProperty("abbrDate");
    }

    public String getBuildVersion()
    {
        return getProperty("buildVersion");
    }

    public String getBuilderCN()
    {
        return getProperty("builderCN","");
    }

    public String getBuilderID()
    {
        return getProperty("builderID","");
    }

    public String getDisplayName()
    {
        return getProperty("displayName");
    }

    public String getHostID()
    {
        return getProperty("hostID","");
    }

    public String getID()
    {
        return getProperty("ID");
    }

    public String getLongDate()
    {
        return getProperty("longDate");
    }

    public String getNSPrefix()
    {
        return getProperty("NSPrefix","");
    }

    public String getNSURI()
    {
        return getProperty("NSURI","");
    }

    public String getOS()
    {
        return getProperty("OS","");
    }

    public String getPropertiesPrefix()
    {
        return getProperty("propertiesPrefix","");
    }

    public String getUsedPaths()
    {
        return getProperty("usedPaths","");
    }

    public String getVersion()
    {
        return getProperty("version");
    }

    private String getProperty(String property, String defaultValue)
    {
        if (m_versionInfo!=null) {
            return m_versionInfo.getProperty(property, defaultValue);
        }
        return Strings.UNDEFINED;
    }

    private String getProperty(String property)
    {
        return getProperty(property,Strings.UNDEFINED);
    }

    private Properties m_versionInfo;
}

/* end-of-PropertiesBasedBuildInfo.java */
