/**
 * $Id: VendorInfoFunctionShortcut.java 1219 2011-08-13 01:21:36Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.install;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;
import  org.jwaresoftware.internal.apis.Buildstrs;
import  org.jwaresoftware.internal.helpers.EmptyBuildstrs;

/**
 *  Function shortcut that returns a particular vendor info field. Useful
 *  if you don't want to load all the vendor info into project properties
 *  just to read one field (like display name or version).
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;show message="AntXtras RELEASE: ${<b>$vendorinfo:</b>}"/&gt;
 *
 *    &lt;property name="VERSION"
 *       value="${<b>$vendorinfo:svn4ant?version</b>}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="vendorinfo"
 *             value="${oja}.install.VendorInfoFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class VendorInfoFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new vendorinfo function shortcut.
     **/
    public VendorInfoFunctionShortcut()
    {
        super();
    }



    /**
     * Factory method for the actual vendor info task.
     * @param clnt
     * @see VendorInfotask
     **/
    private VendorInfoTask newHelper(Requester clnt)
    {
        VendorInfoTask impl = new VendorInfoTask("$vendorinfo:");
        impl.setProject(clnt.getProject());
        impl.setLocation(clnt.getLocation());
        impl.init();
        impl.setMustExist(false);
        return impl;
    }



    /**
     * Returns the vendorinfo field name described in query.
     */
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        VendorInfoTask impl = newHelper(clnt);
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i==0) {
            i++;
        } else if (i>0) {
            String vendor = uriFragment.substring(0,i);
            impl.setName(vendor);
            i++;
        }
        String output=null;
        Buildstrs info = impl.getBuildInfo();
        if (info!=EmptyBuildstrs.INSTANCE) {
            if (i>0 && i<uriFragment.length()) {
                output = impl.getFieldValue(info,uriFragment.substring(i));
            } else {
                output = info.getDisplayName();
            }
        }
        return output!=null ? output : getDefaultValue(fullUri, clnt);
    }
}


/* end-of-VendorInfoFunctionShortcut.java */
