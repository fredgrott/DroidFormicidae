/**
 * $Id: DefaultsFunctionShortcut.java 1491 2012-08-22 01:25:41Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.Defaults;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns default settings for various AntXtras fixture
 * elements. In particular the current execution cycle's {@linkplain Defaults}
 * are checked. This handler is not installed automatically by the AntXtras runtime,
 * you must install it explicitly like the example below. Default funcuts are often
 * linked to either the <span class="src">$default:</span> or the
 * <span class="src">$df:</span> scheme.
 * <p/>
 * If the named default is not one of the known builtin default attributes, this
 * handler will look for a project/fixture property named like:
 * <span class="src">defaults.<i>default-name</i></span> where <i>default-name</i>
 * is the fragment that comes after the <span class="src">$default:</span> prefix
 * in the funcut URI. The looked for property's name is <em>always</em> lowercased; 
 * for example, the URI <span class="src">$default:CopyLeft</span> will be matched 
 * against a project property <span class="src">defaults.copyleft</span>.
 * <p/>
 * To allow you to specify inlined default values for missing property-based defaults,
 * this handler understands the alternate "<span class="src">%{propertyname}</span>"
 * format in its URI fragment query portion (the bits after the "&#63;"); see example
 * below. Note that inlined default values are limited to property-based defaults; 
 * they are never used for builtin fixture defaults. When an inlined default value is
 * used, it is used as specified (no lowercasing is applied).
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;assign var="_loop.failquick" value="${<b>$default:</b>haltiferror}"/&gt;
 *    &lt;property name="finetrace" value="${<b>$default:</b>assertions}"/&gt;
 *    &lt;attribute name="license" default="${<b>$default:</b>license?LGPL}"/&gt;
 *    &lt;parameter name="license" value="${<b>$default:</b>license?%{project.license}}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="default"
 *             value="${ojaf}.info.DefaultsFunctionShortcut"/&gt;
 *       &lt;parameter name="df"
 *             value="${ojaf}.info.DefaultsFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2009-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @see       DefaultsPropertyNameFunctionShortcut
 **/

public class DefaultsFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new defaults function shortcut handler.
     **/
    public DefaultsFunctionShortcut()
    {
    }



    /**
     * Returns the embedded default value from the full uri if there.
     * Otherwise returns <i>null</i>.
     */
    public String getDefaultValue(String fullUri, Requester clnt)
    {
        if (fullUri!=null && fullUri.length()>4) {
            int i;
            if (fullUri.charAt(0)=='$' && (i=fullUri.indexOf(":"))>0) {
                String fallback = null;
                i= fullUri.lastIndexOf(SCHEME_DELIMITER);
                if (i>0) {
                    if ((i+SCHEME_DELIMITER_LEN)<fullUri.length()) {
                        fallback = fullUri.substring(i+SCHEME_DELIMITER_LEN);
                        fallback = Tk.resolveString(clnt.getProject(),fallback,true);
                    } else {
                        fallback = "";
                    }
                }
                return fallback;
            }
        }
        return null;
    }



    /**
     * Returns the associated default setting if possible. Will
     * return <i>null</i> if default name unrecognized.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        Defaults dflt = Iteration.defaultdefaults();
        String fragment;

        // Determine if an inlined default was specified. We should
        // not assume the us-locale string's length is same as the original
        // so we renormalize the fragment minus the default if needed.
        final Project project = clnt.getProject();
        String fallback = null;
        int i= uriFragment.lastIndexOf(SCHEME_DELIMITER);
        if (i>0) {
            if ((i+SCHEME_DELIMITER_LEN)<uriFragment.length()) {
                fallback = uriFragment.substring(i+SCHEME_DELIMITER_LEN);//NB:case used as passed-in!
                fallback = Tk.resolveString(project,fallback,true);
            } else {
                fallback = "";
            }
            fragment = Tk.lowercaseFrom(uriFragment.substring(0,i));
        } else {
            fragment = Tk.lowercaseFrom(uriFragment);
        }

        // Ask the Iteration (or subclass) first!
        String value = dflt.valueFrom(fragment,clnt);
        if (value!=null) {
            return value;
        }

        String property = dflt.defaultPropertiesPrefix(project)+fragment;
        value = Tk.getTheProperty(project,property);

        return (value==null) ? fallback : value;
    }
}

/* end-of-DefaultsFunctionShortcut.java */