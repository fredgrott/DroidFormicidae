/**
 * $Id: ChoiceType.java 430 2008-04-27 15:27:03Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.match;

import  org.jwaresoftware.antxtras.parameters.EnumSkeleton;

/**
 * Helper enum that represents the known AntX choice types.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

final class ChoiceType extends EnumSkeleton
{
    /** Index of {@linkplain #NONE NONE}. **/
    static final int NONE_INDEX = 0;
    /** Index of {@linkplain #SAME SAME}. **/
    static final int SAME_INDEX = NONE_INDEX+1;
    /** Index of {@linkplain #LIKE LIKE}. **/
    static final int LIKE_INDEX = SAME_INDEX+1;
    /** Index of {@linkplain #MEETS MEETS}. **/
    static final int MEETS_INDEX = LIKE_INDEX+1;


    /** Singleton "<span class="src">none</span>" choice. **/
    static final ChoiceType NONE=
        new ChoiceType("none",NONE_INDEX,false);

    /** Singleton "<span class="src">same</span>" choice. **/
    static final ChoiceType SAME=
        new ChoiceType("equals",SAME_INDEX,true);

    /** Singleton "<span class="src">like</span>" choice. **/
    static final ChoiceType LIKE=
        new ChoiceType("like",LIKE_INDEX,true);

    /** Singleton "<span class="src">meets</span>" choice. **/
    static final ChoiceType MEETS=
        new ChoiceType("meets",MEETS_INDEX,false);


    /**
     * Use to create public singletons. Ensures this enum is
     * initialized as if with the default Ant Introspector
     * helper thingy.
     **/
    private ChoiceType(String v, int i, boolean landr)
    {
        super(v);
        m_landr = landr;
    }


    /**
     * Returns copy of all possible source values as an ordered
     * string array. Note: ordering should be same as our
     * singleton indices.
     **/
    public String[] getValues()
    {
        return new String[] {"none", "equals", "like", "meets"};
    };



    /**
     * Returns whether this choice type needs both a known and
     * unknown value for evaluation.
     **/
    boolean needsLeftAndRight()
    {
        return m_landr;
    }


    /**
     * Helper that converts a string to a known ChoiceType
     * singleton. Returns <i>null</i> if string unrecognized.
     **/
    static ChoiceType from(Class c)
    {
        if (c!=null) {
            if (MatchEquals.class.isAssignableFrom(c)) {
                return SAME;
            }
            if (MatchLike.class.isAssignableFrom(c)) {
                return LIKE;
            }
            if (MatchCondition.class.isAssignableFrom(c)) {
                return MEETS;
            }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(Class) from(Class)} but with a
     * default value if supplied value does not match any known
     * ChoiceTask implementation.
     * @param s the symbolic name to be matched
     * @param dflt the default ChoiceType if necessary
     **/
    static ChoiceType from(Class c, ChoiceType dflt)
    {
        ChoiceType choice= from(c);
        return (choice==null) ? dflt : choice;
    }


    private final boolean m_landr;//default for most types
}

/* end-of-ChoiceType.java */