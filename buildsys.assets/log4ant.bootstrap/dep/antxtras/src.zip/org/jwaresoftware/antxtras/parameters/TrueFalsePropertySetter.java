/**
 * $Id: TrueFalsePropertySetter.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a condition component that can set both a true
 * property and a false property based on its result.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface TrueFalsePropertySetter
{
    /**
     * Tells component to set this property on a positive evaluation.
     **/
    void setTrueProperty(String property);

    /**
     * Returns the name of property to be set on a positive
     * evaluation. Can return <i>null</i> if never set.
     **/
    String getTrueProperty();


    /**
     * Tells component to set this property on a negative evaluation.
     **/
    void setFalseProperty(String property);


    /**
     * Returns the name of property to be set on a negative
     * evaluation. Can return <i>null</i> if never set.
     **/
    String getFalseProperty();
}

/* end-of-TrueFalsePropertySetter.java */
