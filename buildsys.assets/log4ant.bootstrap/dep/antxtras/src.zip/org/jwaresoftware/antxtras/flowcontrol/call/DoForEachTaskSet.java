/**
 * $Id: DoForEachTaskSet.java 1419 2012-07-31 16:13:43Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.ComponentHelper;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.TaskContainer;

import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.Empties;
import  org.jwaresoftware.antxtras.helpers.SIDs;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.parameters.ExecutionMode;

/**
 * Looping taskset that allows the per-loop execution steps to be nested
 * inside the taskset itself. This is the primary bounded looping construct
 * in the AntXtras package. The actual <i>implementation</i> of a looping
 * taskset depends on how Ant's macros work. For each iteration of the
 * loop, a (dynamically defined and installed) macrodef instance is performed.
 * The loop's cursor is represented as an overlaid property.
 * <p>
 * <b>Example Usage:</b><pre>
 * &lt;macrodef name="smokecheck-instance"&gt;
 *   &lt;attribute name="server.url"/&gt;
 *   &lt;sequential&gt;
 *      &lt;capturelogs importantfrom="info" splitentries="yes"&gt;
 *        &lt;emit msgid="msg.smokecheck.instance.start" msgarg1="@{server.url}"/&gt;
 *        &lt;<b>doforeach</b> i="testfile" files="smoketests.set"&gt;
 *           &lt;wsop-run file=${testfile}" haltiferror="no"/&gt;
 *        &lt;doforeach&gt;
 *        &lt;always&gt;
 *   &lt;/sequential&gt;
 * &lt;/macrodef&gt;
 *
 * &lt;macrodef name="smokecheck-cluster"&gt;
 *   &lt;attribute name="wl.env" default="proj-dev"/&gt;
 *   &lt;sequential&gt;
 *     &lt;assign var="server.url" value="http://@{wl.env}:9201/"/&gt;
 *     &lt;assert httpalive="${$var:server.url}${adm.urlfrag}" msg="Admin alive"/&gt;
 *     &lt;<b>doforeach</b> i="port" list="9203,9205,9207" tryeach="yes"
 *            failproperty="smokecheck.incomplete"/&gt;
 *        &lt;assign var="server.url" value="http://@{wl.env}:${port}"
 *        &lt;emit msgid="msg.smokecheck.start" msgarg1="${$var:server.url}"/&gt;
 *        &lt;assert httpalive="${$var:server.url}${app.urlfrag}"
 *               msg="Managed instance at ${$var:server.url} alive"/&gt;
 *        &lt;smokecheck-instance url="${$var:server.url}"/&gt;
 *     &lt;/doforeach&gt;
 *     &lt;do if="smokecheck.incomplete"&gt;
 *       &lt;emit msgid="err.smokecheck.failed"/&gt;
 *     &lt;/do&gt;
 *   &lt;/sequential&gt;
 * &lt;/macrodef&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008,2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/

public final class DoForEachTaskSet extends ForEachTaskSkeleton
    implements TaskContainer
{
    /**
     * Initializes new ForEachTaskSet instance.
     **/
    public DoForEachTaskSet()
    {
        super(AntX.flowcontrol+"DoForEachTaskSet:");
    }



    /**
     * Returns this task's inline macrodef's name. Never
     * returns <i>null</i> even if empty.
     **/
    public String getName()
    {
        return m_name;
    }



    /**
     * Returns this task's execution mode which is always
     * <span class="src">LOCAL</span>. Never returns <i>null</i>.
     **/
    public ExecutionMode getMode()
    {
        return ExecutionMode.LOCAL;
    }



    /**
     * Returns this task's implementation macrodef's name.
     * Never returns <i>null</i> even if empty.
     * @since JWare/AntX 0.5
     **/
    public String getMacroNamesList()
    {
        return getName()+"_macrodef";
    }



    /**
     * Returns this taskset's macrodef-name.
     **/
    public String toString()
    {
        return getMacroNamesList();
    }



    /**
     * Allow any task to be nested within this task. Note that there
     * is no special processing for properties or reference.
     * @param task task to be added (non-null)
     **/
    public void addTask(Task task)
    {
        m_nestedTasks.add(task);
    }



    /**
     * Returns this taskset's list of nested tasks.
     **/
    protected final List getTasksList()
    {
        return m_nestedTasks;
    }



    /**
     * Returns a new array of this taskset's nested tasks.
     * The array is new, the tasks are live references.
     **/
    public Task[] getTasks()
    {
        return (Task[])getTasksList().toArray(Empties.EMPTY_TASK_ARRAY);
    }




    /**
     * Returns an overlay keeper that redirects to this taskset's
     * container. Never returns <i>null</i>.
     * @since JWare/AntX 0.4
     **/
    protected OverlayParametersHelper getParametersKeeper()
    {
        if (m_paramsHelper==null) {
            m_paramsHelper= new OverlayParametersHelper(getProject());
            m_paramsHelper.addOverride(this);
        }
        return m_paramsHelper;
    }



    /**
     * Always returns one (1) because the target are the tasks
     * embodied by this taskset itself.
     **/
    protected final int getKindOfRunnablesSpecified()
    {
        return 1;
    }



    /**
     * Ensures this foreach task has been named.
     * @throws BuildException if this task has no step-name, loop-
     *         control, or is not in a valid target.
     * @throws BuildException if is local mode and cannot install a
     *         matching macrodef.
     **/
    protected void verifyCanExecute_(String calr)
        throws BuildException
    {
        super.verifyCanExecute_(calr);
        installMacrodef();
    }



    /**
     * Returns a list-of-one TargetCaller that calls back into this
     * foreach task via its '<i>run</i>' method.
     * @throws BuildException if unable to create target caller
     **/
    protected List copyOfOrderedTargetCallers()
        throws BuildException
    {
        TargetCaller caller;

        verify_(m_macrodefInstalled!=null,"getCalrs- macrodef inited");
        MacroInstanceCaller mcaller = new MacroInstanceCaller(this);
        mcaller.setTarget(m_macrodefInstalled);
        caller = mcaller;

        transferOverlayParameters(caller);

        List l = AntXFixture.newList(2);
        l.add(caller);

        return l;
    }



    /**
     * Executes foreach taskset. If local inlined, will also try to
     * remove the macrodef we installed.
     * @since JWare/AntX 0.5
     **/
    public void execute()
    {
        super.execute();

        String macroname = getMacroNamesList();
        ComponentHelper ch = ComponentHelper.getComponentHelper(getProject());
        Object was = ch.getAntTypeTable().remove(macroname);
        if (was!=null) {
            log("Removed macrodef("+macroname+") from type table",
                Project.MSG_DEBUG);
        } else {
            log("Unable to remove macrodef("+macroname+") from type table",
                Project.MSG_DEBUG);
        }
    }



    /**
     * Installs a macrodef comprised of our internals. This installation
     * is done once in task's lifetime (on verify). If a foreach is run
     * repeatedly as part of a macrodef itself, it installs a <em>single</em>
     * macrodef the first time it is run. Subsequent calls to the foreach's
     * parent macrodef reuses the previously installed foreach macrodef.
     **/
    private void installMacrodef()
    {
        if (m_macrodefInstalled==null) {
            String macroname = getMacroNamesList();

            ComponentHelper ch = ComponentHelper.getComponentHelper(getProject());
            if (ch.getDefinition(macroname)==null) {
                ForEachTasksMacroDef macrodefFactory = new ForEachTasksMacroDef();
                TaskExaminer.initTaskFrom(macrodefFactory,this);

                macrodefFactory.setName(macroname);

                Iterator itr = getTasksList().listIterator();
                while (itr.hasNext()) {
                    Task nestedTask = (Task)itr.next();
                    macrodefFactory.addTask(nestedTask);
                }

                log("Installing macrodef("+macrodefFactory.getName()+
                    ") as foreach implementation.",Project.MSG_DEBUG);

                macrodefFactory.perform();

            } else {
                log("Reusing existing macrodef("+macroname+
                    ") as foreach implementation.",Project.MSG_DEBUG);
            }
            m_macrodefInstalled = macroname;//NB: latch
        }
    }


    private String m_name=SIDs.next("foreach");//NB:required
    private List m_nestedTasks= AntXFixture.newList(10);
    private String m_macrodefInstalled;//NB:null=> macrodef might need installin'
}

/* end-of-DoForEachTaskSet.java */
