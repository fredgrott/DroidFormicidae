/**
 * $Id: IffValue.java 407 2008-04-19 16:52:08Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <em>true</em> and <em>false</em> test for all
 * conditional components. These tests should be set with the <em>resolved</em>
 * value strings.
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2004-2006,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 * @see      Go
 * @see      Iff
 * @see      Unless
 **/

public final class IffValue
{
    /**
     * Execute test for a simple "if-value-true" conditional parameter.
     * Null property names are not allowed.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsTrue extends Go.TestSkeleton {
        public IsTrue() {
        }
        public IsTrue(String string) {
            super(string);
        }
        public boolean pass(Project P) {
            verifyInited();
            String test = Tk.resolveString(P,getParameter());
            return Tk.string2PosBool(test)==Boolean.TRUE;
        }
        public String getParameterName() {
            return "ifValueTrue";
        }
    }


    /**
     * Execute test for a simple "if-value-not-true" conditional
     * parameter. Note that unlike the "IsFalse" test, this test will look explicitly
     * for a test that matches "true" exactly; anything that is not "true" is considered
     * not true (a positive result). Null property names are not allowed.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2006,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsNotTrue extends Go.TestSkeleton {
        public IsNotTrue() {
        }
        public IsNotTrue(String string) {
            super(string);
        }
        public boolean pass(Project P) {
            verifyInited();
            String test = Tk.resolveString(P,getParameter());
            return Tk.string2PosBool(test)==Boolean.TRUE ? false : true;
        }
        public String getParameterName() {
            return "ifValueNotTrue";
        }
    }


    /**
     * Execute test for a simple "if-value-false" conditional
     * parameter. This test looks for a exact "false" value match. Null property names
     * are not allowed.
     * @since    JWare/AntX 0.6
     * @author   ssmc, &copy;2006,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsFalse extends Go.TestSkeleton {
        public IsFalse() {
        }
        public IsFalse(String string) {
            super(string);
        }
        public boolean pass(Project P) {
            verifyInited();
            String test = Tk.resolveString(P,getParameter());
            return Tk.string2NegBool(test)==Boolean.FALSE;
        }
        public String getParameterName() {
            return "ifValueFalse";
        }
    }


    /** Don't allow **/
    private IffValue()
    {
    }
}

/* end-of-IffValue.java */
