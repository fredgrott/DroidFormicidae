/**
 * $Id: ResultsHelper.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.interpret;

import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Utility to assign the result values to the appropriate type of fixture element.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class ResultsHelper
{
    /**
     * Assign the result values to the appropriate type of fixture element. Note
     * that the incoming conclusion must be one of the fixed interpreter
     * constant values! If the result type is anything but write-once properties
     * this helper will <em>clear</em> pre-existing values if results are clean.
     * @param config call config (non-null)
     * @param errs number of final errors as a string (non-null)
     * @param warnings number of final warnings as a string (non-null)
     * @param result the <em>normalized</em> conclusion (non-null)
     **/
    public static void set(InterpretParameters config, String errs, String warnings, String result)
    {
        final Project P = config.getProject();
        if (config.updateProperties()) {
            boolean unclean = !LogInterpreter.CLEAN.equals(result);
            switch (config.getResultType().getIndex()) {
                case IsA.VARIABLE_INDEX: {
                    if (unclean) {
                        Variables.set(config.getErrorCountProperty(),errs,config);
                        Variables.set(config.getWarningCountProperty(),warnings,config);
                    } else {
                        Variables.unset(config.getErrorCountProperty(),config);
                        Variables.unset(config.getWarningCountProperty(),config);
                    }
                    Variables.set(config.getUpdateProperty(),result,config);
                    break;
                }
                case IsA.REFERENCE_INDEX: {
                    Map refstable = P.getReferences();
                    synchronized(refstable) {
                        if (unclean) {
                            refstable.put(config.getErrorCountProperty(),errs);
                            refstable.put(config.getWarningCountProperty(),warnings);
                        } else {
                            refstable.remove(config.getErrorCountProperty());
                            refstable.remove(config.getWarningCountProperty());
                        }
                        refstable.put(config.getUpdateProperty(),result);
                    }
                    break;
                }
                default: {
                    if (unclean) {
                        P.setNewProperty(config.getErrorCountProperty(),errs);
                        P.setNewProperty(config.getWarningCountProperty(),warnings);
                    }
                    P.setNewProperty(config.getUpdateProperty(),result);
                }
            }//switch
        }//do-updates
    }



    /**
     * Like
     * {@linkplain #set(InterpretParameters config, String errs, String warnings, String result)
     *  set(InterpretParameters,String,String,String)} but results are passed as scalar values.
     **/
    public static void set(InterpretParameters config, int nErrs, int nWarnings, String result)
    {
        set(config,String.valueOf(nErrs),String.valueOf(nWarnings),result);
    }


    private ResultsHelper()
    {
        /*disallow*/
    }
}

/* end-of-ResultsHelper.java */