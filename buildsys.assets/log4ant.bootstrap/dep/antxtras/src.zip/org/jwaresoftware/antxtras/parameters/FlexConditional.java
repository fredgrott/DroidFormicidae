/**
 * $Id: FlexConditional.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that supports an extended set of
 * if/unless conditions to determine whether it executes. A flex condition's
 * execution is determined by the combination of <em>all</em> of its
 * <i>if*</i> and <i>unless*</i> condiitons.
 * <p>
 * <b>Examples:</b><pre>
 *    &lt;do ifAll="ant.file,ant.version"&gt;&#8230;
 *    &lt;do unlessAnt="1\.5\.[3-9]?.*"&gt;&#8230;
 *    &lt;call ifOS="unix" &#8230;&gt;
 *    &lt;foreach ifAllTrue="analysis.enabled,findbugs.present"&gt;&#8230;
 * </pre>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface FlexConditional extends Conditional, PlatformConditional
{
    /**
     * Adds a positive boolean condition to this component.
     * The condition is <i>true</i> if the incoming string
     * represents a positive boolean string like <span class="src">yes</span>.
     * This method allows conditional tasks to leverage AntX value
     * URIs that generate a boolean string.
     * @param booleanString the string to evaluate
     * @since JWare/AntX 0.5
     */
    void setTrue(String booleanString);


    /**
     * Adds a negative boolean condition to this component.
     * The condition is <i>true</i> if the incoming string
     * represents a negative boolean string like <span class="src">no</span>.
     * This method allows conditional tasks to leverage AntX value
     * URIs that generate a boolean string.
     * @param booleanString the string to evaluate
     * @since JWare/AntX 0.5
     **/
    void setFalse(String booleanString);


    /**
     * Adds an if-true condition to this component. The
     * condition is only <i>true</i> if the named property
     * is defined as one of the positive Ant boolean
     * strings (like "<span class="src">yes</span>" or
     * "<span class="src">true</span>").
     * @see #setIfAllTrue setIfAllTrue
     **/
    void setIfTrue(String property);


    /**
     * Adds an unless-true condition to this component. The
     * condition is only <i>true</i> if the named property
     * does not exist or is not defined as one of the
     * positive Ant boolean strings (like
     * "<span class="src">yes</span>" or
     * "<span class="src">true</span>").
     * @see #setUnlessAllTrue setUnlessAllTrue
     **/
    void setUnlessTrue(String property);


    /**
     * Adds an if-all condition to this component. The
     * condition is only <i>true</i> if all of the named
     * properties exist.
     * @param properties comma-delimited list of property names
     **/
    void setIfAll(String properties);


    /**
     * Adds an unless-all condition to this component. The
     * condition is only <i>true</i> if none of the named
     * properties exist.
     * @param properties comma-delimited list of property names
     **/
    void setUnlessAll(String properties);


    /**
     * Adds an if-all-true condition to this component. The
     * condition is only <i>true</i> if all of the named
     * properties exist and are defined as valid positive Ant
     * boolean strings.
     * @param properties comma-delimited list of property names
     * @see #setIfTrue setIfTrue
     **/
    void setIfAllTrue(String properties);


    /**
     * Adds an unless-all-true condition to this component. The
     * condition is only <i>true</i> if none of the named
     * properties exist, or if none are defined to a positive
     * Ant boolean string.
     * @param properties comma-delimited list of property names
     * @see #setUnlessTrue setUnlessTrue
     **/
    void setUnlessAllTrue(String properties);


    /**
     * Returns <i>true</i> if all of this component's
     * current <i>if</i> conditions are <i>true</i>.
     **/
    boolean testIfCondition();


    /**
     * Returns <i>true</i> if all of this component's
     * current <i>unless</i> conditions are <i>true</i>.
     **/
    boolean testUnlessCondition();
}


/* end-of-FlexConditional.java */
