/**
 * $Id: ReferenceHandle.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  org.apache.tools.ant.ProjectComponent;
import  org.apache.tools.ant.types.Reference;

/**
 * Utility script element that lets you declare a reference as
 * a standalone nested element.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 **/

public final class ReferenceHandle extends ProjectComponent
{
    /**
     * Initializes a new reference handle.
     **/
    public ReferenceHandle()
    {
    }


    /**
     * Sets this handle's referred-to thing's reference.
     * @param ref the reference (non-null)
     **/
    public void setRefId(Reference ref)
    {
        m_refId = ref;
    }


    /**
     * Returns this handle's referred-to thingy's reference.
     * Will return <i>null</i> if never set.
     **/
    public Reference getRefId()
    {
        return m_refId;
    }


    /**
     * Tells this handle's user whether a missing reference
     * is OK.
     * @param halt <i>true</i> if missing refid is bad.
     **/
    public void setHaltIfMissing(boolean halt)
    {
        m_haltIfMissing = halt ? Boolean.TRUE : Boolean.FALSE;
    }


    /**
     * Returns this handle's bad refid missing instruction.
     * Will return <i>null</i> if never set explicitly.
     **/
    public Boolean getHaltIfMissingFlag()
    {
        return m_haltIfMissing;
    }


    private Reference m_refId;
    private Boolean m_haltIfMissing;
}

/* end-of-ReferenceHandle.java */