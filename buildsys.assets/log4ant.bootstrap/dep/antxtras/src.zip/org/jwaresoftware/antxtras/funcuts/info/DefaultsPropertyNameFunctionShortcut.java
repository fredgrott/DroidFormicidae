/**
 * $Id: DefaultsPropertyNameFunctionShortcut.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns name of the project property that caller
 * must set to control named default. To obtain the result, the current execution
 * cycle's {@linkplain org.jwaresoftware.antxtras.core.Defaults} object is 
 * queried. If the Defaults object does not recognize the default, <i>null</i>
 * is returned. The general format of the URI: 
 * <span class="src">$defaultsproperty:default-name</span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;property name="${$defaultsproperty:shortlocations}" value="yes"/&gt;
 *    &lt;do if="${$defaultsproperty:passwordfile}"&gt;...
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="defaultsproperty"
 *             value="${ojaf}.info.DefaultsPropertyNameFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @see       DefaultsFunctionShortcut
 **/

public final class DefaultsPropertyNameFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new defaults property name function shortcut.
     **/
    public DefaultsPropertyNameFunctionShortcut()
    {
    }


    /**
     * Returns the associated default setting if possible. Will
     * return <i>null</i> if default name unrecognized.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        if (uriFragment.length()>0) {
            String fragment = Tk.lowercaseFrom(uriFragment);
            return Iteration.defaultdefaults().propertyFrom(fragment,clnt);
        }
        return null;
    }
}

/* end-of-DefaultsPropertyNameFunctionShortcut.java */