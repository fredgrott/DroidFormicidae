/**
 * $Id: TaskHandle.java 390 2008-03-30 17:51:32Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  org.apache.tools.ant.Task;

/**
 * ResultObject wrapper for a Task reference.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @.pattern Fowler.ResultObject
 **/

public final class TaskHandle
{
    /**
     * Initializes an empty task handle.
     **/
    public TaskHandle()
    {
    }


    /**
     * Initializes a pre-filled task handle.
     **/
    public TaskHandle(Task t)
    {
        m_task = t;
    }


    /**
     * Returns this handle's underlying task. Can
     * return <i>null</i> if handle empty.
     **/
    public Task getTask()
    {
        return m_task;
    }



    /**
     * Updates this handle's underlying task.
     * @param t new task (can be <i>null</i>)
     **/
    public void setTask(Task t)
    {
        m_task = t;
    }


    /**
     * Clears this handle's underlying task.
     **/
    public void clrTask()
    {
        m_task = null;
    }


    /**
     * Returns <i>true</i> if this handle has no
     * underlying task.
     **/
    public boolean isEmpty()
    {
        return m_task==null;
    }


    /**
     * Returns this handle's underlying task's name
     * or empty string if no task.
     **/
    public String getTaskName()
    {
        return m_task==null ? "" : m_task.getTaskName();
    }



    private Task m_task;
}

/* end-of-TaskHandle.java */
