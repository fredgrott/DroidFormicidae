/**
 * $Id: IsNotWhitespace.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.Handling;
import  org.jwaresoftware.antxtras.parameters.MalformedCheckEnabled;

/**
 * Simple Is-Not-Whitespace condition check.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;isnotwhitespace value="${module.title}"/&gt;
 *   &lt;isnotwhitespace property="_loop.module.title"/&gt;
 *   &lt;isnotwhitespace value="${project.id}" malformed="reject"/&gt;
 *</pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 **/

public class IsNotWhitespace extends SimpleFlexCondition
    implements MalformedCheckEnabled
{
    /**
     * Initializes new IsNotWhitespace condition.
     **/
    public IsNotWhitespace()
    {
    }


    /**
     * Creates defined IsNotWhitespace condition.
     * @param value the value against which condition checks
     **/
    public IsNotWhitespace(String value)
    {
        setValue(value);
    }



    /**
     * Sets condition string used by evaluation method.
     * @param value the value (non-null)
     **/
    public void setValue(String value)
    {
        require_(value!=null,"setValu- nonzro");
        setLiteral(value);
    }



    /**
     * Tells this condition to check for failed property
     * substitution. When property substitution fails, the default
     * Ant behavior is to leave the property reference as the
     * value. This option allows the condition user to specify
     * how to interpret this situation.
     * @param response how to handle unresolved references
     * @since JWare/AntX 0.4
     **/
    public void setMalformed(Handling response)
    {
        m_testFailedSubst = !Handling.isYes(response,Handling.REJECT);
    }


    /**
     * Returns how this condition will handle unresolved
     * properties. Returnes either "accept" or "reject".
     * @since JWare/AntX 0.4
     **/
    public Handling getMalformedHandling()
    {
        return m_testFailedSubst ? Handling.REJECT : Handling.ACCEPT;
    }


    /**
     * Returns <i>true</i> if the condition value is not
     * all whitespace.
     **/
    public boolean eval()
    {
        verifyCanEvaluate_("eval");

        FlexString xv = getValueHelper();
        String value  = xv.getValue();
        boolean notWS = !Tk.isWhitespace(value);

        if (notWS && m_testFailedSubst) {
            if (xv.isProperty()) {
                if (!LocalPropertyExaminer.verifyProperty
                    (getProject(), xv)) {
                    notWS=false;
                }
            } else {
                if (!LocalPropertyExaminer.verifyLiteral
                    (getProject(), xv)) {
                    notWS=false;
                }
            }
        }
        return notWS;
    }


    private boolean m_testFailedSubst= true;//NB:reject unresolved
}

/* end-of-IsNotWhitespace.java */
