/**
 * $Id: Strings.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

/**
 * Collection of common string constants.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2008-2009,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/

public final class Strings
{
    /**
     * System-specific line separator.
     **/
    public static final String NL= System.getProperty("line.separator","\n");

    /**
     * Length of the system-specific {@linkplain #NL line separator}.
     **/
    public static final int NL_LEN= NL.length();


    /**
     * The string "<i>true</i>".
     **/
    public static final String TRUE= String.valueOf(true);

    /**
     * The string "<i>false</i>".
     **/
    public static final String FALSE= String.valueOf(false);

    /**
     * The string "<i>null</i>".
     **/
    public static final String NULL= "null";

    /**
     * The string "<i>default</i>".
     **/
    public static final String DEFAULT= "default";

    /**
     * The string "<i>defaults</i>".
     * @since JWare/AntX 0.5
     **/
    public static final String DEFAULTS= "defaults";

    /**
     * The string "<i>inherit</i>".
     **/
    public static final String INHERIT= "inherit";

    /**
     * The string "<i>enclosing</i>".
     * @since JWare/AntX 0.3
     **/
    public static final String ENCLOSING= "enclosing";

    /**
     * The string "<i>all</i>".
     **/
    public static final String ALL= "all";

    /**
     * The string "<i>user</i>".
     **/
    public static final String USER= "user";

    /**
     * The string "<i>none</i>".
     **/
    public static final String NONE= "none";

    /**
     * The string "<i>current</i>".
     * @since JWare/AntX 0.4
     **/
    public static final String CURRENT= "current";

    /**
     * The string "<i>context</i>".
     * @since JWare/AntX 0.4
     **/
    public static final String CONTEXT= "context";

    /**
     * The string "<i>install</i>".
     **/
    public static final String INSTALL= "install";

    /**
     * The string "<i>uninstall</i>".
     **/
    public static final String UNINSTALL= "uninstall";

    /**
     * The string "<i>undefined</i>".
     * @since JWare/AntX 0.5
     **/
    public static final String UNDEFINED= "undefined";

    /**
     * The string "<i>now</i>".
     * @since JWare/AntX 0.5
     **/
    public static final String NOW= "now";

    /**
     * The string "<i>fallback</i>".
     * @since JWare/AntXtras 2.0.0
     **/
    public static final String FALLBACK= "fallback";

    /**
     * The string "<i>n/d</i>".
     * @since JWare/AntXtras 3.5.0
     **/
    public static final String ND= "n/d";


    /** Prevent this. **/
    private Strings()
    {
    }
}

/* end-of-Strings.java */
