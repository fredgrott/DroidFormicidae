/**
 * $Id: Locals.java 1370 2012-07-26 12:21:35Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture.wrap;

import  java.util.Collections;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Location;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableTask;

/**
 * Collection of fixture elements that should be either preserved by or limited to
 * an isolated task set. Variables are inherited from the enclosing context by
 * default; you must explicitly unset pre-existing variables by setting the
 * <span class="src">inherit</span> parameter <i>false</i>. Properties are <em>not</em>
 * inherited by default; you must explicitly copy pre-existing properties by
 * setting the <span class="src">inherit</span> parameter <i>true</i>. When default
 * values are assigned to local properties, these properties act as overlayed values
 * that replace unconditionally any pre-existing settings.
 * <p/>
 * Locals are applied en-masse at once. This means a local definition cannot depend
 * on another local definition because it is not guaranteed that the source item will
 * be initialized first even if it appears first in the script. Of course locals can
 * depend on pre-existing fixture values including macro attribute values.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;macrodef name="fubar"&gt;
 *       &lt;attribute name="all" default="no"/&gt;
 *       &lt;sequential&gt;
 *          &lt;<b>locals name="fubar.locals"</b>&gt;
 *             &lt;property name="generate"/&gt;
 *             &lt;property name="allowtests" value="@{all}"/&gt;
 *          &lt;/locals&gt;
 *          ...
 *          &lt;isolate block="fubar.locals"&gt;
 *              &lt;do if="allowtests"&gt;
 *                 ...
 *              &lt;condition property="generate"&gt;
 *                 ...
 *          &lt;/isolate&gt;
 *       &lt;/sequential&gt;
 *    &lt;/macrodef&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 * @see       IsolatedTaskSet
 * @.impl     Because this whole notion of macro locals (and scoping in general)
 *            is destined to appear in Ant at some point, most of this class's API
 *            is kept package-private to ease transition to whatever becomes the
 *            standard Ant mechanism.
 **/

public final class Locals extends AssertableTask implements Nameable
{
    /**
     * Returns an altered and slight-less-likely-to-collide name variant.
     * @param name application supplied name (non-null)
     * @return the locals wrapped name (non-null)
     * @since JWare/AntXtras 3.5.0
     **/
    public static final String wrapped(String name)
    {
        return ".Locals("+name+")";
    }



    /**
     * Initialize a new locals bucket. This item's name is
     * defaulted to <span class="src">_macrolocals_</span>.
     **/
    public Locals()
    {
        super(AntX.fixture+"Locals:");
    }



    /**
     * Marks this locals declaration as a blocking definition
     * or not. If blocking this locals items should be removed
     * from the enclosing project's context when the bubble
     * exits.
     * @param denied <i>true</i> if our items should be removed.
     **/
    final void setBlocking(boolean denied)
    {
        m_isDenied = denied;
    }



    /**
     * Returns <i>true</i> if this local's items should be removed
     * from the enclosing bubble's context before it exits.
     **/
    boolean isBlocking()
    {
        return m_isDenied;
    }



    /**
     * Sets this locals name so it can be referenced by a
     * bubble or net component.
     * @param name this locals handle (non-null)
     * @.sideeffect Will install this locals into the project's
     *   reference table using a wrapped version of this name.
     * @see #wrapped(String) wrapped(...)
     * @since JWare/AntXtras 3.5.0 will save wrapped name
     */
    public void setName(String name)
    {
        require_(name!=null,"setName- nonzro name");
        m_name = name;
        m_refid = wrapped(name);
    }



    /**
     * Capture the standard way of setting an item's refid in Ant.
     * Delegates to {@linkplain #setName(String) setName(...)}.
     * @param refid this locals handle (non-null)
     * @since JWare/AntXtras 3.5.0 will save wrapped name
     */
    public final void setId(String refid)
    {
        setName(refid);
    }



    /**
     * Returns this locals item's name as defined. Will never return
     * <i>null</i>; defaults to <span class="src">_macrolocals_</span>.
     */
    public final String getName()
    {
        return m_name;
    }


    /**
     * Returns this locals item's installed-under refid. Will never return
     * <i>null</i>; defaults to <span class="src">.Locals(_macrolocals)</span>.
     * @since JWare/AntXtras 3.5.0
     */
    public final String getRefIdValue()
    {
        return m_refid;
    }



    /**
     * Sets default inherit option for all of this local's
     * contained items. Individual items can override this
     * setting.
     * @param inherit <i>true</i> to inherit
     **/
    public void setInherit(boolean inherit)
    {
        m_inherit = inherit ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this local's inherit flag setting. Will return
     * <i>null</i> if never set explicitly.
     **/
    public final Boolean getInheritFlag()
    {
        return m_inherit;
    }



    /**
     * Returns a local item's inherit flag setting. Will return
     * <i>null</i> if neither the item nor this bucket has
     * an explicit setting.
     **/
    public final Boolean getInheritFlag(ConditionalLocal local)
    {
        Boolean f = local.getInheritFlag();
        if (f==null) {
            f = getInheritFlag();
        }
        return f;
    }



    /**
     * Adds a new property item to this locals bucket.
     * @return the new item
     **/
    public Object createProperty()
    {
        if (m_propertyItems==null) {
            m_propertyItems = AntXFixture.newList();
        }
        return newItem(m_propertyItems);
    }



    /**
     * Adds a new variable item to this locals bucket.
     * @return the new item
     **/
    public Object createVariable()
    {
        if (m_variableItems==null) {
            m_variableItems = AntXFixture.newList();
        }
        return newItem(m_variableItems);
    }



    /**
     * Common synonym for {@linkplain #createVariable}.
     * @return the new item
     **/
    public final Object createVar()
    {
        return createVariable();
    }



    /**
     * Ensures all local items have been named (at least). Values
     * are not required for local declarations.
     * @param calr execution method (non-null)
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);
        try {
            verifyNamed(m_propertyItems);
            verifyNamed(m_variableItems);
        } catch(BuildException bX) {
            log(bX.getMessage(),Project.MSG_ERR);
            if (bX.getLocation()==Location.UNKNOWN_LOCATION) {
                bX = new BuildException(bX,getLocation());
            }
            throw bX;
        }
    }


    /**
     * Ensures this locals item and all of its nested items are
     * named. Once verified, execute will install this locals into its
     * project's reference table using its wrapped name as the key.
     * @throws BuildException if another locals object already exists
     *     with same handle.
     * @throws BuildException if this object or any of its nested
     *     items are improperly named (or unnamed).
     * @see #wrapped(String) wrapped(...)
     */
    public void execute()
    {
        verifyCanExecute_("exec");

        Map ht = getProject().getReferences();
        synchronized(ht) {
            if (ht.containsKey(getRefIdValue())) {
                String error = getAntXMsg("flow.locals.exists",getName());
                log(error,Project.MSG_ERR);
                throw new BuildException(error,getLocation());
            }
            ht.put(getRefIdValue(),this);
        }
    }



    /**
     * Removes this locals item from its project's reference table. This
     * method should be called immediately after a locals reference
     * is assigned to a bubble or net. This method does
     * <em>nothing</em> if this locals object is not installed.
     * @param clnt feedback controls.
     * @return <i>true</i> if removed from projects reference table.
     **/
    public final boolean uninstall(Requester clnt)
    {
        boolean ok=true;
        Map ht = getProject().getReferences();
        synchronized(ht) {
            Object o = ht.get(getRefIdValue());
            if (o==this) {
                ht.remove(getRefIdValue());
            } else {
                String warning = getAntXMsg("flow.locals.not.installed",getName());
                clnt.problem(warning,Project.MSG_WARN);
                ok = false;
            }
        }
        return ok;
    }



    List getProperties()
    {
        return m_propertyItems;
    }


    List getVariableNames()
    {
        return getItemNames(m_variableItems);
    }


    List getVariables()
    {
        return m_variableItems;
    }


    boolean hasVariables()
    {
        return m_variableItems!=null;
    }


    private ConditionalLocal newItem(List list)
    {
        ConditionalLocal item = new ConditionalLocal(getProject());
        list.add(item);
        return item;
    }


    private List getItemNames(List from)
    {
        List l = Collections.EMPTY_LIST;
        if (from!=null) {
            synchronized(from) {
                l = AntXFixture.newList(from.size());
                for (int i=0,N=from.size();i<N;i++) {
                    ConditionalLocal local = (ConditionalLocal)from.get(i);
                    if (local.isEnabled()) {
                        l.add(local.getName());
                    }
                }
            }
        }
        return l;
    }


    private void verifyNamed(List from)
    {
        if (from!=null) {
            synchronized(from) {
                Iterator itr= from.iterator();
                while (itr.hasNext()) {
                    ConditionalLocal local = (ConditionalLocal)itr.next();
                    local.verifyNamed();
                }
            }
        }
    }

    private static final String DEFAULT_NAME = "_macrolocals_";
    private String m_name = DEFAULT_NAME;
    private String m_refid = wrapped(DEFAULT_NAME);
    private boolean m_isDenied;
    private List m_propertyItems,m_variableItems;
    private Boolean m_inherit;
}

/* end-of-Locals.java */