/**
 * $Id: MatchesTask.java 1488 2012-08-21 11:40:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.condition.IsMatch;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.parameters.IgnoreCaseEnabled;
import  org.jwaresoftware.antxtras.parameters.TrimEnabled;
import  org.jwaresoftware.antxtras.parameters.TrueFalsePropertySetter;
import  org.jwaresoftware.antxtras.parameters.TrueFalseVariableSetter;

/**
 * Task version of a {@linkplain IsMatch} condition that lets you set
 * another property based on the evaluation result. Usually defined
 * &lt;matches&gt;.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;<b>oja:matches</b> trueproperty="loop.DIE"
 *      pattern="(true)|(yes)|(okidoki)|(on)" variable="_loop.haltiferror"
 *      ignorecase="true"/&gt;
 * -OR-
 *  &lt;target name="--verify.buildenv"/&gt;
 *    &lt;<b>oja:matches</b> falseproperty="build.type.broken"
 *        pattern="^(internal|distribution|local)$" value="${build.type}"/&gt;
 *    &lt;oja:stop messageid="err.unknown.buildtype" arg0="${build.type}"
 *        if="build.type.broken"/&gt;
 *  &lt;/target&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 * @see      IsMatch
 **/

public final class MatchesTask extends AssertableTask
    implements FlexValueSupport, IgnoreCaseEnabled, TrimEnabled,
               TrueFalsePropertySetter, TrueFalseVariableSetter,
               Condition
{
    /**
     * Initializes a new MatchesTask instance.
     **/
    public MatchesTask()
    {
        super(AntX.conditions+"MatchesTask:");
    }


    /**
     * Initializes the enclosing project of this task.
     * Also updates this task's helper bits.
     **/
    public void setProject(Project P)
    {
        super.setProject(P);
        m_impl.setProject(P);
    }


// ---------------------------------------------------------------------------------------
// Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets this task's regular expression pattern.
     * @param pattern pattern against which value matched (non-null)
     **/
    public void setPattern(String pattern)
    {
        m_impl.setPattern(pattern);
    }


    /**
     * Sets this task's to-be-matched literal value.
     * @param value value to be matched (non-null)
     **/
    public void setValue(String value)
    {
        m_impl.setValue(value);
    }


    /**
     * Sets a property whose value is to be evaluated by this
     * task. Property read when this task is executed.
     * @param property the property's name (non-null)
     **/
    public void setProperty(String property)
    {
        m_impl.setProperty(property);
    }


    /**
     * Sets an exported property whose value is to be evaluated
     * by this task. Variable read when this task is executed.
     * @param variable the exported property's name (non-null)
     **/
    public void setVariable(String variable)
    {
        m_impl.setVariable(variable);
    }


    /**
     * Synonym for {@linkplain #setVariable setVariable}.
     **/
    public void setVar(String variable)
    {
        setVariable(variable);
    }


    /**
     * Sets a reference whose value is to be evaluated by this
     * task. Reference read wen this task is executed.
     * @param refid the reference's name (non-null)
     **/
    public void setReference(String refid)
    {
        m_impl.setReference(refid);
    }


    /**
     * Set whether the value should be trimmed of whitespace
     * before it's compared.
     **/
    public void setTrim(boolean trim)
    {
        m_impl.setTrim(trim);
    }


    /**
     * Returns <i>true</i> if the value will be trimmed before
     * it's compared.
     **/
    public final boolean willTrim()
    {
        return m_impl.willTrim();
    }



    /**
     * Set whether the value should be lower-cased before
     * it's compared.
     **/
    public void setIgnoreCase(boolean ignore)
    {
        m_impl.setIgnoreCase(ignore);
    }


    /**
     * Returns <i>true</i> if the value will be lower-cased
     * before it's compared.
     **/
    public final boolean isIgnoreCase()
    {
        return m_impl.isIgnoreCase();
    }


    /**
     * Sets the property to be created on a negative evaluation.
     * Property will be set to the string "<i>true</i>."
     * @param property the property to create (non-null)
     **/
    public void setFalseProperty(String property)
    {
        require_(property!=null,"setFalsP- nonzro nam");
        m_falseProperty = property;
    }


    /**
     * Returns the property to be created/set on a negative
     * evaluation. Returns <i>null</i> if never set.
     **/
    public final String getFalseProperty()
    {
        return m_falseProperty;
    }


    /**
     * Sets the variable to be created on a negative evaluation.
     * Variable will be set to the string "<i>true</i>."
     * @param varname the variable to create (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setFalseVariable(String varname)
    {
        require_(varname!=null,"setFalsV- nonzro nam");
        m_falseVariable = varname;
    }


    /**
     * Returns the variable to be created/set on a negative
     * evaluation. Returns <i>null</i> if never set.
     * @since JWare/AntXtras 2.0.0
     **/
    public final String getFalseVariable()
    {
        return m_falseVariable;
    }


    /**
     * Sets the property to be created on a positive evaluation.
     * Property will be set to the string "<i>true</i>."
     * @param property the property to create (non-null)
     **/
    public void setTrueProperty(String property)
    {
        require_(property!=null,"setTrueP- nonzro nam");
        m_trueProperty = property;
    }


    /**
     * Returns the property to be created/set on a positive
     * evaluation. Returns <i>null</i> if never set.
     **/
    public final String getTrueProperty()
    {
        return m_trueProperty;
    }


    /**
     * Sets the variable to be created on a positive evaluation.
     * Variable will be set to the string "<i>true</i>."
     * @param varname the variable to create (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setTrueVariable(String varname)
    {
        require_(varname!=null,"setTrueV- nonzro nam");
        m_trueVariable = varname;
    }


    /**
     * Returns the variable to be created/set on a positive
     * evaluation. Returns <i>null</i> if never set.
     * @since JWare/AntXtras 2.0.0
     **/
    public final String getTrueVariable()
    {
        return m_trueVariable;
    }


    /**
     * Returns <i>true</i> if the value matches this task's pattern.
     * @throws BuildException if condition definition is incomplete
     * @since JWare/AntX 0.3
     **/
    public boolean eval() throws BuildException
    {
        verifyCanExecute_("eval");

        boolean istrue= m_impl.eval();

        if (istrue) {
            if (getTrueProperty()!=null) {
                String prop = getTrueProperty();
                log("Match was true; setting true-property '"+prop+"' property",
                    Project.MSG_DEBUG);
                getProject().setNewProperty(prop,Strings.TRUE);
            }
            if (getTrueVariable()!=null) { //@since AntX 2.0.0
                String varname = getTrueVariable();
                log("Match was true; setting true-variable '"+varname+"' var",
                    Project.MSG_DEBUG);
                Variables.set(varname,Strings.TRUE);
            }
        }
        else {
            if (getFalseProperty()!=null) {
                String prop = getFalseProperty();
                log("Match was false; setting false-property '"+prop+"' property",
                    Project.MSG_DEBUG);
                getProject().setNewProperty(prop,Strings.TRUE);
            }
            if (getFalseVariable()!=null) { //@since AntX 2.0.0
                String varname = getFalseVariable();
                log("Match was false; setting false-variable '"+varname+"' var",
                    Project.MSG_DEBUG);
                Variables.set(varname,Strings.TRUE);
            }
        }

        return istrue;
    }


    /**
     * Checks if the value-under-test matches this task's pattern
     * and updates properties based on results.
     * @throws BuildException if condition definition is incomplete
     **/
    public void execute() throws BuildException
    {
        eval();
    }

    private final IsMatch m_impl= new IsMatch();
    private String m_falseProperty, m_trueProperty;
    private String m_falseVariable, m_trueVariable;
}

/* end-of-MatchesTask.java */
