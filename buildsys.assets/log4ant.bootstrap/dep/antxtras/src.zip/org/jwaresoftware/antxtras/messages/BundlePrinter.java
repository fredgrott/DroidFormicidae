/**
 * $Id: BundlePrinter.java 421 2008-04-26 23:40:44Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.io.IOException;
import  java.io.OutputStream;
import  java.util.Properties;

import  org.jwaresoftware.antxtras.print.DisplayRequest;
import  org.jwaresoftware.antxtras.print.DisplayStrategy;

/**
 * Default strategy for printing a {@linkplain MessagesBundle MessagesBundle} to an
 * output stream. Basically dumps the resource bundle's underlying properties object
 * to the stream.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 * @see      PrintBundleTask
 **/

public final class BundlePrinter implements DisplayStrategy
{
    /**
     * Initializes a new BundlePrinter.
     **/
    public BundlePrinter()
    {
    }


    /**
     * Copies the referenced bundle's underlying Properties information
     * to given output stream.
     * @param info display information (non-null)
     * @param os the output stream (non-null)
     * @throws IOException if any I/O error occurs
     **/
    public void print(final DisplayRequest info, OutputStream os)
        throws IOException
    {
        Object thing = info.getObjectToBeDisplayed();

        if (thing instanceof MessagesBundle) {
            Properties msgs = ((MessagesBundle)thing).newProperties(null);
            msgs.store(os,info.getName());
            msgs.clear();
            msgs = null;
        }
    }
}

/* end-of-BundlePrinter.java */
