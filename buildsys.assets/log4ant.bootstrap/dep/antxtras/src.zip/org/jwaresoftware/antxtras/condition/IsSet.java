/**
 * $Id: IsSet.java 1174 2010-11-07 23:38:31Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.jwaresoftware.antxtras.parameters.Handling;
import  org.jwaresoftware.antxtras.parameters.IgnoreWhitespaceEnabled;
import  org.jwaresoftware.antxtras.parameters.IsA;
import  org.jwaresoftware.antxtras.parameters.MalformedCheckEnabled;

/**
 * Simple Is-Set condition check that supports references and AntXtras
 * variables. Standalone condition named &lt;isdeclared&gt; to avoid
 * conflict with the standard Ant isset condition.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;isdeclared property="jdk14.present"/&gt;
 *   &lt;isdeclared property="module.id" whitespace="reject"/&gt;
 *   &lt;isdeclared variable="__loopcount"/&gt;
 *   &lt;isdeclared reference="build.num"/&gt;
 *   &lt;isdeclared property="build.ROOT" whitespace="reject" malformed="reject"/&gt;
 *</pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2003-2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 **/

public class IsSet extends SimpleFlexCondition
    implements IgnoreWhitespaceEnabled, MalformedCheckEnabled
{
    /**
     * Initializes new IsSet condition. A value type must be
     * specified before this condition is evaluated.
     **/
    public IsSet()
    {
        super();
    }


    /**
     * Initializes a fully-defined IsSet condition.
     * @param property the property against which condition checks
     **/
    public IsSet(String property)
    {
        setProperty(property);
    }


    /**
     * Initializes an IsSet condition to either a property or
     * a variable value check.
     * @param value property or variable against which condition checks
     * @param isP <i>true</i> if <span class="src">value</span> is
     *             property's name
     **/
    public IsSet(String value, boolean isP)
    {
        if (isP) {
            setProperty(value);
        } else {
            setVariable(value);
        }
    }



    /**
     * Tells this condition whether a property containing only
     * whitespace is considered "not set". If the choice is
     * one of "ignore", "reject", or "balk" then an all-whitespace
     * property are considered not set.
     **/
    public void setWhitespace(Handling response)
    {
        getValueHelper().setWhitespace(response);
    }


    /**
     * Returns <i>true</i> if values of all whitespace will be
     * ignored (as if not set). Defaults <i>false</i>.
     **/
    public final boolean ignoreWhitespace()
    {
        return getValueHelper().isIgnoreWhitespace();
    }


    /**
     * Tells this condition whether properties must be completely
     * resolved to be considered "set". If the choice is
     * either "ignore" or "accept" then unresolved property
     * values are considered okidoki (set).
     * @since JWare/AntX 0.4
     **/
    public void setMalformed(Handling response)
    {
        // malformed="accept|ignore"
        if (Handling.isYes(response,Handling.REJECT)) {
            m_checkUnresolved= false;
        }
        // malformed="reject|balk|inherit"
        else {
            m_checkUnresolved= true;
        }
    }


    /**
     * Returns how this condition will handle unresolved
     * properties. Returnes either "accept" or "reject".
     * @since JWare/AntX 0.4
     **/
    public Handling getMalformedHandling()
    {
        return m_checkUnresolved ? Handling.REJECT : Handling.ACCEPT;
    }



    /**
     * Marks this condition's property as the default field
     * set by a value URI.
     * @since JWare/AntX 0.5
     * @return IsA.PROPERTY always.
     */
    protected IsA getDefaultIsAForURI()
    {
        return IsA.PROPERTY;
    }



    /**
     * Returns <i>true</i> if this condition's property, reference,
     * or variable is explicitly set.
     **/
    public boolean eval()
    {
        verifyCanEvaluate_("eval");

        if (isProperty()) {
            if (m_checkUnresolved) {
                if (!LocalPropertyExaminer.verifyProperty
                    (getProject(), getValueHelper())) {
                    return false;
                }
            }
        }
        else if (isReference()) {
            Object o = getProject().getReference(getResolvedFlexValue());
            if (!(o instanceof String)) {//otherwise apply modifiers(ssmc)
                return o!=null;
            }
        }

        return getValueHelper().getValue()!=null;
    }


    private boolean m_checkUnresolved;//NB:=> even unresolved=="set"
}

/* end-of-IsSet.java */
