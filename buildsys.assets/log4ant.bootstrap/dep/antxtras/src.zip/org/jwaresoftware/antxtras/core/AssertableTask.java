/**
 * $Id: AssertableTask.java 1491 2012-08-22 01:25:41Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;

import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.behaviors.ScriptLocatable;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.internal.apis.UIStringManager;

/**
 * Extension of basic Ant <i>Task</i> that adds builtin assertions and
 * support for resource-bundle based messages.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2007-2009,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  guarded
 * @.group   impl,infra
 * @see      AssertableProjectComponent
 **/

public abstract class AssertableTask extends Task
    implements ProjectDependent, ScriptLocatable
{
    /**
     * Initializes new CV-labeled task.
     * @param iam CV-label (non-null)com.idare
     **/
    protected AssertableTask(String iam)
    {
        super();
        Iam_= Tk.cvlabelFrom(iam);
    }



    /**
     * Ensures this task's {@linkplain #initonce} method is called just
     * once. Sometimes Ant introspection mechanisms trigger mulitple calls
     * to init. This ensure that once-only initialization code is really
     * only called once.
     * @since JWare/AntX 0.5
     **/
    public void init()
    {
        super.init();

        if (!m_initedOnce) {
            initonce();
            m_initedOnce=true;
        }
    }



    /**
     * Initialization that must be done at most one time. Called by
     * {@linkplain #init} once even if init is itself called multiple
     * times. By default does nothing.
     * @throws BuildException if unable to initialize required bits
     * @since JWare/AntX 0.5
     **/
    protected void initonce()
    {
    }



    /**
     * Workaround NPE triggered problem in super.maybeConfigure since
     * Ant 1&#46;7.
     * @since JWare/AntX 0.5.1
     */
    public void maybeConfigure()
    {
        if (!m_configuredOnce) {
            super.maybeConfigure();
            this.m_configuredOnce = true;
        }
    }



    /**
     * Shortcut that returns this task's internal component UI
     * strings manager. Never returns <i>null</i>. By default returns
     * the current iteration's UI strings manager.
     * @see Iteration#uistrs
     **/
    public final UIStringManager uistrs()
    {
        return Iteration.uistrs();
    }


// ---------------------------------------------------------------------------------------
// (AntXtras) Universal Task Log Conversion (make events useful):
// ---------------------------------------------------------------------------------------

    /**
     * Indicate this task as source of logged message.
     **/
    public void log(String msg, int msgLevel)
    {
        if (getProject()!=null) {
            getProject().log(this,msg,msgLevel);
        } else {
            if (msgLevel >= Project.MSG_INFO) { //NB: works around bug in Task.log!
                System.err.println(msg);
            }
        }
    }

// ---------------------------------------------------------------------------------------
// (AntXtras) Universal Task Assertion Facilities:
// ---------------------------------------------------------------------------------------


    /**
     * Returns this task's CV-label. Never <i>null</i>.
     **/
    public final String cvlabel_()
    {
        return Iam_;
    }


    /**
     * Throws assertion error if pre-condtion is not met.
     * @param c pre-condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalArgumentException if condition not met
     **/
    protected final void require_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.require",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalArgumentException(ermsg);
        }
    }


    /**
     * Throws assertion error if post-condition is not met. Used
     * for post-condition verification.
     * @param c post-condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalStateException if condition not met
     **/
    protected final void ensure_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.ensure",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    /**
     * Throws assertion error if condition is not met. Used for
     * block and invariant verification.
     * @param c condition
     * @param msg [optional] failure message (if not met)
     * @throws IllegalStateException if condition not met
     **/
    protected final void verify_(boolean c, String msg)
    {
        if (!c) {
            String ermsg = uistrs().get("cv.verify",Iam_,msg);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    /**
     * Verifies we're in a live project (created from build process).
     * @throws IllegalStateException if not in project
     **/
    protected final void verifyInProject_(String calr)
    {
        if (getProject()==null) {
            String ermsg = uistrs().get("cv.verifyInP",Iam_,calr);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
    }


    /**
     * Verifies we're in a live target and project (created from
     * build process).
     * @throws IllegalStateException if not in target
     **/
    protected final void verifyInTarget_(String calr)
    {
        if (getOwningTarget()==null) {
            String ermsg = uistrs().get("cv.verifyInT",Iam_,calr);
            log(ermsg, Project.MSG_ERR);
            throw new IllegalStateException(ermsg);
        }
        verifyInProject_(calr);
    }


    /**
     * Called by '<i>execute</i>' on entry to verify that all required
     * options have been specified for correct execution of this task.
     * By default just verifies this task is associated with an enclosing
     * project.
     * @param calr calling method (usually 'execute' or 'run')
     * @throws BuildException if unable to execute
     * @throws IllegalStateException if improperly configured
     **/
    protected void verifyCanExecute_(String calr)
        throws BuildException
    {
        verifyInProject_(calr);
    }



    /**
     * Check whether a project property already exists and optionally
     * barfs if it does. Instance-level wrapper for generic
     * {@linkplain FixtureExaminer#checkIfProperty FixtureExaminer}
     * method.
     * @param property name of property to check
     * @param warn <i>true</i> if only issue a warning <em>otherwise can fail</em>
     * @return <i>true</i> if property already exists
     * @throws BuildException if property exists and isn't a warning
     * @since JWare/AntX 0.3
     **/
    protected final boolean checkIfProperty_(String property, boolean warn)
    {
        require_(property!=null,"chkProp- nonzro nam");

        return FixtureExaminer.checkIfProperty(getProject(),
            new Requester.ForComponent(this), property, warn);
    }



    /**
     * Check whether a project reference already exists and optionally
     * barfs if it does. Instance-level wrapper for generic
     * {@linkplain FixtureExaminer#checkIfReference FixtureExaminer}
     * method.
     * @param refid name of reference to check
     * @param warn <i>true</i> if only issue a warning <em>otherwise can fail</em>
     * @return <i>true</i> if reference already exists
     * @throws BuildException if reference exists and isn't a warning
     * @since JWare/AntX 0.4
     **/
    protected final boolean checkIfReference_(String refid, boolean warn)
    {
        require_(refid!=null,"chkRef- nonzro refid");

        return FixtureExaminer.checkIfReference(getProject(),
            new Requester.ForComponent(this), refid, warn);
    }


    /**
     * Returns the type-checked referenced object. Common utility that
     * generates resource bundle based messages if reference broken.
     * @param from the source project (null=> this task's project)
     * @param refid the referred-to thing's identifier (non-null)
     * @param requiredClass the required class of referred-to thing (non-null)
     * @throws BuildException if no such reference or object is not compatible
     * @since JWare/AntX 0.3
     **/
    public final Object getReferencedObject(Project from, String refid,
                                            Class requiredClass)
    {
        require_(refid!=null,"getRefObj- nonzro id");

        if (from==null) {
            from= getProject();
            verify_(from!=null,"getRefObj- hav project");
        }

        return FixtureExaminer.getReferencedObject(from,
            new Requester.ForComponent(this), refid, requiredClass);
    }

// ---------------------------------------------------------------------------------------
// (AntXtras) Universal UI strings management:
// ---------------------------------------------------------------------------------------

    /**
     * Sets this task's default response message identifier.
     * This identifer is used with a {@linkplain UIStringManager} in
     * the ultimate concrete task subclass.
     **/
    public void setMessageId(String msgid)
    {
        m_msgId= msgid;
    }


    /**
     * Returns this task's default response message identifier.
     * Can return <i>null</i> if never set.
     **/
    public String getMessageId()
    {
        return m_msgId;
    }


    /**
     * Returns the localized message associated with given id. Looks for
     * messages using following steps:<ol>
     *   <li>Checks if there's a message in this task's default UI strings;
     *       if message exists, it's returned.
     *   <li>Returns msgid itself. This is useful instead of using a
     *       blank string since the msgid usually reflects some semantic
     *       meaning and it notifies the builder that the message is
     *       missing.
     * </ol>
     * @param msgId the message id (non-null)
     * @param getr retrieve UISM-based message (specific to API+args)
     * @see #getUISM
     * @see #getUISMArgs
     **/
    public String getMsg(String msgId, MsgGetter getr)
    {
        require_(msgId!=null && getr!=null,"getmsg- nonzro args");
        verifyInProject_("getMsg");

        String msg = getr.get(msgId);
        if (Tk.isWhitespace(msg)) {
            msg = msgId;
        }
        return msg;
    }


    /**
     * Same as {@linkplain #getMsg(String, MsgGetter) getMsg(String,MsgGetter)}
     * but with only the default message template variables inserted. Never
     * returns <i>null</i> but can return the empty string. The default formatting
     * automatically passes this task's name and build-file file/line information
     * to the MessageFormat.
     * @param getr the UIStringManager 'get' method pointer
     **/
    public String getMsg(MsgGetter getr)
    {
        String msgId = getMessageId();
        if (msgId==null) {
            return "";
        }
        return getMsg(msgId, getr);
    }


    /**
     * Shortcut {@linkplain #getMsg(MsgGetter) getMsg} that returns
     * the default msgid set on this task. Never returns <i>null</i> but
     * can return the empty string.
     * @see #getMessageId
     **/
    public String getMsg()
    {
        return getMsg(new MsgGetter() {
                public String get(String msgId) {
                    String out = getUISM().mget(msgId,m_UISMargs,null);
                    if (out==null) {
                        out = "";
                    }
                    return out;
                }
            });
    }


    /**
     * Helper that returns this task's (class) default msg noise level
     * as if its never been specified. Subclass can change what's returned
     * to elevate or lower the default. Never returns <i>null</i>.
     **/
    public NoiseLevel getDefaultNoiseLevel()
    {
        return NoiseLevel.getDefault(getProject());
    }


    /**
     * Initializes this task's default UISM arguments (taskname, location).
     **/
    private void getUISMDefaultArgs()
    {
        boolean shorten = Iteration.defaultdefaults().isShortLocationsEnabled();
        String mylocation = Tk.shortStringFrom(shorten, getLocation());
        m_UISMargs = new Object[]{getTaskName(), mylocation};
    }


    /**
     * Determines this task's target UIStringManager. Looks in the current
     * thread's iteration information for an activated UIStringManager. If
     * one not found, defaults to the currently installed root UIStringManager;
     * the default string manager is used only if no other string manager
     * is installed.
     * @see Iteration#stringManager
     **/
    public final UIStringManager getUISM()
    {
        synchronized (this) {
            if (m_UISMargs==null) {
                getUISMDefaultArgs();
            }
        }
        return Iteration.stringManager();
    }


    /**
     * Returns a copy of this task's always-on UIStringManager arguments.
     * @param args [optional] argument array to fill in
     **/
    public final Object[] getUISMArgs(Object[] args)
    {
        synchronized (this) {
            if (m_UISMargs==null) {
                getUISMDefaultArgs();
            }
        }
        if (args==null) {
            args = new Object[] {m_UISMargs[0],m_UISMargs[1]};
        } else {
            args[0] = m_UISMargs[0];
            args[1] = m_UISMargs[1];
        }
        return args;
    }

// ---------------------------------------------------------------------------------------

    /**
     * Helper that returns a new msg getter that uses UIStringManager
     * API for one additional non-standard argument. Task's name is always
     * for location {0} and task's declaration location is location {1}.
     * @param arg3 1st additional argument, template location {2}
     **/
    public final MsgGetter newMsgGetter(final String arg3)
    {
        return new MsgGetter() {
                public String get(String msgId) {
                    return getUISM().mget
                        (msgId, new Object[] {m_UISMargs[0],m_UISMargs[1],
                                              arg3});
                }
            };
    }


    /**
     * Helper that returns a new msg getter that uses UIStringManager
     * API for two additional arguments.
     * @param arg3 1st additional argument, template location {2}
     * @param arg4 2nd additional argument, template location {3}
     * @see #newMsgGetter(java.lang.String)
     **/
    public final MsgGetter newMsgGetter(final String arg3, final String arg4)
    {
        return new MsgGetter() {
                public String get(String msgId) {
                    return getUISM().mget
                        (msgId, new Object[] {m_UISMargs[0],m_UISMargs[1],
                                              arg3, arg4});
                }
            };
    }


    /**
     * Helper that returns a new msg getter that uses UIStringManager
     * API for one additional non-standard argument. Task's name is always
     * for location {0} and task's declaration location is location {1}.
     * @param argN [optional] template arguments (ALL of them!)
     * @see #getUISMArgs(Object[])
     * @since JWare/AntXtras 3.0.0
     **/
    public final MsgGetter newMsgGetter(final Object[] argN)
    {
        return new MsgGetter() {
                public String get(String msgId) {
                    Object[] finalArgs = argN;
                    if (argN==null)
                        finalArgs = m_UISMargs;
                    return getUISM().mget(msgId, finalArgs);
                }
            };
    }

// ---------------------------------------------------------------------------------------

    /**
     * Returns instance of an <em>internal JWare/AntX</em> string or if
     * not found, the message identifier itself (as a placeholder).
     * @param msgId AntX message id (non-null)
     * @see #uistrs
     **/
    public final String getAntXMsg(String msgId)
    {
        require_(msgId!=null,"getAntXMsg- nonzro msgId");
        String msg = uistrs().get(msgId);
        if (Tk.isWhitespace(msg)) {
            msg = msgId;
        }
        return msg;
    }


    /**
     * Returns instance of a custom <em>internal JWare/AntX</em> string
     * or if not found the message identifier itself (as a placeholder).
     * @param msgId message id
     * @param arg1 additional argument, template location {0}
     **/
    public final String getAntXMsg(String msgId, String arg1)
    {
        require_(msgId!=null,"getAntXMsg- nonzro msgId");
        String msg = uistrs().get(msgId, arg1);
        if (Tk.isWhitespace(msg)) {
            msg = msgId;
        }
        return msg;
    }


    /**
     * Returns instance of a custom <em>internal JWare/AntX</em> string
     * or if not found the message identifier itself (as a placeholder).
     * @param msgId message id
     * @param arg1 1st additional argument, template location {0}
     * @param arg2 2nd additional argument, template location {1}

     **/
    public final String getAntXMsg(String msgId, String arg1, String arg2)
    {
        require_(msgId!=null,"getAntXMsg- nonzro msgId");
        String msg = uistrs().get(msgId, arg1,arg2);
        if (Tk.isWhitespace(msg)) {
            msg = msgId;
        }
        return msg;
    }


    /**
     * Returns instance of a custom <em>internal JWare/AntX</em> string
     * or if not found the message identifier itself (as a placeholder).
     * @param msgId message id
     * @param arg1 1st additional argument, template location {0}
     * @param arg2 2nd additional argument, template location {1}
     * @param arg3 3rd additional argument, template location {2}

     **/
    public final String getAntXMsg(String msgId, String arg1, String arg2, String arg3)
    {
        require_(msgId!=null,"getAntXMsg- nonzro msgId");
        String msg = uistrs().get(msgId, arg1,arg2,arg3);
        if (Tk.isWhitespace(msg)) {
            msg = msgId;
        }
        return msg;
    }


    private final String Iam_;
    private String m_msgId;
    Object[] m_UISMargs;
    private boolean m_initedOnce;
    private boolean m_configuredOnce;//Ant 1.7 pains
}

/* end-of-AssertableTask.java */
