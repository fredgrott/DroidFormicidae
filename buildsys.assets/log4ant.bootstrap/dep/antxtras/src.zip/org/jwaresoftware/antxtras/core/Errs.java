/**
 * $Id: Errs.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * Collection of <em>very</em> frequently used AntXtras error messages.
 *
 * @since    JWare/AntX 0.6.0
 * @author   ssmc, ssmc, &copy;2007-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/
public class Errs
{
    /** Template for: {@value}. */
    public static final String CLONE_BROKEN_MSGID= "cv.clone.broken";
    public static final String CloneInternalError() {
        return AntX.uistrs().get(CLONE_BROKEN_MSGID);
    }

    public static final String TNTA  = "task.needs.this.attr";
    /** Tasks of type "&#123;0&#125;" require a "&#123;1&#125;" attribute. */
    public static final String NeedsThisAttribute(String type, String attrname) {
        return AntX.uistrs().get(TNTA,type,attrname);
    }

    public static final String TIPV  = "task.illegal.param.value";
    /** Items of type "&#123;0&#125;" do not permit the value "&#123;1&#125;" 
     * for the " &#123;2&#125;" parameter. */
    public static final String IllegalParameterValue(String source, String param, String badvalue) {
        return AntX.uistrs().get(TIPV,source,badvalue,param);
    }

    public static final String TOOOA = "task.one.or.other.attr";
    /** Can only specify either a "&#123;0&#125;" or a "&#123;1&#125;" parameter. */
    public static final String OneOrOtherAttribute(String one, String other) {
        return AntX.uistrs().get(TOOOA,one,other);
    }

    /** Template for: {@value}. */
    public static final String TOOSI = "taskset.only.one.specialtask";
    
    /** Cannot nest a "&#123;0&#125;" element, another "&#123;1&#125;" element is already defined. */
    public static final String OnlyOneSpecialTask(String name) {
        return AntX.uistrs().get(TOOSI,name,name);
    }

    /** Cannot nest a "&#123;0&#125;" element, another "&#123;1&#125;" element is already defined. */
    public static final String OnlyOneSpecialTask(String first, String second) {
        return AntX.uistrs().get(TOOSI,first,second);
    }

    /** Can only specify ONE of the attributes "&#123;0&#125;" as a parameter. */
    public static final String TOOA = "task.only.oneof.attr";
    public static final String OnlyOneOfAttributeSet(String set) {
        return AntX.uistrs().get(TOOA,set);
    }

    /** Unable to locate or read item at path: &#123;0&#125;. */
    public static final String FNF   = "task.err.filenotfound";
    public static final String FileNotFound(String path) {
        return AntX.uistrs().get(FNF,path);
    }
    
    /** The &#123;0&#125; task allows only one "&#123;1&#125;" element. */
    public static final String OST   = "task.one.specialtask";
    public static final String OnlyOneSpecialElement(String source, String element) {
        return AntX.uistrs().get(OST,source,element);
    }

    /** The reference "&#123;0&#125;" is not of a compatible type 
     * (want "&#123;1&#125;", have "&#123;2&#125;")*/
    public static final String TBR = "task.bad.refid";
    public static final String BadReferenceId(String refid, String want, String have) {
        return AntX.uistrs().get(TBR,refid,want,have);
    }

    /** The reference "&#123;0&#125;" does not exist. */
    public static final String TMR = "task.missing.refid";
    public static final String MissingReferenceId(String refid) {
        return AntX.uistrs().get(TMR,refid);
    }

    /** Tasks of type "&#123;0&#125;" do not support the "&#123;1&#125;" attribute(s). */
    public static final String TUA = "task.unsupported.attr";
    public static final String UnsupportedAttribute(String source, String attr) {
        return AntX.uistrs().get(TUA,source,attr);
    }

    /** Tasks of type "{0}" cannot be nested in {1} tasks. */
    public static final String UnsupportedNestedElement(String source, String element) {
        return AntX.uistrs().get("taskset.nested.task.disallowed",element,source);
    }

    /** The update property(&#123;0&#125;) already exists; it cannot be overwritten. */
    public static final String PropertyExists(String property) {
        return AntX.uistrs().get("task.warn.property.exists",property);
    }

    /** The new refid(&#123;0&#125;) belongs to an existing reference. */
    public static final String ReferenceExists(String refid) {
        return AntX.uistrs().get("task.warn.refid.exists",refid);
    }

    /** Can only specify one of the attributes: property, variable, or reference. */
    public static final String TooManyFlexibleAttributes() {
        return AntX.uistrs().get("task.too.many.flex.attrs");
    }

    /** The current thread's &#123;0&#125; stack has been fatally corrupted. */
    public static final String FixtureOverlayContextStackCorrupted(String fxid) {
        return AntX.uistrs().get("context.stack.corrupted",fxid);
    }

    /** The nested &#123;0&#125; item is improperly defined (&#123;1&#125;) */
    public static final String ItemImproperlyDefined(String itemid, String how) {
        return AntX.uistrs().get("task.bad.nested.item",itemid,how);
    }

    /** Unable to write to output stream because: &#123;0&#125;. */
    public static final String UnableToWriteToOutputSream(String because) {
        String msgid = (because==null) ? "task.echo.unable": "task.echo.unable.because";
        return AntX.uistrs().get(msgid,because);
    }

    /** Unable to create or access(rw) directory: &#123;0&#125;. */
    public static final String UnableToRWOrCreateDirectory(String path) {
        return AntX.uistrs().get("task.cant.access.dir",path);
    }

    /** A non-directory item already exists at path (&#123;0&#125;). */
    public static final String NonDirectoryExistsAt(String path) {
        return AntX.uistrs().get("mktemp.mkdirs.file.exists",path);
    }

    /** Unable to truncate file ({0}) because: {1}. */
    public static final String CantTruncateFileBecause(String path, String cause) {
        return AntX.uistrs().get("mktemp.truncfile.cant",path,cause);
    }

    /** Unable to use file "&#123;0&#125;" because &#123;1&#125;. */
    public static final String CantUseFileBecause(String path, String issue) {
        return AntX.uistrs().get("task.echo.unable.use.file",path,issue);
    }

    /** The "&#123;0&#125;" component requires at least one of these nested elements [&#123;1&#125;].  */
    public static final String NeedsOneOfTheseNested(String type, String item) {
        return AntX.uistrs().get("task.needs.oneof.these.nested",type,item);
    }

    /** Unable to load configuration file "&#123;0&#125;"; error: &#123;1&#125;. */
    public static final String CantLoadConfigSource(String name, String cause) {
        return AntX.uistrs().get("task.bad.configfile",name,cause);
    }

    /** Unable to translate resource "&#123;0&#125;" into an input stream. */
    public static final String CantFindInputStreamForResource(String name) {
        return AntX.uistrs().get("task.nostream.from.rez",name);
    }

    /** A malformed declaration was detected: {0}({1}), value({2}). */
    public static final String MalformedValueFound(String type, String name, String value) {
       return AntX.uistrs().get("fixture.malformed.value.found",type,name,value); 
    }

    protected Errs()
    {}
}


/* end-of-Errs.java */
