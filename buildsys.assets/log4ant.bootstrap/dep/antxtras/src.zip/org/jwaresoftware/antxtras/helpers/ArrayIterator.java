/**
 * $Id: ArrayIterator.java 390 2008-03-30 17:51:32Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.lang.reflect.Array;
import  java.util.Enumeration;
import  java.util.Iterator;
import  java.util.NoSuchElementException;

/**
 * Iterator and Enumeration implementation for a Java array.
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2000-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @.pattern GoF.Adapter
 **/

public class ArrayIterator extends NoRemoveIteratorSkeleton implements Iterator, Enumeration
{
    private final Object m_array;
    private final int m_len;
    private int m_i;

    /**
     * Creates new iterator for given array.
     * @param array array to iterate (non-null array)
     **/
    public ArrayIterator(Object array)
    {
        if (array==null || !array.getClass().isArray()) {
            throw new IllegalArgumentException("ctor- nonzro ary reqd");
        }
        m_array = array;
        m_len = Array.getLength(array);
    }


    /**
     * Returns <i>true</i> if more elements in array to iterate.
     **/
    public boolean hasNext()
    {
        return m_i < m_len;
    }


    /**
     * Returns <i>true</i> if more elements in array to iterate.
     **/
    public final boolean hasMoreElements()
    {
        return hasNext();
    }


    /**
     * Returns next object in array and advances iteration by one.
     * @throws NoSuchElementException if iteration finished
     **/
    public Object next()
    {
        if (m_i>=m_len) {
            throw new NoSuchElementException();
        }
        return Array.get(m_array,m_i++);
    }


    /**
     * Same as {@linkplain #next}.
     **/
    public final Object nextElement()
    {
        return next();
    }


    /**
     * Returns index of last element returned returned by either
     * {@linkplain #next} or {@linkplain #nextElement}.
     **/
    public int nextIndex()
    {
        return (m_i>=m_len) ? m_len : m_i;
    }


    /**
     * Unsupported removal operation (arrays are immutable).
     * @throws java.lang.UnsupportedOperationException always
     **/
    public void remove()
    {
        throw new UnsupportedOperationException("Cannot remove slot from Java array");
    }
}

/* end-of-ArrayIterator.java */
