/**
 * $Id: LogsRecorder.java 1510 2012-09-24 23:26:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.capture;

/**
 * Any iteration-based helper that captures Ant logged messages or System stream
 * messages.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2005,2008,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,helper
 **/

public interface LogsRecorder
{
    /** Marker value for a logs recorder that can capture unlimited
     *  amounts of data. **/
    public static final int UNLIMITED_CHARS = -1;


    /**
     * Returns a <em>copy</em> of this recorder's current important
     * logs. The returned messages are determined by what this
     * recorder considers important.
     **/
    String copyOfImportantLogs();


    /**
     * Returns a <em>copy</em> of all logs captured by this recorder
     * so far. The returned string contains all levels of messages
     * from debug to fatal since recorder was started or last reset.
     * @see #copyOfImportantLogs
     **/
    String copyOfAllLogs();


    /**
     * Clears this recorder's logs as if no log event ever
     * recorded.
     **/
    void clearLogs();
}

/* end-of-LogsRecorder.java */
