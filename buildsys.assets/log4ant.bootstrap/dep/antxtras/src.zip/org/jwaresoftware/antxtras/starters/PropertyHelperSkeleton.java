/**
 * $Id: PropertyHelperSkeleton.java 1042 2010-03-27 16:52:23Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.MagicNames;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;

import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.PropertyFactoryMethod;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.RPParser;

/**
 * Starter for a PropertyHelper that can be installed and uninstalled throughout
 * a build iteration's lifetime. Implements a standard <span class="src">install</span> 
 * and <span class="src">uninstall</span> method. Also supports recursive
 * property definitions automatically.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   guarded (as inherited)
 * @.group    impl,infra
 * @see       RPParser
 * @see       org.jwaresoftware.antxtras.behaviors.PropertyHelperWrap
 **/

public abstract class PropertyHelperSkeleton extends PropertyHelper
    implements ProjectDependent, Nameable
{
    /**
     * Initializes a new property helper replacement.
     * @param iam cv-label (non-null)
     **/
    protected PropertyHelperSkeleton(String iam)
    {
        super();
        this.IAM_ = iam;
    }



    /**
     * Associates this helper with a project. This helper still has
     * to be {@linkplain #install(Project,Requester) installed}
     * explicitly.
     * @.safety single
     **/
    public void setProject(Project project)
    {
        super.setProject(project);
        m_rqlink = new Requester.ForProject(project);
        m_pfm = new PropertyFactoryMethod.FromProject(project);
    }



    /**
     * Returns the helper that was original replaced by this 
     * one. Never returns <i>null</i> <em>when installed</em>.
     **/
    protected PropertyHelper getReplacedHelper()
    {
        return m_realPH;
    }



    /**
     * Returns <i>true</i> if we're installed.
     * @since JWare/AntXtras 3.0.0
     **/
    public boolean isInstalled() 
    {
        return m_realPH!=null;
    }



    /**
     * Initializes this helper's diagnostics-friendly name.
     * @param name helper's name (non-null)
     * @.safety single
     **/
    public final void setName(String name)
    {
        AntX.require_(name!=null,IAM_,"setName- nonzro name");
        m_nameImpl = name;
    }



    /**
     * Returns this helper's diagnostics label. Will return
     * "n/d" if never set explicitly.
     * @.safety single
     */
    public final String getName()
    {
        return m_nameImpl;
    }



    /**
     * Returns this helper's project ensuring that value is still defined.
     * @throws IllegalStateException if this helper has no project
     */
    protected final Project getProjectNoNull()
    {
        Project P = getProject();
        AntX.verify_(P!=null,IAM_,"getProject- still non-null");
        return P;
    }



    /**
     * Returns this helper's property parser ensuring that value 
     * is still initialized. When creating underlying parser takes  
     * into account whether parser should allow '\' as a general
     * escape character. For instance 'property \${foo}' 
     * would not expand the embedded '${foo}'. Enabled by default.
     * @since JWare/AntXtras 3.0.0
     **/
    private RPParser getParserNoNull()
    {
        if (m_rpp==null) {
            if (m_rppEscapes==null) {
                Project p = getProjectNoNull();
                m_rppEscapes = Boolean.valueOf
                    (Iteration.defaultdefaults().isEscapesInParsingAllowed(p));
            }
            m_rpp = new RPParser(m_rppEscapes.booleanValue(),false);
        }
        return m_rpp;
    }



    /**
     * Ensure this helper is not already installed in the given project's
     * property helper (or hook chain). Prevents infinite (circular) lookups.
     **/
    protected final void verifyNotInChain_(PropertyHelper ph, Requester calr)
    {
        AntX.verify_(ph!=null,IAM_,"install- Ant env inited");
        if (ph==this) {
            String error = AntX.uistrs().get("fixture.ph.install.once",getName());
            calr.log(error,Project.MSG_ERR);
            throw new BuildException(error,calr.getLocation());
        }
    }



    /**
     * Installs this helper as the given project's property helper.
     * @param project this helper's associated project
     * @param calr [optional] caller link
     * @return <i>true</i> if net installed first time
     * @return <i>false</i> if already installed directly or indirectly
     * @.safety single
     **/
    public boolean install(Project project, Requester calr)
    {
        AntX.require_(project!=null,IAM_,"install- nonzro project");
        setProject(project);

        if (calr==null) {
            calr = m_rqlink;
        }
        PropertyHelper current = PropertyHelper.getPropertyHelper(project);
        verifyNotInChain_(current,calr);

        log(calr,"Installing...",Project.MSG_VERBOSE);
        m_realPH = current;
        project.getReferences().put(MagicNames.REFID_PROPERTY_HELPER,this);
        
        AntX.verify_(PropertyHelper.getPropertyHelper(project)==this,
                     IAM_,"install- installed properly");
        return true;
    }



    /**
     * Uninstalls this net as its project's property helper.
     * Will reinstall the helper that was there when this net
     * was installed.
     * @param calr [optional] caller link
     * @throws BuildException if this net is not currently installed
     **/
    public void uninstall(Requester calr)
    {
        Project project = getProjectNoNull();
        if (calr==null) {
            calr = m_rqlink;
        }
        PropertyHelper current = PropertyHelper.getPropertyHelper(project);
        if (current==this) {
            log(calr,"Uninstalling...",Project.MSG_VERBOSE);
            project.getReferences().put(MagicNames.REFID_PROPERTY_HELPER,getReplacedHelper());
            m_realPH = null;
        } else if (current!=null) {
            m_realPH = null;
            String error = AntX.uistrs().get("fixture.ph.not.instald",getName());
            calr.problem(error,Project.MSG_ERR);
            throw new BuildException(error,calr.getLocation());
        }
    }



    /**
     * Returns <i>true</i> if this helper will signal an error if a malformed
     * property deference is encountered during parsing. Will check the global
     * property by default.
     * @since JWare/AntXtras 3.0.0
     **/
    protected boolean isHaltIfErrorForMalformedProperties()
    {
        return Iteration.defaultdefaults().isHaltIfError
                    ("malformedproperties",getProjectNoNull());
    }



    /**
     * Replaces all property references in given value including nested 
     * property references. Replaces inherited method to handle nested
     * properties. Note that funcut handling is NOT implemented here!
     * @see RPParser
     **/
    public Object parseProperties(String value)
    {
        if (m_realPH==null) {
            return super.parseProperties(value);
        }
        RPParser.Result r = getParserNoNull().interpolate(value,m_pfm,m_rqlink);
        if (r.malformed || r.unresolved) {
            String warning = AntX.uistrs().get("valueuri.rpp.malformed.value",value);
            m_rqlink.log(warning, Project.MSG_VERBOSE);
            if (r.malformed && isHaltIfErrorForMalformedProperties()) {
                throw new BuildException(warning);
            }
        }
        return r.result;
    }



    /**
     * Scans the given value to see if there are any property references
     * embedded in it. Will <em>not</em> throw an error if the value 
     * is judged to be malformed unless told to; this is not the same 
     * (default) behavior as the standard property evaluator which barfs
     * unconditionally always.
     * @see RPParser
     * @since JWare/AntXtras 3.0.0
     **/
    public boolean containsProperties(String value)
    {
        if (m_realPH==null) {
            return super.containsProperties(value);
        }
        RPParser.Result r = getParserNoNull().interpolate(value,m_pfmPreflight,m_rqlink);
        if (r.malformed && isHaltIfErrorForMalformedProperties()) {
            String error = AntX.uistrs().get("valueuri.rpp.malformed.value",value);
            throw new BuildException(error);
        }
        return r.edits>0;
    }


    protected final void log(Requester calr, String msg, int noiselevel)
    {
        calr.log("PropertyHelper("+getName()+"): "+msg, noiselevel);
    }


    protected final String IAM_;
    protected Requester m_rqlink;
    private String m_nameImpl="n/d";
    private PropertyHelper m_realPH;
    private PropertyFactoryMethod m_pfm;
    private PropertyFactoryMethod m_pfmPreflight = new PropertyFactoryMethod.ForConstant("-");
    private Boolean m_rppEscapes;
    private RPParser m_rpp;
}

/* end-of-PropertyHelperSkeleton.java */
