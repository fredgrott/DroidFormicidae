/**
 * $Id: PropertiesList.java 1172 2010-11-07 17:35:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.types;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.FilterChain;

import  org.jwaresoftware.antxtras.behaviors.PropertiesFactoryMethod;
import  org.jwaresoftware.antxtras.behaviors.PropertySetMethod;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.construct.PropertiesLoaderDef;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.ListFriendly;

/**
 * Script facing type for the standard {@linkplain PropertiesLoaderDef}
 * utility that lets you load a Java properties source (XML or
 * standard) into Ant as a <span class="src">Properties</span> type.
 * Note that the underlying source is lazy-loaded by the factory
 * method {@linkplain #toProperties(Project) toProperties} the first
 * time the actual Properties object is needed. The loaded Properties
 * object is then <em>CACHED and REUSED</em>.
 * <p/>
 * When printed as a string a properties' pairs are separated by the
 * platform's newline string unless its <span class="src">delim</span>
 * attribute has been set.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;<b>properties</b> id="shared-conf.def"
 *         resource="staging/META-INF/shared-conf.properties"/&gt;
 *
 *  &lt;<b>properties</b> id="build-messages"
 *         mustexist="yes"
 *         file="${build.d}/${module}/feedback-messages.xml"/&gt;
 *
 *  &lt;<b>properties</b> id="modules" mustexist="yes"
 *         url="${buildserver.url}/${project}/modules"
 *         format="xml" delim=";"/&gt;
 *
 *  &lt;<b>properties</b> id="shared-conf.def"
 *         resource="shared-conf.properties"
 *         classpath="${local-conf.d}:${shared-conf.d}"&gt;
 *      &lt;filterchain&gt;
 *          &lt;expandproperties/&gt;
 *      &lt;filterchain&gt;
 *  &lt;/properties&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   guarded (after fully configured)
 * @.group    api,helper
 * @see       org.jwaresoftware.antxtras.types.Parameters
 **/

public class PropertiesList extends PropertiesLoaderDef
    implements PropertiesFactoryMethod, ListFriendly, PropertySetMethod
{
    private static final String IAM_= AntX.fixture+"PropertiesList:";


    /** Default delimiter used by all parameter sets. **/
    public static final String DEFAULT_DELIMITER = Strings.NL;



    /**
     * Initializes a new properties set object.
     **/
    public PropertiesList()
    {
        super(IAM_);
    }



    /**
     * Our implementation data type name is 'properties'
     * not 'propertiesdef' (as inherited).
     */
    protected String getCN()
    {
        return "properties";
    }



    /**
     * Returns this set's prep filter chain. Never <i>null</i>.
     **/
    public FilterChain createFilterChain()
    {
        if (m_filterChain==null) {
            m_filterChain = new FilterChain();
            m_filterChain.setProject(getProject());
        }
        return m_filterChain;
    }



    /**
     * Sets a custom delimiter for this properties. This
     * delimiter is used by all stringification(TM) methods.
     * @param delimiter new delimiter (non-blank)
     **/
    public void setDelim(String delimiter)
    {
        AntX.require_(delimiter!=null,IAM_,"setDelim- nonzro delim");
        m_delim = delimiter;
    }



    /**
     * Returns the Properties of the items loaded by
     * this properties set. Will load source for first time
     * if needed (lazy-loaded); thereafter returns the
     * <em>same</em> Properties object!
     */
    public synchronized Properties toProperties(Project wrtProject)
    {
        if (m_loadedProperties==null) {
            m_loadedProperties = newProperties(null,m_filterChain,
                    new Requester.ForComponent(this));
        }
        return m_loadedProperties;
    }



    /**
     * Returns an iterator for all stringified key-value pairs
     * in this set. Each item is a single string of form:
     * <i>key</i>=<i>value</i> where <i>value</i> can be the
     * empty string.
     * @param wrt [optional] the context project (can be <i>null</i>)
     */
    public Iterator readonlyStringIterator(Project wrt)
    {
        Map items = toProperties(wrt);
        List kvpairs = AntXFixture.newList(items.size());
        Iterator itr = items.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry e = (Map.Entry)itr.next();
            String rawvalue = e.getValue().toString();//NB:nevr-null!
            String v = Tk.resolveString(wrt,rawvalue,true);
            if (Tk.isWhitespace(v)) {
                kvpairs.add(""+e.getKey());
            } else {
                kvpairs.add(""+e.getKey()+"="+v);
            }
        }
        return kvpairs.iterator();
    }



    /**
     * Returns the string-form appropriate for this properties object.
     * @param wrt [optional] the context project (can be <i>null</i>)
     **/
    public String stringFrom(Project wrt)
    {
        StringBuffer sb = AntXFixture.newLargeStringBuffer();
        int N=0;
        Iterator itr= readonlyStringIterator(wrt);

        while (itr.hasNext()) {
            if (N>0) {
                sb.append(m_delim);
            }
            sb.append(itr.next().toString());
            N++;
        }
        itr=null;
        return sb.substring(0);
    }



    /**
     * Returns the number of keys in this set's underlying Properties
     * object. Will load properties if needed (first time; one time).
     */
    public int size()
    {
        return toProperties(getProject()).size();
    }


    /**
     * Returns <i>true</i> if this set is empty (no keys).
     */
    public boolean isEmpty()
    {
        return size()==0;
    }



    /**
     * Adapter set-property interface for this object. Lets our
     * data types act as sinks for all sorts of fun edit operations.
     * @param name property's name (non-null)
     * @param value property's value (non-null)
     */
    public void setProperty(String name, String value)
    {
        toProperties(getProject()).setProperty(name, value);
    }


    private String  m_delim = DEFAULT_DELIMITER;
    private FilterChain m_filterChain;
    private Properties m_loadedProperties;
}


/* end-of-PropertiesList.java */
