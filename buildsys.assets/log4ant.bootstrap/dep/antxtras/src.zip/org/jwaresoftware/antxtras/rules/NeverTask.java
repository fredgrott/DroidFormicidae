/**
 * $Id: NeverTask.java 1020 2010-03-13 18:12:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.Task;

import  org.jwaresoftware.antxtras.behaviors.TestScriptComponent;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;

/**
 * Test task that unconditionally throws an standard Error. See the {@linkplain
 * org.jwaresoftware.antxtras.flowcontrol.StopTask StopTask} for a build-script
 * variant of Never. <b>Implementation Note:</b> a NeverTask throws a plain
 * <span class="src">java.lang.Error</span> to differentiate it from an AntXtras
 * BuildError. This allows tests to determine if an expected BuildError was
 * generated instead of a Never error.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,test,helper
 * @see      org.jwaresoftware.antxtras.flowcontrol.StopTask
 **/

public final class NeverTask extends Task
    implements TestScriptComponent
{
    /**
     * Initializes a new NeverTask.
     **/
    public NeverTask()
    {
        super();
    }



    /**
     * Assigns this task a custom script message to display.
     * @param message the message (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setMessage(String message)
    {
        m_errorMsg = message;
    }



    /**
     * Throws an Error.
     * @throws Error always
     **/
    public void execute()
    {
        String info = m_errorMsg;
        if (info==null) {
            String purtylocation = LocalTk.purtyLocation(getLocation());
            info = AntX.uistrs().get("never.msg",purtylocation);
        }
        throw new Error(info);
    }


    private String m_errorMsg;
}

/* end-of-NeverTask.java */
