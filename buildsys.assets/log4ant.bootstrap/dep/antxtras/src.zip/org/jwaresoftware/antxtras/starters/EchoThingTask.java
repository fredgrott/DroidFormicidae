/**
 * $Id: EchoThingTask.java 1155 2010-10-01 13:21:18Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Skeleton for a helper task that displays some internal 
 * single AntXtras variable or data type instance.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public abstract class EchoThingTask extends ShowTask
{
    /**
     * Platform-specific newline.
     **/
    protected static final String NL= Strings.NL;



    /**
     * Initializes new CV-labeled EchoThingTask.
     * @param iam CV-label (non-null)
     **/
    protected EchoThingTask(String iam)
    {
        super(iam);
    }

// ---------------------------------------------------------------------------------------
// Implementation helpers:
// ---------------------------------------------------------------------------------------

    /**
     * Initializes the reference id of this task's thing.
     **/
    protected final void setThingRefId(String refId)
    {
        require_(refId!=null,"setRefId- nonzro refid");
        m_refId = refId;
    }


    /**
     * Returns this task's thing reference id; can be <i>null</i>
     * if never set. Required for task to execute properly.
     **/
    protected final String getThingRefId()
    {
        return m_refId;
    }


    /**
     * Returns the parameter name of this task's thing refid.
     * Used in diagnostic messages.
     * @since JWare/AntX 0.4
     **/
    protected String getThingRefParameterName()
    {
        return "refid";//backward compatible
    }


    /**
     * Returns the actual thing instance echoed by this task. Never
     * returns <i>null</i>.
     * @param ofKind thing's required class (non-null)
     * @param msgid id of error message used if reference invalid
     * @throws BuildException if refid undefined or not a a valid thing
     **/
    protected Object getReferencedThing(Class ofKind, String msgid)
        throws BuildException
    {
        require_(ofKind!=null,"getRefTing- nonzro clas");
        String refid = getThingRefId();
        if (msgid==null) {
            return getReferencedObject(null,refid,ofKind);
        }
        Object object = getProject().getReference(refid);
        if (!ofKind.isInstance(object)) {
            String ermsg = uistrs().get(msgid,refid);
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
        return object;
    }


    /**
     * Ensures we're in a valid target/project and have a defined
     * thing reference id. Subclasses must ensure the referenced thing
     * is of the expected type.
     * @see #getReferencedThing
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (getThingRefId()==null) {
            String ermsg = uistrs().get(Errs.TNTA,
                                        getTaskName(),getThingRefParameterName());
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg, getLocation());
        }
    }


    /**
     * Echoes this task's referenced thing iff execution conditions
     * have been met. Subclass should implement the {@linkplain #echoThing
     * echoThing} method.
     * @throws BuildException if invalid refid or a file I/O
     *         error occurs.
     * @see #echoThing
     **/
    public void execute() throws BuildException
    {
        verifyCanExecute_("execute");

        if (executeAllowed()) {
            echoThing();
        }
    }


    /**
     * Actual task echoing work; subclass must provide.
     * @throws BuildException if invalid refid or a file I/O
     *         error occurs.
     **/
    protected abstract void echoThing() throws BuildException;


    //Thing to echo
    private String m_refId;
}

/* end-of-EchoThingTask.java */
