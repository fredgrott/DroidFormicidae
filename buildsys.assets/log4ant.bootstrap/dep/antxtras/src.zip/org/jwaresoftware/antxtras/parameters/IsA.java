/**
 * $Id: IsA.java 1146 2010-05-23 13:35:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Enumeration of a flex value's possible interpretation: as a literal, 
 * as a property, as a reference, or as a variable (exported property).
 * <p/>
 * We support several shorthand ways for describing an 'is-a' selector;
 * in particular, the single characters [p,v,r,l] refer to property,
 * variable, reference, and literal in order.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2003-2004,2006,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public class IsA extends EnumSkeleton
{
    //  @.impl ORDERING of static declarations is important! ------

    //  1) Indices (in order)

    /** Index of {@linkplain #LITERAL LITERAL}. **/
    public static final int LITERAL_INDEX= 0;
    /** Index of {@linkplain #PROPERTY PROPERTY}. **/
    public static final int PROPERTY_INDEX= LITERAL_INDEX+1;
    /** Index of {@linkplain #VARIABLE VARIABLE}. **/
    public static final int VARIABLE_INDEX= PROPERTY_INDEX+1;
    /** Index of {@linkplain #REFERENCE REFERENCE}. **/
    public static final int REFERENCE_INDEX= VARIABLE_INDEX+1;

    /** The number of base is-a values.
     *  @since JWare/AntX 0.6
     **/
    protected static final int BASE_VALUE_COUNT= REFERENCE_INDEX+1;

    //2) Values (in order)

    /** Values in same order as public indices. **/
    private static final String[] VALUES_= new String[] {
        "literal", "property", "variable", "reference"
    };

    //3) Singletons (depend on Indices and Values already existing!)

    /** Singleton "literal" Is-A. **/
    public static final IsA LITERAL =
        new IsA(VALUES_[LITERAL_INDEX],LITERAL_INDEX);

    /** Singleton "property" Is-A. **/
    public static final IsA PROPERTY =
        new IsA(VALUES_[PROPERTY_INDEX],PROPERTY_INDEX);

    /** Singleton "variable" Is-A. **/
    public static final IsA VARIABLE =
        new IsA(VALUES_[VARIABLE_INDEX],VARIABLE_INDEX);

    /** Singleton "reference" Is-A. **/
    public static final IsA REFERENCE =
        new IsA(VALUES_[REFERENCE_INDEX],REFERENCE_INDEX);


    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public IsA()
    {
        super();
    }



    /**
     * Use to create public singletons. Ensure it's initialized
     * as with default Ant Introspector helper thingy.
     **/
    private IsA(String v, int i)
    {
        super(v);
    }



    /**
     * Returns a <em>copy</em> of the standard is-a values
     * in order. Subclasses can use this method to pre-fill their
     * value arrays with the inherited list.
     * @param fillin [optional] array of strings to update with values.
     * @since JWare/AntX 0.6
     **/
    public static String[] copyOfDefaultValues(String[] fillin)
    {
        if (fillin==null) {
            fillin = new String[VALUES_.length];
        }
        System.arraycopy(VALUES_,0,fillin,0,VALUES_.length);
        return fillin;
    }



    /**
     * Returns copy of all possible source values as an ordered
     * string array. Note: ordering should be same as our
     * singleton indices.
     **/
    public String[] getValues()
    {
        return IsA.copyOfDefaultValues(null);
    }



    /**
     * Helper that converts a string to a known IsA singleton.
     * Returns <i>null</i> if string unrecognized. String can be
     * either IsA's symbolic name or its index.
     **/
    public static IsA from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            if ("p".equals(s))             { return PROPERTY; }
            if ("prop".equals(s))          { return PROPERTY; }
            if (PROPERTY.value.equals(s))  { return PROPERTY; }
            if ("v".equals(s))             { return VARIABLE; }
            if ("var".equals(s))           { return VARIABLE; }
            if (VARIABLE.value.equals(s))  { return VARIABLE; }
            if ("r".equals(s))             { return REFERENCE;}
            if ("ref".equals(s))           { return REFERENCE;}
            if (REFERENCE.value.equals(s)) { return REFERENCE;}
            if ("l".equals(s))             { return LITERAL;  }
            if ("value".equals(s))         { return LITERAL;  }
            if (LITERAL.value.equals(s))   { return LITERAL;  }

            if ("variables".equals(s))     { return VARIABLE; }
            if ("references".equals(s))    { return REFERENCE;}
            if ("properties".equals(s))    { return PROPERTY; }
            if ("default".equals(s))       { return PROPERTY; }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(java.lang.String) from(String)} but
     * with a default value if value does not match any known
     * IsA's name.
     * @param s the symbolic name to be matched
     * @param dflt the default IsA if necessary
     **/
    public static IsA from(String s, IsA dflt)
    {
        IsA isa= from(s);
        return (isa==null) ? dflt : isa;
    }
}

/* end-of-IsA.java */
