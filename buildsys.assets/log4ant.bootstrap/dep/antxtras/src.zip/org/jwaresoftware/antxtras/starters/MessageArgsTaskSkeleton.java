/**
 * $Id: MessageArgsTaskSkeleton.java 1303 2011-10-22 11:52:46Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.DynamicAttribute;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Extension of the basic AntXtras {@linkplain AssertableTask} that adds
 * support for message template arguments.
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   guarded
 * @.group    impl,helper
 **/

public abstract class MessageArgsTaskSkeleton extends AssertableTask
    implements DynamicAttribute
{
    /**
     * Initializes new CV-labeled task.
     * @param iam CV-label (non-null)com.idare
     **/
    protected MessageArgsTaskSkeleton(String iam)
    {
        super(iam);
    }



    /**
     * Adds an arbitrary message argument for use with final message.
     * Argument parameters must begin with 'arg' and end with the zero-based
     * index for the message template; for example 'arg0' for template
     * item '{0}'.
     * @param name condition name (no namespace)
     * @param value parameter's actual value (non-null)
     * @since JWare/AntXtras 2.0.0
     * @throws BuildException if attribute's name is not a recognized
     *         message argument
     **/
    public void setDynamicAttribute(final String name, String value)
    {
        require_(name!=null, "setArgX- nonzro arg name");
        require_(value!=null,"setArgX- nonzro arg valu");

        String lname = Tk.lowercaseFrom(name.trim());
        if (!setDynamicMessageArgs(lname,value)) {
            String err = getAntXMsg(Errs.TUA,getTaskName(),name);
            log(err,Project.MSG_ERR);
            throw new BuildException(err,getLocation());
        }
    }

// ---------------------------------------------------------------------------------------
// Implementation:
// ---------------------------------------------------------------------------------------

    /**
     * Initialize a new message argument array. By default will fill in
     * the first two slots with the task's name and location. Subclasses
     * can include other pre-defined slots.
     * @param args args array to intializes (10 slots) (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    protected void initMessageArgs(String[] args)
    {
        super.getUISMArgs(args);
    }



    /**
     * Work method for extracting dynamic message arguments. If
     * parameter not recognized as a message template argument (begins
     * with 'arg' and ends with an index 0-9), returns <i>false</i>.
     * @param lname normalized parameter name (non-null)
     * @param value parameter value (non-null)
     * @return true if accepted as a message template argument.
     **/
    protected final boolean setDynamicMessageArgs(final String lname, String value)
    {
        boolean ok = false;
        if (lname.length()>=4 && lname.startsWith("arg")) {
            String indexstring = lname.substring(3);
            int index = Tk.integerFrom(indexstring,-1);
            if (index>=0 && index<10) {
                ok = true;
                if (m_args==null) {
                    m_args = new String[10];
                    for (int i=0;i<m_args.length;i++) { m_args[i]= ""; }
                    initMessageArgs(m_args);
                }
                m_args[index] = value;
            }
        }
        return ok;
    }



    /**
     * Returns this task's dynamically defined message template arguments.
     * Can return <i>null</i> if no arguments defined.
     * @since JWare/AntXtras 2.0.0
     **/
    protected final String[] getDynamicMessageArgs()
    {
        return m_args;
    }



    /**
     * Extension of inherited '<i>getMsg</i>' that will return this
     * task's default message string if its messageid is undefined.
     **/
    public String getMsg()
    {
        String msg = null;

        if (m_args!=null) {
            msg = getMsg(newMsgGetter(m_args));
        } else {
            msg = super.getMsg();
        }

        return msg;
    }


    String[] m_args;//NB: lazy-inited to 10 long on first use
}

/* end-of-MessageArgsTaskSkeleton.java */
