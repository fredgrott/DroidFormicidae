/**
 * $Id: UEContainerProxy.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;
import  java.util.StringTokenizer;

import  org.apache.tools.ant.RuntimeConfigurable;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.TaskContainer;
import  org.apache.tools.ant.UnknownElement;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Helper when constructing UnknownElements(UEs) that contain other UEs.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @see      TaskExaminer#newUEProxy TaskExaminer.newUEProxy(&#8230;)
 **/

public final class UEContainerProxy implements TaskContainer
{
    /**
     * The element that must be "filled-in" with other UE items.
     **/
    private final UnknownElement m_rootItem;



    /**
     * Initialize a new container proxy for an unknown element.
     * @param impl the unknown element (acts like container)
     **/
    public UEContainerProxy(UnknownElement impl)
    {
        AntX.require_(impl!=null,AntX.nopackage,"ctor- nonzro UE");
        m_rootItem= impl;
    }




    /**
     * Ensures the incoming UE and its wrapper are added to our
     * underlying UE properly.
     * @param task the unknown element task proxy (non-null)
     **/
    public void addTask(Task task)
    {
        AntX.require_(task instanceof UnknownElement,
                      AntX.nopackage, "addWrappedTask- UE");
        UnknownElement ue = (UnknownElement)task;
        m_rootItem.addChild(ue);
        m_rootItem.getWrapper().addChild(ue.getWrapper());
    }



    /**
     * Sets an attribute on the underlying UE element. Useful if
     * a macro maker or custom macro definition needs to tweak
     * the item's attributes as it is itself defined.
     * @param name attribute's name (non-null)
     * @param value attribute's value (non-null)
     **/
    public void setAttribute(String name, String value)
    {
        RuntimeConfigurable wrapper = m_rootItem.getWrapper();
        wrapper.setAttribute(name,value);
    }



    /**
     * Sets a collection of attributes on the underlying UE
     * element. Shorthand for calling {@linkplain #setAttribute
     * setAttribute()} repeatedly. The passed map must contain
     * string-based name/value pairs.
     * @param attrs map of attribute name/value pairs (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setAttributes(Map attrs)
    {
        RuntimeConfigurable wrapper = m_rootItem.getWrapper();
        Iterator itr = attrs.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry e = (Map.Entry)itr.next();
            wrapper.setAttribute((String)e.getKey(),(String)e.getValue());
        }
    }



    /**
     * Like {@linkplain #addTask addTask()} except the new element
     * is added to a nested child element. Incoming is therefore a
     * grandchild to root element.
     * @param task the unknown element grandchild proxy (non-null)
     * @param parentname local type name of parent (non-null)
     * @since JWare/AntX 0.5
     **/
    public void addGrandchildTask(Task task, String parentname)
    {
        AntX.require_(task instanceof UnknownElement,
                      AntX.nopackage, "addWrappedTask- UE");
        UnknownElement target = getBestTarget(parentname);
        UnknownElement ue = (UnknownElement)task;
        target.addChild(ue);
        target.getWrapper().addChild(ue.getWrapper());
    }



    /**
     * Like {@linkplain #setAttribute setAttribute()} except the new
     * attribute is set on a nested child element.
     * @param name attribute's name (non-null)
     * @param value attribute's value (non-null)
     * @param parentname local type name of parent (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setGrandchildAttribute(String name, String value,
        String parentname)
    {
        UnknownElement target = getBestTarget(parentname);
        RuntimeConfigurable wrapper = target.getWrapper();
        wrapper.setAttribute(name,value);
    }



    /**
     * Like {@linkplain #setAttributes setAttributes()} except the new
     * attributes are set on a nested child element.
     * @param attrs map of attribute name/value pairs (non-null)
     * @param parentname local type name of parent (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setGrandchildAttributes(Map attrs, String parentname)
    {
        RuntimeConfigurable wrapper = getBestTarget(parentname).getWrapper();
        Iterator itr = attrs.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry e = (Map.Entry)itr.next();
            wrapper.setAttribute((String)e.getKey(),(String)e.getValue());
        }
    }



    /**
     * Returns the main underlying unknown element. Never
     * returns <i>null</i>.
     * @since JWare/AntX 0.5
     * @see TaskExaminer#copyUEProxy TaskExaminer.copyUEProxy(&#8230;)
     **/
    public UnknownElement getUE()
    {
        return m_rootItem;
    }


    private UnknownElement getBestTarget(String itempath)
    {
        UnknownElement match = m_rootItem;
        if (!Tk.isWhitespace(itempath)) {
            StringTokenizer st= new StringTokenizer(itempath,",");
            while (st.hasMoreTokens()) {
                String nextname = st.nextToken();
                UnknownElement next = childFor(nextname,match);
                if (next==null) {
                    return m_rootItem;
                }
                match = next;
            }
        }
        return match;
    }



    private UnknownElement childFor(String childname, UnknownElement parent)
    {
        UnknownElement child = null;
        if (!Tk.isWhitespace(childname)) {
            List l = parent.getChildren();
            if (l!=null && !l.isEmpty()) {
                for (int i=0,N=l.size();i<N;i++) {
                    UnknownElement next = (UnknownElement)l.get(i);
                    if (childname.equals(next.getTaskName())) {
                        child = next;
                        break;
                    }
                }
            }
        }
        return child;
    }
}

/* end-of-UEContainerProxy.java */
