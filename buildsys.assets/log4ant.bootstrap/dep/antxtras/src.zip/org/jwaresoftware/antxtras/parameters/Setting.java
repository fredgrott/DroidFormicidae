/**
 * $Id: Setting.java 1146 2010-05-23 13:35:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Enumeration of settings for a configurable option. The following  
 * list explains what the various settings mean:<ul>
 *    <li><span class="src">undefined</span>: The option has not been 
 *       explicitly set. The default value that will be used is task
 *       defined.</li>
 *    <li><span class="src">on</span>: The option has been enabled or 
 *       set explicitly.</li>
 *    <li><span class="src">off</span>: The option has been disabled 
 *       or unset explicitly.</li>
 *    <li><span class="src">default</span>: The default setting 
 *        should be used. Exactly  what that value is (on|off) is 
 *        task defined.</li>
 *    <li><span class="src">inherited</span>: The setting value should 
 *        be determined by the surrounding or "parent" context. What 
 *        context is used is actually task dependent.</li>
 * </ul>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public final class Setting extends EnumSkeleton
{
    /** Index of {@linkplain #OFF OFF}. **/
    public static final int OFF_INDEX= 0;
    /** Index of {@linkplain #ON ON}. **/
    public static final int ON_INDEX= 1;
    /** Index of {@linkplain #DEFAULT DEFAULT}. **/
    public static final int DEFAULT_INDEX= 2;
    /** Index of {@linkplain #INHERITED INHERITED}. **/
    public static final int INHERITED_INDEX= 3;
    /** Index of {@linkplain #UNDEFINED UNDEFINED}. **/
    public static final int UNDEFINED_INDEX= 4;

    /** Singleton "off" setting. **/
    public static final Setting OFF = new Setting("off",OFF_INDEX);
    /** Singleton "on" setting. **/
    public static final Setting ON = new Setting("on",ON_INDEX);
    /** Singleton "default" setting. **/
    public static final Setting DEFAULT = new Setting("default",DEFAULT_INDEX);
    /** Singleton "inherited" setting. **/
    public static final Setting INHERITED = new Setting("inherited",INHERITED_INDEX);
    /** Singleton "undefined" setting. **/
    public static final Setting UNDEFINED = new Setting("undefined",UNDEFINED_INDEX);



    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public Setting()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensure it's initialized
     * as with default Ant Introspector helper thingy.
     **/
    private Setting(String v, int i)
    {
        super();
        Tk.initEnum(this,v);
    }


    /**
     * Returns copy of all possible settings as an ordered string
     * array. Implementation: must be in order specified in public
     * INDEX_xxx constants.
     **/
    public String[] getValues()
    {
        return new String[] {"off","on","default","inherited","undefined"};
    };



    /**
     * Helper that converts a scalar to a known setting. Some synonyms
     * for on (true,yes) and off (false,no) as accepted. Returns <i>null</i>
     * if string unrecognized. String can be either setting's symbolic
     * name or its index.
     * @param s the string to be interpreted
     **/
    public static Setting from(String s)
    {
        if (s!=null && s.length()>0) {
            s = s.toLowerCase();
            if ("yes".equals(s))         { return ON; }
            if ("true".equals(s))        { return ON; }
            if (ON.value.equals(s))      { return ON; }

            if ("no".equals(s))          { return OFF; }
            if ("false".equals(s))       { return OFF; }
            if (OFF.value.equals(s))     { return OFF; }

            if (Strings.INHERIT.equals(s)) { return INHERITED; }
            if (INHERITED.value.equals(s)) { return INHERITED; }

            if (DEFAULT.value.equals(s))   { return DEFAULT; }
            if (UNDEFINED.value.equals(s)) { return UNDEFINED; }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(java.lang.String) from(String)} but
     * with a default value if value does not match any known
     * setting's name.
     * @param s the symbolic name to be matched
     * @param dflt the default Setting if necessary
     **/
    public static Setting from(String s, Setting dflt)
    {
        Setting st= from(s);
        return (st==null) ? dflt : st;
    }


    /**
     *  Returns <i>true</i> if this setting equals incoming
     * object (also a setting).
     **/
    public boolean equals(Object o)
    {
        if (o==this) { return true; }
        if (o==null) { return false; }
        if (o.getClass()==getClass()) {
            return ((Setting)o).getIndex()==this.getIndex();
        }
        return false;
    }



    /**
     * Returns this setting's hash value; fixed when
     * constructed.
     **/
    public int hashCode()
    {
        return this.value.hashCode();
    }
}

/* end-of-Setting.java */
