/**
 * $Id: Tk.java 388 2008-03-30 15:44:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Project;

/**
 * Utilities used by implementation classes in this package. We are at the top of
 * the interface food chain so we cannot depend on the standard AntX helpers package
 * or any other.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

final class Tk
{
    /**
     * Returns the leaf of a class's name. If the leaf partion of the
     * class name includes the '$' character (as for inner or anonymous
     * classes), all occurances of  '$' are replaced by a '-'
     * character.
     * @param cls the class (non-null)
     **/
    static String leafNameFrom(Class cls)
    {
        if (cls==null) {
            throw new IllegalArgumentException("leafFrom- NULL class");
        }
        String cn = cls.getName();
        int i= cn.lastIndexOf('.');
        if (i != -1) {
            return cn.substring(i+1).replace('$','-');
        }
        return cn;
    }



    /**
     * Returns a generic system identity string for given object.
     * @param thing the thing to be stringified (can be <i>null</i>)
     * @since JWare/AntX 0.4
     **/
    static String identityStringFrom(Object thing)
    {
        if (thing==null) {
            return "null";
        }
        return thing.getClass().getName()
            +"@"
            +System.identityHashCode(thing);
    }



    /**
     * Tries to obtain the result of an object's
     * <span class="src">toString()</span> handling. If the object's
     * handling generates an exception (often the case in Ant 1.6+)
     * this method returns a generic system identity string.
     * @param thing the thing to be stringified (can be <i>null</i>)
     * @param P [optional] project for problem logging purposes
     * @since JWare/AntX 0.4
     **/
    static String stringFrom(Object thing, Project P)
    {
        try {
            return String.valueOf(thing);
        } catch(RuntimeException rtX) {
            if (P!=null) {
                P.log(rtX.getMessage(),Project.MSG_INFO);
            }
            return identityStringFrom(thing);
        }
    }

    private Tk()
    {
    }
}

/* end-of-Tk.java */