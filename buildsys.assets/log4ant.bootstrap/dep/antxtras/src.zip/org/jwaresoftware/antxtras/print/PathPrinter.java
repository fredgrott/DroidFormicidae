/**
 * $Id: PathPrinter.java 1419 2012-07-31 16:13:43Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.PrintStream;
import  java.util.List;
import  java.util.Properties;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Helper to print a PATH object without encoding. Useful for a diagnostic
 * view of a set of path objects.
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2008,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class PathPrinter extends XPropertiesPrinter
{
    /** Generates a more readable version of an encoded PATH value */
    public static final LineOutput PathLines = new LineOutput() {
        public void println(String name, Object value, PrintStream out) {
            String delim = System.getProperty("path.separator",";");
            List paths = Tk.splitList(String.valueOf(value),delim);
            out.print(name);
            out.println("=");
            for (int i=0,N=paths.size();i<N;i++) {
                out.println(paths.get(i));
            }
            out.println();
        }
    };

    /**
     * Generate a succinct text output of the given set of PATH
     * values (each property value is expected to be a delimited 
     * path string).
     * @param p [optional] the properties object
     * @param out output stream (non-null)
     **/
    public final static void print(Properties p, PrintStream out)
    {
        print(p,out,PathLines);
    }


    private PathPrinter() { }
}

/* end-of-PathPrinter.java */
