/**
 * $Id: ShowTask.java 1510 2012-09-24 23:26:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  java.io.ByteArrayOutputStream;
import  java.io.File;
import  java.io.FileOutputStream;
import  java.io.IOException;
import  java.io.OutputStream;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.NoiseLevel;
import  org.jwaresoftware.antxtras.go.Go;
import  org.jwaresoftware.antxtras.go.Iff;
import  org.jwaresoftware.antxtras.go.IffValue;
import  org.jwaresoftware.antxtras.go.Unless;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.NullStream;
import  org.jwaresoftware.antxtras.parameters.Conditional;
import  org.jwaresoftware.antxtras.parameters.FeedbackSink;
import  org.jwaresoftware.antxtras.parameters.InformationSaver;

/**
 * Simple task that displays <i>messageid</i>-based messages. By default 
 * behaves like the standard Ant '<i>echo</i>' task but is also able
 * to use external resource bundles. If undefined, the message noise-level
 * is whatever the AntXtras's runtime default is defined to be (info).
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>show</b> messageid="msg.helloworld"/&gt;
 *   &lt;<b>show</b> messageid="msg.starting" tofile="${log.file}"/&gt;
 *   &lt;<b>show</b> messageid="msg.byeworld" level="verbose"/&gt;
 *   &lt;<b>show</b> messageid="msg.youarehere" arg2="Compiling" level="debug"/&gt;
 *   &lt;<b>show</b> messageid="err.no.jdk15" unless="jdk15.present"&gt;
 *      &lt;defaultmessage&gt;Need J2SE 1.5 or later&lt;/defaultmessage&gt;
 *   &lt;/show&gt;
 *   &lt;<b>show</b> true="${$v:trace.flag}" message="STARTING ${$now:}"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 **/

public class ShowTask extends MessageArgsTaskSkeleton implements 
    Conditional, InformationSaver
{
    /**
     * Initializes a new task instance.
     **/
    public ShowTask()
    {
        super(AntX.starters+"ShowTask:");
    }


    /**
     * Initializes a new task subclass instance.
     * @param iam CV-label (non-null)
     **/
    public ShowTask(String iam)
    {
        super(iam);
    }


    /**
     * Initializes a new task subclass instance with a predefined
     * default message.
     * @param iam CV-label (non-null)
     * @param defaultMsg default message (non-null)
     **/
    public ShowTask(String iam, String defaultMsg)
    {
        super(iam);
        require_(defaultMsg!=null,"ctor- nonzro dfltMsg");
        m_defaultMessage = defaultMsg;
    }

// ---------------------------------------------------------------------------------------
// Public script-facing parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets the target file for this echo task's generated output.
     * The file reference is used as-is.
     * @param outputFile the output file (non-null)
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public final void setToProjectFile(File outputFile)
    {
        require_(outputFile!=null,"setToProjFile- nonzro file");
        m_toFile = outputFile;
        m_toSink = FeedbackSink.EXTERNAL;
    }


    /**
     * Sets the target file path for this echo task's generated
     * output. If the path is relative, the output file will be
     * determined relative to this task's project's base directory.
     * @param outputFile the output file's path (non-null)
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public void setToFile(String outputFile)
    {
        require_(outputFile!=null,"setToFil- nonzro filepath");
        setToProjectFile(getProject().resolveFile(outputFile));
    }


    /**
     * Returns this task's target file for output. Returns
     * <i>null</i> if never set.
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public File getToFile()
    {
        return m_toFile;
    }


    /**
     * Returns this task's target file for output. Returns
     * <i>null</i> if never set.
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public final String getToFilePath()
    {
        File f = getToFile();
        return f!=null ? f.getPath() : null;
    }


    /**
     * Marks whether this task should try to append its new information
     * to its output stream.
     * @param append <i>true</i> if should try to append
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public void setAppend(boolean append)
    {
        m_tryAppend= append;
    }


    /**
     * Returns <i>true</i> if this task will try to append any new
     * information to an existing output sink. By default is <i>false</i>.
     * @since AntXtras 3.0.0 (pulled up from EchoThingTask)
     **/
    public final boolean willTryAppend()
    {
        return m_tryAppend;
    }


    /**
     * Adds an if-condition to this echo task.
     * @since JWare/AntX 0.2
     **/
    public void setIf(String property)
    {
        m_ifProperty = (property==null) ? "" : property;
    }


    /**
     * Returns this task's (raw) if-condition if any. Returns
     * empty string if condition never set.
     * @since JWare/AntX 0.2
     **/
    public String getIfProperty()
    {
        return m_ifProperty;
    }



    /**
     * Adds an unless-condition to this show task.
     * @since JWare/AntX 0.2
     **/
    public void setUnless(String property)
    {
        m_unlessProperty = (property==null) ? "" : property;
    }


    /**
     * Returns this task's (raw) unless-condition if any. Returns
     * empty string if condition never set.
     * @since JWare/AntX 0.2
     **/
    public String getUnlessProperty()
    {
        return m_unlessProperty;
    }



    /**
     * Adds a generic "is true" check to this show task.
     * @param booleanString the string to evaluate (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public void setTrue(String booleanString)
    {
        require_(booleanString!=null,"setTru- nonzro test");
        m_1Test = new IffValue.IsTrue(booleanString);
    }



    /**
     * Adds a generic "is false" check to this show task.
     * @param booleanString the string to evaluate (non-null)
     * @since JWare/AntXtras 3.0.0
     **/
    public void setFalse(String booleanString)
    {
        require_(booleanString!=null,"setFals- nonzro test");
        m_0Test = new IffValue.IsNotTrue(booleanString);
    }



    /**
     * Sets this task's preferred message noise level.
     * @param level new level (non-null)
     * @see #getPreferredNoiseLevel getPreferredNoiseLevel()
     **/
    public void setLevel(NoiseLevel level)
    {
        require_(level!=null,"setLvl- nonzro lvl");
        m_preferredNoiseLevel = level;
    }


    /**
     * Returns this task's preferred message noise level. Returns
     * <i>null</i> if never set. For the message level used when
     * showing message, see {@linkplain #getNoiseLevel getNoiseLevel()}.
     **/
    public final NoiseLevel getPreferredNoiseLevel()
    {
        return m_preferredNoiseLevel;
    }


    /**
     * Returns this task's <em>effective</em> message noise level. If
     * this task's preferred msg level never set, this method returns
     * the default message level set at either the project, system, or
     * AntX-defaults levels. Never returns <i>null</i>.
     * @see org.jwaresoftware.antxtras.core.AssertableTask#getDefaultNoiseLevel()
     **/
    public final NoiseLevel getNoiseLevel()
    {
        NoiseLevel nl= getPreferredNoiseLevel();
        if (nl==null) {
            nl= getDefaultNoiseLevel();
        }
        return nl;
    }



    /**
     * <em>Replaces</em> the default message string associated with
     * this task. Usually only specified if it is acceptable for 
     * resource bundles to be missing at build-time.
     * @see #getDefaultMessage
     **/
    public void addConfiguredDefaultMessage(InnerString defaultMsgStr)
    {
        require_(defaultMsgStr!=null,"addDfltMsg- nonzro str");
        m_defaultMessage= defaultMsgStr.toString(getProject());
    }


    /**
     * Returns this task's default message string if any. Never
     * returns <i>null</i> but will return the empty string if this
     * element never defined.
     **/
    public final String getDefaultMessage()
    {
        return m_defaultMessage;
    }



    /**
     * Sets the inlined string message emitted by this task. 
     * Same as nesting a default message.
     * @param string the message (non-null)
     **/
    public void setMessage(String string)
    {
        require_(string!=null,"setMsg- nonzro string");
        addConfiguredDefaultMessage(new InnerString(string));
    }



    /**
     * Sets the target output system stream for this show message.
     * @param fbLevel requested system output stream 
     * @since JWare/AntXtras 3.5.0
     **/
    public void setTo(String fbLevel)
    {
        FeedbackSink to = FeedbackSink.from(fbLevel);
        if (to!=null) {
            m_toSink = to;
            if (getPreferredNoiseLevel()==null) {
                if (FeedbackSink.STDERR==to)
                    setLevel(NoiseLevel.WARNING);
                else if (FeedbackSink.STDOUT==to) {
                    setLevel(NoiseLevel.INFO);
                }
            }
        }
    }


// ---------------------------------------------------------------------------------------
// Implementation:
// ---------------------------------------------------------------------------------------

    /**
     * Extension of inherited '<i>getMsg</i>' that will return this
     * task's default message string if its messageid is undefined.
     **/
    public String getMsg()
    {
        String msg = super.getMsg();
        String dfltMsg = getDefaultMessage();
        if (Tk.isWhitespace(msg)) {
            msg = dfltMsg;
        } else if (msg.equals(getMessageId()) && !Tk.isWhitespace(dfltMsg)) {
            msg = dfltMsg;
        }

        return msg;
    }



    /**
     * Tests whether or not this task's "if" condition resolves
     * to a an existing property.
     * @return <i>true</i>if the "if" property is defined
     * @since JWare/AntX 0.2
     **/
    protected final boolean testIfCondition()
    {
        boolean y = m_1Test!=null ? m_1Test.pass(getProject()) : true;
        return y && Iff.allowed(getIfProperty(), getProject());
    }



    /**
     * Tests whether or not this task's "unless" condition resolves
     * to an existing property.
     * @return <i>true</i> if the "unless" property is not defined
     * @since JWare/AntX 0.2
     **/
    protected final boolean testUnlessCondition()
    {
        boolean y = m_0Test!=null ? m_0Test.pass(getProject()) : true;
        return y && Unless.allowed(getUnlessProperty(),getProject());
    }



    /**
     * Returns an output stream suitable for this task. The returned
     * stream is the raw output stream, <em>not</em> a buffered stream
     * if possible. If this show task is assigned to sink to either of
     * the System streams, then the stream is already a custom stream.
     **/
    protected OutputStream getOutputStream()
    {
        switch(m_toSink.getIndex()) {
            case FeedbackSink.STDOUT_INDEX: {
                return System.out;
            }
            case FeedbackSink.STDERR_INDEX: {
                return System.err;
            }
            case FeedbackSink.NONE_INDEX:   {
                return new NullStream();
            }
            default: {
                File f = getToFile();
                if (f!=null) {
                    try {
                        return new FileOutputStream(f.getPath(), willTryAppend());
                    } catch(IOException ioX) {
                        String ermsg = uistrs().get("task.echo.unable.use.file",f.getPath(),
                                                    ioX.getMessage());
                        log(ermsg,Project.MSG_WARN);
                    }
                }
            }
        }
        return new ByteArrayOutputStream(1024);//ALWAYS USE AS FALLBACK
    }



    /**
     * Returns <i>true</i> if this task should try to echo the given
     * output stream to the Ant runtime's logging system. Use this
     * method ONLY IF you are a subclass that can "naturally" do 
     * something other than writing to the Ant log. Call this method
     * to determine if you should ALSO try logging your information
     * to the Ant console.
     **/
    protected boolean tryAntLog(OutputStream os)
    {
        return (os instanceof ByteArrayOutputStream);
    }



    /**
     * Returns the information from the given stream to log to the
     * Ant logging system. By default if the stream is a byte buffer,
     * returns the entire contents; otherwise returns the empty string.
     **/
    protected String getAntLogString(OutputStream os)
    {
        if (os instanceof ByteArrayOutputStream) {
            return ((ByteArrayOutputStream)os).toString();
        }
        return "";
    }



    /**
     * Work like the default '<i>echo</i>' Ant task except 
     * using UIStringManager underneath if requested.
     * @see #executeAllowed() guard condition
     **/
    public void execute()
    {
        verifyCanExecute_("execute");

        if (executeAllowed()) {
            echoThing();
        }
    }



    /**
     * Returns <i>true</i> if this task's make function can go
     * ahead. By default just checks the 'if' and 'unless' 
     * conditions, subclasses can additional checks. Call after
     * verified execution parameters.
     * @since JWare/AntXtras 2.0.0
     **/
    protected boolean executeAllowed()
    {
        return testIfCondition() && testUnlessCondition();
    }



    /**
     * Does the actual "showing" work for this task. If the "to" destination
     * has not been changed, the default is to just log this task's message
     * to the Ant console.
     * @since JWare/AntXtras 3.0.0
     * @since JWare/AntXtras 3.5.0 reworked to work with feedback sink indicator
     **/
    protected void echoThing()
    {
        String message = getMsg();

        switch(m_toSink.getIndex()) {
            case FeedbackSink.NONE_INDEX: {
                break;
            }
            case FeedbackSink.ALL_INDEX: 
            case FeedbackSink.ANTLOG_INDEX: {
                log(message, getNoiseLevel().getNativeIndex());
                break;
            }
            case FeedbackSink.STDOUT_INDEX: {
                System.out.print(message);
                break;
            }
            case FeedbackSink.STDERR_INDEX: {
                System.err.print(message);
                break;
            }
            default: {
                OutputStream os = getOutputStream();
                try {
                    os.write(message.getBytes());
                } catch(Exception ioX) {
                    String because = Tk.messageFrom(ioX);
                    log(Errs.UnableToWriteToOutputSream(because),Project.MSG_ERR);
                } finally {
                    closeOutputStream(os);
                    os=null;
                }
            }
        }
    }


    /**
     * Checks if the assigned sink for the echo'ed thing is 
     * one of the system output streams (err or out).
     * @return <i>true</i> if outputting to either of the system streams.
     * @since JWare/AntXtras 3.5.0
     **/
    protected final boolean isSystemOutput()
    {
        return FeedbackSink.STDERR.equals(m_toSink) || FeedbackSink.STDOUT.equals(m_toSink);
    }


    /**
     * Do whatever is necessary to close the stream returned by
     * {@linkplain #getOutputStream() getOutputStream()}.
     * @param os the stream returned by getOutputStream
     * @since JWare/AntXtras 3.5.0
     **/
    protected final void closeOutputStream(OutputStream os)
    {
        if (!isSystemOutput()) {
            Tk.closeQuietly(os);
        }
    }


    private NoiseLevel m_preferredNoiseLevel;
    private String m_defaultMessage="";
    private String m_ifProperty="";
    private String m_unlessProperty="";
    private Go.Test m_1Test;//Optional: true ="<test>"
    private Go.Test m_0Test;//Optional: false="<test>"
    private FeedbackSink m_toSink = FeedbackSink.ANTLOG;
    private File m_toFile;
    private boolean m_tryAppend;//NB:false=>overwrite existin'
}


/* end-of-ShowTask.java */
