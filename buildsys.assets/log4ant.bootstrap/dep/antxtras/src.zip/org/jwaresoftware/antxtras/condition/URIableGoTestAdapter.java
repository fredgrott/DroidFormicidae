/**
 * $Id: URIableGoTestAdapter.java 1482 2012-08-19 17:52:17Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.go.Go;

/**
 * Adapter that converts a URIable condition into a Go&#46;Test for use
 * in a composite evaluator.
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    impl,helper
 * @see       ConditionFunctionShortcuts
 **/

public final class URIableGoTestAdapter extends Go.TestSkeleton
{
    /**
     * Initializes a new test adapter for the given URIable and parameters.
     * @param attribute the URIable's script facing attribute name (non-null)
     * @param value the URIable's value as a shortcut string (non-blank)
     * @param evaluator the URIable to evaluator when called (non-null)
     **/
    public URIableGoTestAdapter(String attribute, String value, URIable evaluator)
    {
        super(value);
        m_evaluator = evaluator;
        m_attrName  = attribute;
    }

    public String getParameterName()
    {
        return m_attrName;
    }

    public boolean pass(Project wrtProject)
    {
        if (wrtProject!=null) {
            wrtProject.setProjectReference(m_evaluator);
        }
        m_evaluator.xsetFromURI(getParameter());
        return m_evaluator.eval();
    }

    private final URIable m_evaluator;
    private final String  m_attrName;
}

/* end-of-URIableGoTestAdapter.java */
