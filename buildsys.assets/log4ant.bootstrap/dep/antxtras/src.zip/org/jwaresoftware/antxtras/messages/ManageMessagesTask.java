/**
 * $Id: ManageMessagesTask.java 1372 2012-07-26 15:03:02Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.io.File;
import  java.net.URL;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.AntlibDefinition;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.internal.apis.UIStringManager;
import  org.jwaresoftware.internal.uism.BundleStringManager;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.behaviors.Responses;
import  org.jwaresoftware.antxtras.construct.DefinitionLoader;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.FixtureInitializer;
import  org.jwaresoftware.antxtras.core.UISMContext;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.CustomLoaderEnabled;

/**
 * Helper task that initializes a thread's iteration UIStringManagers.
 * Usually used by the execution cycle's initialization or with test 
 * scripts. If you do not specify an action, this task will try to 
 * install a <em>fallback</em> string manager.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;managemessages url="${my.url}/strings.properties"/&gt;
 *  &lt;managemessages resource="my-messages" 
 *       classpathref="my.classpath"/&gt;
 *  &lt;managemessages action="install-fallback" 
 *       bundleid="my.messages"/&gt;
 *  &lt;managemessages action="install-root" 
 *       file="/builds/module-messages.properties"/&gt;
 *  &lt;managemessages action="uninstall-root"/&gt;
 *  &lt;managemessages resource="my/messages.properties" 
 *       loaderref="my.loaderref"/&gt;
 * </pre>
 * <p/>
 * Implementation Note: This class is intentionally subclassed from 
 * the standard  <i>Antlib</i> and not AntXtras's <i>AssertableTask</i>  
 * to ensure UISM-based functionality doesn't apply to instances of  
 * this class (publicly). You can also use this task in your own  
 * antlib files to install a <em>default</em> message bundle like:
 * <pre>
 *   &lt;antlib&gt;
 *     &lt;managemessages resource="META-INF.my-messages"/&gt;
 *     &#46;&#46;&#46;
 *   &lt;/antlib&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 **/

public final class ManageMessagesTask extends AntlibDefinition/*intentional*/
    implements MessagesSource, CustomLoaderEnabled, AntLibFriendly, FixtureInitializer
{
    /**
     * {@linkplain #setAction Action} name to install the
     * <em>default</em> aka fallback bundle ({@value}).
     * @since JWare/AntX 0.4
     **/
    public static final String OP_INSTALL_FALLBACK =
        "install-fallback";

    /**
     * {@linkplain #setAction Action} name to uninstall the
     * <em>default</em> aka fallback bundle ({@value}).
     * @since JWare/AntX 0.4
     **/
    public static final String OP_UNINSTALL_FALLBACK = 
        "uninstall-fallback";

    /**
     * {@linkplain #setAction Action} name to install the
     * <em>root</em> bundle ({@value}). Limited to current thread.
     * @since JWare/AntX 0.4
     **/
    public static final String OP_INSTALL_CONTEXT_ROOT = 
        "install-root";

    /**
     * {@linkplain #setAction Action} name to uninstall the
     * <em>root</em> bundle ({@value}). Limited to current thread.
     * @since JWare/AntX 0.4
     **/
    public static final String OP_UNINSTALL_CONTEXT_ROOT = 
        "uninstall-root";



    /**
     * Initializes a new manage messages task.
     **/
    public ManageMessagesTask()
    {
        super();
    }



    /**
     * Initializes this task's default problem notify callback 
     * and ties its bundle impl to any antlib bits.
     * @since JWare/AntX 0.4
     **/
    public void init()
    {
        super.init();
        m_rqlink = new Requester.ForComponent(this);
        m_bundle.setController(new DefinitionLoader(this));
    }



    /**
     * Sets this task's project; updates other underlying
     * project-components.
     **/
    public void setProject(Project P)
    {
        super.setProject(P);
        m_bundle.setProject(P);
    }



    /**
     * Sets whether this task will fail if it cannot locate 
     * and load its strings from the specified location.
     * @param mustExist <i>true</i> if source must exist
     * @since JWare/AntX 0.4
     **/
    public void setMustExist(boolean mustExist)
    {
        m_bundle.setMustExist(mustExist);
    }



    /**
     * Sets this task's bundle source information as a 
     * reference to an existing MessagesBundle.
     **/
    public void setBundleId(Reference reference)
    {
        m_bundle.setRefid(reference);
    }



    /**
     * Sets this task's resource bundle's location as a URL. 
     * @param urlstr URL string representation (non-null)
     **/
    public void setURL(String urlstr)
    {
        m_bundle.setURL(urlstr);
    }



    /**
     * Returns this task's message source's URL location. 
     * Returns <i>null</i> if never set or was set to an
     * invalid URL string.
     **/

    public URL getURL()
    {
        return m_bundle.getURL();
    }



    /**
     * Sets this task's source location as a file. Path 
     * is resolved relative to this task's project.
     * @param filepath the path to the source properties.
     **/
    public void setFile(String filepath)
    {
        m_bundle.setFile(filepath);
    }



    /**
     * Returns this task's source bundle's file location. 
     * Returns <i>null</i> if never set.
     **/
    public File getFile()
    {
        return m_bundle.getFile();
    }



    /**
     * Sets this task's source location as a resource 
     * base name.
     * @param resource resource base name (non-null)
     **/
    public void setResource(String resource)
    {
        m_bundle.setResource(resource);
    }


 
    /**
     * Returns this task's source bundle's resource base
     * name. Returns <i>null</i> if never set.
     **/
    public String getResource()
    {
        return m_bundle.getResource();
    }



    /**
     * Returns new (added) empty (nested) Path for use 
     * when searching for resources.
     */
    public Path createClassPath()
    {
        return m_bundle.createClassPath();
    }



    /**
     * Adds new classpath element for use when searching
     * for resources.
     * @param classpath the search path (non-null)
     */
    public void setClassPath(Path classpath)
    {
        m_bundle.setClassPath(classpath);
    }



    /**
     * Set the classpath by-reference for use when searching
     * for resources.
     * @param reference a Reference to a Path instance (non-null)
     */
    public void setClassPathRef(Reference reference)
    {
        m_bundle.setClassPathRef(reference);
    }



    /**
     * Returns this task's custom classpath used when loading 
     * a resource based source. Returns <i>null</i> if never set.
     * @see #setClassPath
     * @see #setClassPathRef
     **/
    public Path getClassPath()
    {
        return m_bundle.getClassPath();
    }



    /**
     * Tells this task to use an existing classloader to 
     * search for source messages resource.
     * @param r reference to an existing ClassLoader (non-null)
     **/
    public void setLoaderRef(Reference r)
    {
        m_bundle.setLoaderRef(r);
    }



    /**
     * Returns this task's custom class loader identifier. 
     * Will return <i>null</i> if never set.
     * @see #setLoaderRef
     **/
    public String getLoaderRefId()
    {
        return m_bundle.getLoaderRefId();
    }



    /**
     * Explicitly tells us the format of the source. 
     * Valid hint values are "properties" or "xml".
     * @param hint format of source (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setFormat(String hint)
    {
        m_bundle.setFormat(hint);
    }



    /**
     * Instructs this task how to manage the iteration's 
     * UISM context. Action should be one of ['install-fallback',
     * 'install-root', 'uninstall-fallback', 'uninstall-root'].
     * @param op the operation (non-null)
     **/
    public void setAction(String op)
    {
        m_Op = Tk.lowercaseFrom(op);
    }



    /**
     * Factory method for our UIStringManager.
     **/
    private BundleStringManager getUISM()
    {
        return new BundleStringManager
            (m_bundle.newBundle(m_rqlink),null);
    }



    /**
     * Installs a root UISMContext UIStringManager based on the
     * bundle assigned to this manager. Installed UISM will act
     * as the catch-all for other UISMs (e.g. overlayed), UISM-aware
     * tasks, and UISM-listeners within this thread. This type
     * of UISM should be installed at most once from an 'init' 
     * type target. As of AntXtras-0&#46;6, the root UISM will
     * <em>automatically</em> delegate misses to the installed
     * default or fallback UISM.
     **/
    private void installContextFallbackSM() throws BuildException
    {
        BundleStringManager uism = getUISM();
        uism.setNextUISM(DefaultStringManager.INSTANCE);//NB:envelope!=fixed
        UIStringManager alreadyInstalled = UISMContext.installStringManager(uism,null);
        if (alreadyInstalled!=null) {//Whups!
            UISMContext.unwindStringManager(m_rqlink);
            String ermsg = AntX.uistrs().get("task.uism.err.too.many.root.bundles");
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
        log("Installed context fallback UIStringManager from "
              +m_bundle.getFromLabel(), Project.MSG_DEBUG);
    }


    /**
     * Installs a <em>default fallback</em> UIStringManager 
     * based on the bundle assigned to this manager. A fallback
     * UISM acts as the catch-all for <em>ALL</em> 
     * UISMContexts, UISM-aware tasks, etc.
     * @since JWare/AntX 0.4
     **/
    private void installFallbackSM()
    {
        boolean alreadyInstalled = !UISMContext.isDefaultUndefined();
        UISMContext.setDefaultStringManager(getUISM());
        if (alreadyInstalled) {
            String ermsg = AntX.uistrs().get("task.uism.repl.context.msgs");
            log(ermsg, Project.MSG_VERBOSE);
        } else {
            log("Installed context fallback UIStringManager from "
                 +m_bundle.getFromLabel(), Project.MSG_DEBUG);
        }
    }



    /**
     * Executes this UISM manager's instruction; by default 
     * installs a default fallback UIStringManager (as of AntXtras 2.0)
     * @throws BuildException if a root UIStringManager already 
     *         installed for current thread or unable to load strings
     **/
    public void execute()
        throws BuildException
    {
        //If as Antlib definition, only install operations are permitted!
        if (getAntlibClassLoader()!=null) {//=>in Antlib always?
            if (m_Op!=null && m_Op.startsWith("uninstall")) {
                String ermsg = AntX.uistrs().get
                    ("task.manager.err.illegal.operation",m_Op);
                log(ermsg,Project.MSG_ERR);
                throw new BuildException(ermsg,getLocation());
            }
        }

        //Install|Uninstall UI string managers
        synchronized(m_bundle) {
            if (m_Op==null || OP_INSTALL_FALLBACK.equals(m_Op)) {
                installFallbackSM();
            }
            else if (OP_INSTALL_CONTEXT_ROOT.equals(m_Op) ||
                     Strings.INSTALL.equals(m_Op)/*backward-compat*/) {
                installContextFallbackSM();
            }
            else if (OP_UNINSTALL_CONTEXT_ROOT.equals(m_Op) ||
                     Strings.UNINSTALL.equals(m_Op)/*backward-compat*/) {
                log("Trying to uninstall the active context fallback UIStringManager",
                    Project.MSG_DEBUG);
                UISMContext.unwindStringManager(m_rqlink);
            }
            else if (OP_UNINSTALL_FALLBACK.equals(m_Op)) {
                if (!UISMContext.isDefaultUndefined()) {
                    log("Trying to uninstall the default fallback UIStringManager",
                        Project.MSG_DEBUG);
                    AntXFixture.reset(UISMContext.FXID,Strings.DEFAULT,m_rqlink);
                }
            }
            else {
                String ermsg = AntX.uistrs().get
                    ("task.manager.err.unknown.operation",m_Op);
                log(ermsg,Project.MSG_WARN);
            }
        }
    }

    private MessagesBundle m_bundle= 
        new MessagesBundle(AntX.messages+"ManageMessagesTask:",true);//NB:delegatee for configuration
    private String m_Op;//NB:==> install-fallback
    private ProblemHandler m_rqlink = Responses.ERROR;
}

/* end-of-ManageMessagesTask.java */
