/**
 * $Id: FreeFormEnabled.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Marker interface for any AntX component that supports arbitrary application-defined
 * subclassed sub-elements by typedef'd name. <em>This functionality depends on Ant
 * 1.6 or later to actually work "out-of-the-box".</em> However, individual
 * implementations can support earlier Ant versions through some AntX-specific mechanism
 * (although this is not encouraged because of the long-term maintanance issues).
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   impl,helper
 * @.expects Ant 1.6 or later
 **/

public interface FreeFormEnabled
{
}

/* end-of-FreeFormEnabled.java */
