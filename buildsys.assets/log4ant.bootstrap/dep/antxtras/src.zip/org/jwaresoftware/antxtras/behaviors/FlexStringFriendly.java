/**
 * $Id: FlexStringFriendly.java 751 2009-03-15 01:41:25Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Project;

/**
 * Mixin interface for an object that can represent itself as a
 * property-value-friendly string. The application can use the string
 * representation as a readable property, variable, or reference value.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @.group   api,helper
 * @see      org.jwaresoftware.antxtras.core.Stringifier Stringifier
 **/

public interface FlexStringFriendly
{
    /**
     * Returns the string-form appropriate for this object.
     * @param project [optional] the context project (can be <i>null</i>)
     **/
    String stringFrom(Project project);
}

/* end-of-FlexStringFriendly.java */
