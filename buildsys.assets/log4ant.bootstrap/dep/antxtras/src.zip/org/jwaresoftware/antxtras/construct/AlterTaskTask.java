/**
 * $Id: AlterTaskTask.java 1303 2011-10-22 11:52:46Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.DynamicAttribute;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.TaskContainer;
import  org.apache.tools.ant.UnknownElement;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.ownhelpers.UEContainerProxy;

/**
 * Task that modifies a previously cached task instance. Note that you can only <em>add</em>
 * attributes and sub-components to an existing item; you cannot remove previously
 * installed bits. The "<span class="src">name</span>" attribute is reserved by
 * the AlterTask instance; all other parameters are treated as input to the task
 * under construction. You can prefix each parameter's name with a "addparam-"
 * string to mark it as a parameter (this allows you set a parameter called "name"
 * also).
 * <p/>
 * If you use the &lt;altertask&gt; task within an AntXtras looping construct, you need
 * to be careful about using the loop cursor as an input value to any added parameter
 * or nested element. If the cursor property is not evaluated <em>before</em> the
 * loop exists, the property cannot be determined (because it lives only as long
 * as the executing loop block does).
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;createtask name="${$var:_junitinstance}"&gt;
 *       &lt;junit printsummary="yes" haltonfailure="yes"&gt;
 *          &#8230;
 *       &lt;/junit&gt;
 *    &lt;/createtask&gt;
 *    &lt;do true="${$notwhitespace:@{classpathref}}"&gt;
 *       &lt;<b>altertask</b> name="${$var:_junitinstance}"&gt;
 *          &lt;classpath refid="@{classpathref}"/&gt;
 *       &lt;/altertask&gt;
 *    &lt;/do&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008,2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 * @see       CreateTaskTask
 * @see       PerformTaskTask
 **/

public final class AlterTaskTask extends AssertableTask
    implements TaskContainer, DynamicAttribute
{
    /**
     * Initializes a new altertask task instance.
     **/
    public AlterTaskTask()
    {
        super(AntX.construct+"AlterTaskTask:");
    }



    /**
     * Tells this editor the reference id of the task under construction.
     * This task should've been installed by the AntX task creator method.
     * @param refId reference id of task under construction (non-null)
     **/
    public void setName(String refId)
    {
        require_(refId!=null,"setName- nonzro refid");
        m_itemUC = (UEContainerProxy)FixtureExaminer.getReferencedObject(getProject(),
            new Requester.ForComponent(this), refId, UEContainerProxy.class);
    }



    /**
     * Tells this editor to immediately resolve properties in
     * proxy objects.
     * @param inLoop <i>true</i> to resolve.
     **/
    public void setResolveProperties(boolean inLoop)
    {
        m_tryResolveProperties = inLoop;
    }



    /**
     * Tells this editor its modifications apply to a nested element
     * one level inside the target component. Only a single level (to
     * grandchild) is supported.
     * @param childElementName local name of nested element
     **/
    public void setChild(String childElementName)
    {
        m_childElementName = childElementName;
    }



    /**
     * Gives this wrapper an override for the named parameter. Only
     * allowed if this task's "fixed" flag was cleared.
     * @param param ARM parameter (non-null)
     * @param value ARM parameter value (non-null)
     * @throws BuildException the named attribute is invalid
     */
    public void setDynamicAttribute(String param, String value)
    {
        require_(param!=null,"setDynAttr- nonzro param");
        if (param.startsWith("addparam-")) {
            param = param.substring("addparam-".length());
            if (param.length()==0) {
                String err = Errs.UnsupportedAttribute(getTaskName(),"<blank>");
                log(err,Project.MSG_ERR);
                throw new BuildException(err,getLocation());
            }
        }
        if (m_tryResolveProperties) {
            value = tryResolve(getProject(),value);
        }
        m_itemAtrs.put(param,value);
    }



    /**
     * Stashes the nested element's UE proxy for subsequent installation
     * inside the main item under construction.
     * @param task the unknown element task proxy (non-null)
     **/
    public void addTask(Task task)
    {
        require_(task instanceof UnknownElement, "addTask- is UE proxy");
        m_nestedElems.add(task);
    }



    /**
     * Installs all named attributes and nested elements into main item
     * under construction.
     */
    public void execute()
    {
        verifyCanExecute_("exec");
        final boolean grandchild = m_childElementName!=null;

        if (!m_nestedElems.isEmpty()) {
            for (int i=0,N=m_nestedElems.size();i<N;i++) {
                UnknownElement ue = (UnknownElement)m_nestedElems.get(i);
                if (m_tryResolveProperties) {
                    ue = TaskExaminer.copyUEProxy
                            (ue,ue.getProject(),ue.getOwningTarget(),true);
                }
                if (grandchild) {
                    m_itemUC.addGrandchildTask(ue,m_childElementName);
                } else {
                    m_itemUC.addTask(ue);
                }
            }
        }

        if (!m_itemAtrs.isEmpty()) {
            if (grandchild) {
                m_itemUC.setGrandchildAttributes(m_itemAtrs,m_childElementName);
            } else {
                m_itemUC.setAttributes(m_itemAtrs);
            }
        }

        m_itemUC = null;
        m_nestedElems = null;
        m_itemAtrs = null;
    }



    /**
     * Ensures we've been given a reference to a task to perform.
     */
    protected void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);

        if (m_itemUC==null) {
            String ermsg = Errs.NeedsThisAttribute(getTaskName(), "name");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }


    /**
     * Tries to immediately determine the value of an attribute resolving
     * any context-dependent properties.
     * @param P project (non-null)
     * @param string string to resolve (non-null)
     * @return resolved string or original if could not resolve now.
     **/
    private static String tryResolve(final Project P, final String string)
    {
        try {
            return Tk.resolveString(P,string);
        } catch(BuildException tooSoonX) {
            return string;
        }
    }



    private UEContainerProxy m_itemUC;//item under construction (non-null after name known)
    private List m_nestedElems = AntXFixture.newList();
    private Map m_itemAtrs = AntXFixture.newMap();
    private boolean m_tryResolveProperties;//NB:off-by-default (only in loops)
    private String m_childElementName;
}

/* end-of-AlterTaskTask.java */