/**
 * $Id: FixtureIds.java 1374 2012-07-27 11:53:49Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * AntXtras's public lifecycle and project configuration 
 * category identifiers.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2009,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,infra
 * @see      FixtureOverlays
 **/

public class FixtureIds
{
    /**
     * Prefix for all global iteration properties.
     * @since JWare/AntX 0.4
     **/
    public static final String PREFIX =
        AntX.ANTX_INTERNAL_ID+"fixture.";


    /**
     * UIStringManager Instance.
     **/
    public static final String MSGS_STRINGMANAGER =
        PREFIX+"UIStringManager";


    /**
     * General captured logs administration.
     * @since JWare/AntX 0.4
     **/
    public static final String CAPTURED_LOG_OUTPUTS =
        PREFIX+"CapturedLogOutputs";


    /**
     * Standard System output LogRecorder Instance.
     * @since JWare/AntX 0.3
     **/
    public static final String SYSTEM_STREAMS_RECORDER =
        PREFIX+"SystemStreamsRecorder";


    /**
     * Ant logs LogsRecorder Instance.
     * @since JWare/AntX 0.2
     **/
    public static final String ANT_LOGS_RECORDER =
        PREFIX+"AntLogsRecorder";


    /**
     * TaskExaminer Utility.
     * @since JWare/AntX 0.4
     **/
    public static final String TASK_EXAMINER =
        PREFIX+"TaskExaminer";


    /**
     * Variables Utilities.
     * @since JWare/AntX 0.4
     **/
    public static final String VARIABLES_ADMINISTRATION =
        PREFIX+"Variables";


    /**
     * AntX function shortcuts property interpreter.
     * @since JWare/AntXtras 2.0.0
     **/
    public static final String FUNCUTS_INTERPRETER =
        PREFIX+"FuntionShortcutInterpreter";


    /**
     * AntX iteration fixture overlays administration.
     * @since JWare/AntX 0.5
     **/
    public static final String FIXTURE_OVERLAYS =
        PREFIX+"FixtureOverlays";


    /**
     * AntX iteration last-thrown error administration.
     * @since JWare/AntXtras 3.0.0
     **/
    public static final String THROWN_ERRORS_STACK =
        PREFIX+"ThrownErrors";



    /**
     * Allows extension of list of iteration-based elements.
     **/
    protected FixtureIds()
    { }
}

/* end-of-FixtureIds.java */
