/**
 * $Id: StrictInnerTaskSet.java 1289 2011-08-30 04:20:03Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

/**
 * Superclass of all special helper tasks within a strict outer taskset. Special
 * helper tasks are usually tasksets executed in response to a particular kind-of event
 * like a caught build exception or a matching case check. Note a strict inner class
 * is by definition quiet except an alternative "go" API isn't necessary since the inner
 * task can only be nested in a prescribed outer task that controls it.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008,2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  n/a
 * @see      StrictOuterTask
 **/

public abstract class StrictInnerTaskSet extends TaskSet implements StrictInnerTask
{
    /**
     * Creates a new strict inner task. Must be associated with an
     * enclosing task before functional.
     **/
    protected StrictInnerTaskSet(String iam)
    {
        super(iam);
    }


    /**
     * Returns this helper's enclosing block task.
     **/
    public final StrictOuterTask getEnclosingTask()
    {
        return m_enclosingTask;
    }


    /**
     * Initializes this helper's enclosing block task. For now can
     * only be done by a default AntX block task definitions.
     **/
    public final void setEnclosingTask(StrictOuterTask owner)
    {
        m_enclosingTask = owner;
    }


    /**
     * Ensures this helper is enclosed within a block task before
     * it can execute.
     * @throws BuildException if not in valid target/project or not nested
     *         in the expected enclosing taskset.
     **/
    protected void verifyCanExecute_(String calr)
        throws BuildException
    {
        super.verifyCanExecute_(calr);

        if (getEnclosingTask()==null) {
            String ermsg = uistrs().get("task.only.in.outer",getTaskName());
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }


    private StrictOuterTask m_enclosingTask;
}

/* end-of-StrictInnerTaskSet.java */
