/**
 * $Id: NumberCompareFunctionShortcuts.java 1504 2012-09-22 23:30:22Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.condition.ConditionFunctionShortcuts;
import  org.jwaresoftware.antxtras.condition.IsNumber;
import  org.jwaresoftware.antxtras.condition.URIable;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Function shortcuts that let you compare if a number is greater-than,
 * less-than, greater-than-or-equal-to, or less-than-or-equal-to a 
 * specified value. Heavy lifting done by the AntXtras {@linkplain IsNumber}
 * condition; only integral numbers.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;do true="${$gte:1,,${filecount}}"&gt;
 *     <i>[Work work work...]</i>
 *   &lt;/do&gt;
 *   ...
 *   &lt;do gte="1,,${filecount}"&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 3.5.0
 * @author    ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    impl,helper
 **/

public final class NumberCompareFunctionShortcuts
{
    /**
     * Starting implementation for our shortcuts. Common behavior.
     *
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    private abstract static class InnerFuncut implements FunctionShortcut, URIable
    {
        protected InnerFuncut() {
            super();
        }

        public String getDefaultValue(String fullUri, Requester clnt)
        {
            return "";
        }

        public String valueFrom(String fragment, String fullUri, Requester clnt)
        {
            String s = null;
            xsetFromURI(fragment);
            if (m_test!=null) {
                setProject(clnt.getProject());
                s = String.valueOf(m_test.eval());
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }

        protected abstract void finishSetup(IsNumber test, long testValue);

        public void xsetFromURI(String fragment)
        {
            m_test = null;//RESET!
            int N = fragment.length();
            int i = -1;
            if (N>=FunctionShortcut.PARAMS_DELIMITER_LEN+2) {
                i = fragment.indexOf(FunctionShortcut.PARAMS_DELIMITER);
                if (i>0 && (i+FunctionShortcut.PARAMS_DELIMITER_LEN<N)) {
                    long testValue = Tk.longFrom(fragment.substring(0,i),IsNumber.NO_VALUE);
                    if (testValue!=IsNumber.NO_VALUE) {
                        String vut = fragment.substring(i+FunctionShortcut.PARAMS_DELIMITER_LEN);
                        m_test = new IsNumber(vut);
                        finishSetup(m_test,testValue);
                    }
                }
            }
        }

        public boolean eval()
        {
            AntX.verify_(m_test!=null,"NumberCompareFuncut","inited");
            return m_test.eval();
        }

        public void setProject(Project newproject)
        {
            if (m_test!=null) {
                m_test.setProject(newproject);
            }
        }

        private IsNumber m_test;
    }


    /**
     * Function shortcut that tests if a number is greater-than a specified value.
     * @since    JWare/AntXtras 3.5.0
     * @author   ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class IsGT extends InnerFuncut
    {
        protected void finishSetup(IsNumber test, long testValue)
        {
            test.setGT(testValue);
        }
    }


    /**
     * Function shortcut that tests if a number is greater-than or equal-to
     * a specified value.
     * @since    JWare/AntXtras 3.5.0
     * @author   ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class IsGTE extends InnerFuncut
    {
        protected void finishSetup(IsNumber test, long testValue)
        {
            test.setGTE(testValue);
        }
    }
    

    /**
     * Function shortcut that tests if a number is less-than a specified value.
     * @since    JWare/AntXtras 3.5.0
     * @author   ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class IsLT extends InnerFuncut
    {
        protected void finishSetup(IsNumber test, long testValue)
        {
            test.setLT(testValue);
        }
    }


    /**
     * Function shortcut that tests if a number is less-than or equal-to
     * a specified value.
     * @since    JWare/AntXtras 3.5.0
     * @author   ssmc, &copy;2012 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     **/
    public final static class IsLTE extends InnerFuncut
    {
        protected void finishSetup(IsNumber test, long testValue)
        {
            test.setLTE(testValue);
        }
    }



    /**
     * Installs these function shortcuts as URIable
     **/
    public static void doInstall()
    {
        ConditionFunctionShortcuts.addMapping("$lt:", IsLT.class);
        ConditionFunctionShortcuts.addMapping("$lte:", IsLTE.class);
        ConditionFunctionShortcuts.addMapping("$gt:", IsGT.class);
        ConditionFunctionShortcuts.addMapping("$gte:", IsGTE.class);
    }
}


/* end-of-NumberCompareFunctionShortcuts.java */
