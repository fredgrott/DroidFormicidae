/**
 * $Id: TimeUnitFormat.java 780 2009-05-25 11:38:29Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.text.FieldPosition;
import  java.text.Format;
import  java.text.ParsePosition;
import  java.util.Iterator;
import  java.util.Map;

import  org.jwaresoftware.antxtras.core.AntXFixture;

/**
 * Parser for the supported human readable time unit strings
 * used by the $millis: function shortcut.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 * @see       MillisecsFunctionShortcut
 **/

public final class TimeUnitFormat extends Format
{
    final static Double NaN = new Double(Double.NaN);

    //Fixed indices for our recognized time units.
    public final static int UNKNOWN = 0;
    public final static int MILLIS  = UNKNOWN+1;
    public final static int SECONDS = MILLIS+1;
    public final static int MINUTES = SECONDS+1;
    public final static int HOURS   = MINUTES+1;
    public final static int DAYS    = HOURS+1;

    final static Map UNITS  = AntXFixture.newMap();
    final static Map NAMES  = AntXFixture.newMap();
    static {
        //nanos|micros|other (error-> unsupported!)
        Integer index = new Integer(UNKNOWN);
        UNITS.put("nanos",index);
        UNITS.put("micros",index);
        NAMES.put(index,"?");
        //millisecs
        index = new Integer(MILLIS);
        UNITS.put("S",index);
        UNITS.put("ms",index);
        UNITS.put("msecs",index);
        UNITS.put("milli",index);
        UNITS.put("millis",index);
        NAMES.put(index,"ms");
        //seconds
        index = new Integer(SECONDS);
        UNITS.put("s",index);
        UNITS.put("sec",index);
        UNITS.put("secs",index);
        NAMES.put(index,"s");
        //minutes
        index = new Integer(MINUTES);
        UNITS.put("m",index);
        UNITS.put("min",index);
        UNITS.put("mins",index);
        NAMES.put(index,"m");
        //hours
        index = new Integer(HOURS);
        UNITS.put("h",index);
        UNITS.put("hr",index);
        UNITS.put("hrs",index);
        UNITS.put("hour",index);
        UNITS.put("hours",index);
        NAMES.put(index,"h");
        //days
        index = new Integer(DAYS);
        UNITS.put("d",index);
        UNITS.put("dy",index);
        UNITS.put("day",index);
        UNITS.put("days",index);
        NAMES.put(index,"d");
    }

    public Object parseObject(String source, ParsePosition pos)
    {
        final int startindex = pos.getIndex();
        if (startindex<0 || startindex>=source.length()) {
            throw new StringIndexOutOfBoundsException(startindex);
        }
        String s = source.substring(startindex);
        Object exactmatch = UNITS.get(s);
        if (exactmatch!=null) {
            pos.setIndex(startindex+s.length());
            return exactmatch;
        }
        for (Iterator itr = UNITS.entrySet().iterator();itr.hasNext();) {
            Map.Entry next = (Map.Entry)itr.next();
            String unit = next.getKey().toString();
            if (s.startsWith(unit)) {
                pos.setIndex(startindex+unit.length());
                return next.getValue();
            }
        }
        return null;
    }
    
    public Number parse(String source, ParsePosition pos)
    {
        Object result = parseObject(source,pos);
        if (result instanceof Number) {
            return ((Number)result);
        }
        return NaN;
    }

    public Number parse(String source)
    {
        return parse(source, new ParsePosition(0));
    }

    public StringBuffer format(Object o, StringBuffer sb, FieldPosition pos)
    {
        if (o instanceof Number) {
            Integer index = new Integer(((Number)o).intValue());
            String name = (String)NAMES.get(index);
            if (name!=null) {
                pos.setBeginIndex(sb.length());
                sb.append(name);
                pos.setEndIndex(sb.length()-1);
            }
        }
        return sb;
    }
}

/* end-of-TimeUnitFormat.java */
