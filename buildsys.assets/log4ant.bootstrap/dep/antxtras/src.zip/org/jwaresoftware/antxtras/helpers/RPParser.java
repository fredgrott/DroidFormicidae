/**
 * $Id: RPParser.java 1197 2011-08-01 15:17:23Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.util.regex.Pattern;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.PropertyFactoryMethod;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * Recursive property parser. Use to extract recursive property declarations
 * <em>before</em> additional interpretation like funcut URI references. A
 * parser can be setup to be either standard or "full". A full parser will
 * look for back-slash escaped token markers; for example,
 * "<span class="src">\$${name}"</span>. The default is to create standard
 * parsers without escape processing.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 * @see       org.jwaresoftware.antxtras.core.FixtureExaminer
 **/
public final class RPParser
{
    /** Symbolic index of an item that is not located; {@value}.*/
    public static final int NOT_FOUND= -1;


    /** Default opener for Ant property references '{@value}'. */
    public static final String DEFAULT_OPENER_TOKEN= "${";
    /** Default closer for Ant property references '{@value}'. */
    public static final String DEFAULT_CLOSER_TOKEN= "}";


    /**
     * Tracks the match and replacement information needed for
     * user-defined opener and closers. Need RE and replacement
     * to support escaping of tokens within value strings.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   impl,helper
     **/
    static final class Token {
        final String string; //original token string
        final int len; //length of original token
        Pattern re; //replacement pattern (iff 'full')
        String replacement; // what we subst in REs

        Token(String s, boolean full) {
            string = s;
            replacement = s;
            len = s.length();
            if (full) {
                re = newPattern(s);
                if (s.indexOf('$')>=0) {
                    replacement = newReplacement(s);
                }
            }
        }
        private Pattern newPattern(String s) {
            final int n=s.length();
            StringBuffer sb= new StringBuffer(n*3+2);
            sb.append("\\\\");
            for (int i=0;i<n;i++) {
                sb.append('\\');
                sb.append(s.charAt(i));
            }
            return Pattern.compile(sb.toString());
        }
        private String newReplacement(String s) {
            final int n=s.length();
            StringBuffer sb= new StringBuffer(n*2);
            for (int i=0;i<n;i++) {
                char c = s.charAt(i);
                if (c=='$') {
                    sb.append('\\');
                }
                sb.append(c);
            }
            return sb.toString();
        }
    }


    /**
     * Tracks the recursive parsing of property value interpolation.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.5.0b2
     * @.safety  single
     * @.group   api,helper
     **/
    public static final class Result {
        public boolean malformed;
        public boolean unresolved;//@since JWare/AntXtras 3.0.0
        public final String original;
        public String result;
        public int edits;//@since JWare/AntXtras 3.0.0
        Result(String original) { 
            this.original = original; 
            this.result = original;
        }
        public String toString() {
            StringBuffer sb = SystemFixture.newStringBuffer();
            sb.append("Malformed=").append(malformed).append(Strings.NL);
            sb.append("Unresolved=").append(unresolved).append(Strings.NL);
            sb.append("Replaced=").append(edits).append(Strings.NL);
            sb.append("Original=").append(original).append(Strings.NL);
            sb.append("Interpolated=").append(result).append(Strings.NL);
            return sb.toString();
        }
    }


    /**
     * Initializes a new recursive property value interpreter.
     * @param opener opening token for a property reference (non-null)
     * @param closer closing token for a property reference (non-null)
     * @param escapable <i>false</i> to disable processing of '\' as escape character
     * @param full <i>true</i> to support token escaping.
     * @throws IllegalArgumentException if either token is <i>null</i> or
     *          opener and closer are same value.
     **/
    public RPParser(String opener, String closer, final boolean escapable, final boolean full)
    {
        if (opener==null || closer==null) {
            throw new IllegalArgumentException("Non-null opener/closer tokens required");
        }
        if (Tk.equalStrings(opener, closer, true)) {
            throw new IllegalArgumentException("Distinct opener/closer tokens required");
        }
        m_Opener = new Token(opener,full);
        m_Closer = new Token(closer,full);
        m_EscEsc = escapable;
        m_AntEsc = getSupportAntEscapeFlag(opener,closer,full);
    }



    /**
     * Initializes a new standard recursive property value interpreter
     * that looks for the default opener and closer tokens and allows
     * '\' as an overall escape prefix but <em>NOT</em> '$$' (old
     * Ant style).
     * @see #DEFAULT_OPENER_TOKEN
     * @see #DEFAULT_CLOSER_TOKEN
     **/
    public RPParser()
    {
        this(DEFAULT_OPENER_TOKEN,DEFAULT_CLOSER_TOKEN,true,false);
    }



    /**
     * Initializes a new standard recursive property interpreter
     * that can ignore escaping processing.
     * @param escapable <i>false</i> to disable processing of '\' as escape character
     * @param full <i>true</i> to support token escaping.
     * @since JWare/AntXtras 3.0.0
     **/
    public RPParser(final boolean escapable, final boolean full)
    {
        this(DEFAULT_OPENER_TOKEN,DEFAULT_CLOSER_TOKEN,escapable,full);
    }



    /**
     * Returns this parser's opener token. Never returns <i>null</i>
     * or a whitespace string. Note: a RPParser's opener is never
     * equal to its closer token.
     **/
    public final String getOpenerToken()
    {
        return m_Opener.string;
    }



    /**
     * Returns this parser's closer token. Never returns <i>null</i>
     * or a whitespace string. Note: a RPParser's closer is never
     * equal to its opener token.
     **/
    public final String getCloserToken()
    {
        return m_Closer.string;
    }



    /**
     * Returns the index of the next occurance of a named token string.
     * Will return {@linkplain #NOT_FOUND} if unable to find match.
     * @param in string under test (non-null)
     * @param start index from where search should start
     * @param of token string (non-null)
     * @param esc <i>true</i> to process '\' as escape character
     **/
    private static int nextOccurance(String in, int start, final String of, boolean esc)
    {
        int index = NOT_FOUND;
        if (in!=null && start>=0 && start<in.length()) {
            index = in.indexOf(of,start);
            if (index>0 && esc) {
                char prevch = in.charAt(index-1);
                if (prevch=='\\') {
                    index = nextOccurance(in,index+1,of,esc);
                }
            }
        }
        return index;
    }



    /**
     * Return the index of the next occurance of this parser's
     * opener token inside the given string.
     * @param in string under test (non-null)
     * @param start index from where search should start
     * @return index of <em>start</em> of opener or {@linkplain #NOT_FOUND}
     **/
    public int nextOpener(String in, int start)
    {
        return nextOccurance(in,start,m_Opener.string,m_EscEsc);
    }



    /**
     * Return the index of the next occurance of this parser's
     * closer token inside the given string.
     * @param in string under test (non-null)
     * @param start index from where search should start
     * @return index of <em>start</em> of closer or {@linkplain #NOT_FOUND}
     **/
    public int nextCloser(String in, int start)
    {
        return nextOccurance(in,start,m_Closer.string,m_EscEsc);
    }



    /**
     * Locate the balancing closer for a previously located opener. Will
     * return {@linkplain #NOT_FOUND} if no balancing closer found.
     * @param in string under test (non-null)
     * @param start index in 'string' where search for closer should start
     * @return location of <em>start</em> of closer or {@linkplain #NOT_FOUND}.
     **/
    public int balancingCloser(String in, int start)
    {
        int index = NOT_FOUND;
        if (in!=null && start>=0 && start<in.length()) {
            int lastOpener = NOT_FOUND;
            int unbalancedOpeners = 1;
            int nextCloser = nextCloser(in,start);
            int nextOpener = nextOpener(in,start);
            while (unbalancedOpeners>0) {
                if (nextCloser==NOT_FOUND) {
                    break;//malformed
                }
                if (nextOpener!=NOT_FOUND && nextOpener<nextCloser) {
                    unbalancedOpeners++;
                    lastOpener = nextOpener;
                    nextOpener = nextOpener(in,lastOpener+m_Opener.len);
                } else {
                    unbalancedOpeners--;
                    if (unbalancedOpeners==0) {
                        index=nextCloser;
                    } else {
                        nextCloser = nextCloser(in,nextCloser+m_Closer.len);
                    }
                }
            }
        }
        return index;
    }



    /**
     * Interpolate the incoming value by replacing occurances of all property
     * references (including recursive references) with values stored in
     * the incoming properties holder.
     * @param value string to be interpolated (non-null)
     * @param properties domain of possible property reference values (non-null)
     * @param calr callback handler (non-null)
     * @return interpolation result including flag if not totally successful
     **/
    public Result interpolate(String value, PropertyFactoryMethod properties, Requester calr)
    {
        Result r = new Result(value);
        if (Tk.isWhitespace(value)) {
            return r;
        }
        StringBuffer sb = new StringBuffer(value);
        int openerIndex = nextOpener(value,0);
        int edits = 0;
        while (openerIndex!=NOT_FOUND) {
            String vut = sb.toString();
            int closerIndex = balancingCloser(vut,openerIndex+m_Opener.len);
            if (closerIndex==NOT_FOUND) {
                r.malformed=true;
                break;
            }
            String replacement=null;
            edits++;
            if (m_AntEsc && openerIndex>0) {
                char prevch = vut.charAt(openerIndex-1);
                if (prevch=='$') {
                    replacement = sb.substring(openerIndex,closerIndex+m_Closer.len);
                    openerIndex--;
                }
            }
            if (replacement==null) {
                String between = sb.substring(openerIndex+m_Opener.len,closerIndex);
                Result between_interp = interpolate(between,properties,calr);
                if (between_interp.malformed)  {
                    r.malformed=true;
                }
                if (between_interp.unresolved) {
                    r.unresolved=true;
                }
                edits += between_interp.edits;
                if (m_Opener.re!=null) {
                    String alt = m_Opener.re.matcher(between_interp.result).replaceAll(m_Opener.replacement);
                    if (alt.length()!=between_interp.result.length()) {
                        between_interp.result = alt;
                    }
                    alt = m_Closer.re.matcher(between_interp.result).replaceAll(m_Closer.replacement);
                    if (alt.length()!=between_interp.result.length()) {
                        between_interp.result = alt;
                    }
                }
                replacement = properties.getProperty(between_interp.result);
                if (replacement==null) {
                    replacement = m_Opener.string+between_interp.result+m_Closer.string;
                    calr.problem("Unable to find property value for '"+replacement+"'", Project.MSG_VERBOSE);
                    r.unresolved = true;
                    edits--;
                }
            }
            sb.replace(openerIndex,closerIndex+m_Closer.len,replacement);
            closerIndex += replacement.length()-(closerIndex-openerIndex+1);//replacement-adjustment
            openerIndex = nextOpener(sb.toString(),closerIndex+1);
        }
        if (edits>0) {
            r.result = sb.substring(0);
            r.edits  = edits;
        }
        return r;
    }


    private boolean getSupportAntEscapeFlag(String opener, String closer, final boolean full) {
        return DEFAULT_OPENER_TOKEN.equals(opener) && DEFAULT_CLOSER_TOKEN.equals(closer) && !full;
    }

    private final Token m_Opener, m_Closer;
    private final boolean m_AntEsc;//NB: Per-Ant '$${...}' needs collapsing to '${...}' in final string
    private final boolean m_EscEsc;//NB: General '\' escaping (not specific to Ant)
}

/* end-of-RPParser.java */
