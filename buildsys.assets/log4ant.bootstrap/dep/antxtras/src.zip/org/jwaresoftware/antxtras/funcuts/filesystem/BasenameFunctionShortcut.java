/**
 * $Id: BasenameFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.filesystem;

import  java.io.File;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that is an inline version of the standard Ant 
 * &lt;basename&gt; task. The general format of the URI is:
 * <span class="src">$basename:path[?suffix]</span>. The path will be 
 * resolved relative to the URI's owning project if necessary and like
 * the &lt;basename&gt; task an empty path string is interpreted as
 * the project's base directory.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;parameter name="label" 
 *      value="${<b>$basename:</b>${mainlibs.d}}"/&gt;
 *
 * <b>2)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="basename"
 *             value="${ojaf}.filesystem.BasenameFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class BasenameFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new basename shortcut handler.
     **/
    public BasenameFunctionShortcut()
    {
        super();
    }


    /**
     * Extracts the basename from a passed in filesystem path.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();
        String path = uriFragment;
        String suffix = null;

        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            path = uriFragment.substring(0,i);
            i += SCHEME_DELIMITER_LEN;
            if (i<uriFragment.length()) {
                suffix = Tk.resolveString(P,uriFragment.substring(i),true);
            }
        }
        path = Tk.resolveString(P,path,true);
        return baseFrom(path,suffix,clnt);
    }



    /**
     * Extracts the extensionless base name of given file.
     * @param inpath path as passed in uri fragment
     * @param suffix [optional] suffix to be stripped (if exists)
     * @param clnt call controls (non-null)
     * @return basename (never <i>null</i>)
     **/
    private String baseFrom(String inpath, String suffix, Requester clnt)
    {
        File file;
        if (inpath.length()==0) {
            file = clnt.getProject().getBaseDir();
            if (file==null) {
                return null;
            }
        } else {
            file = clnt.getProject().resolveFile(inpath);
        }
        /* --
         * This is a duplicate of the Ant basename task's core
         * functionality to ensure we do not stray from that impl.
         */
        String filename = file.getName();
        if (!Tk.isWhitespace(suffix) && filename.endsWith(suffix)) {
            int pos = filename.length() - suffix.length();
            if (pos>0 && suffix.charAt(0)!= '.'
                && filename.charAt(pos-1)=='.') {
                pos--;
            }
            filename = filename.substring(0,pos);
        }
        return filename;
    }
}

/* end-of-BasenameFunctionShortcut.java */