/**
 * $Id: Unless.java 407 2008-04-19 16:52:08Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <i>unless</i> and <i>unlessTrue</i>
 * tests for all conditional components.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/

public final class Unless
{
    /**
     * Tests whether or not the given property name does not
     * resolve to a project property. Always returns <i>true</i>
     * for the <i>null</i> or empty string.
     * @param property the property name (non-null)
     * @param P the project to check against (non-null)
     * @return <i>true</i> if the property is <em>not</em> defined
     **/
    public static final boolean allowed(String property, Project P)
    {
        return allowed(property, P, false);
    }



    /**
     * Tests whether or not the given property name does not
     * resolve to a project property with a positive boolean
     * value. Always returns <i>true</i> for the <i>null</i>
     * or empty string.
     * @param property the property name (non-null)
     * @param P the project to check against (non-null)
     * @param onlyUnlessTrue <i>true</i> if property must be defined
     *        to a positive boolean string (like "yes")
     * @return <i>true</i> if the property is <em>not</em> defined
     *         or is not defined as to be positive boolean
     **/
    public static final boolean allowed(String property, Project P,
                                        boolean onlyUnlessTrue)
    {
        if (property==null || "".equals(property)) {
            return true;
        }
        String test = Tk.resolveString(P,property);
        if (onlyUnlessTrue) {
            return !Tk.booleanFrom(P.getProperty(test));//allow off,no,false
        }
        return P.getProperty(test)==null;
    }


    /** Don't allow **/
    private Unless()
    {
    }
}

/* end-of-Unless.java */
