/**
 * $Id: OverlayTaskSet.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture.wrap;

import  java.io.File;
import  java.io.IOException;
import  java.net.MalformedURLException;
import  java.net.URL;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.DynamicAttributeNS;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.property.LocalProperties;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.Defaults;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.FixtureOverlay;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.ownhelpers.ScopedProperties;
import  org.jwaresoftware.antxtras.parameters.FlexSourceSupport;
import  org.jwaresoftware.antxtras.starters.TaskSet;

/**
 * A taskset that overlays a set of localized properties for its nested elements.
 * You can also annotate this block of tasks using the <span class="src">meta</span>
 * attribute so that top-level selectors can examine the meta values w/o having to
 * fully form the usual Ant placeholder <span class="src">UnknownElement</span>.
 * You define local properties using custom attributes which are then installed as
 * supplemental (overriding) project properties for the duration of the taskset's
 * execution (effective for all nested, same-project, tasks). Note that all tasks
 * inherit a standard <span class="src">description</span> attribute so you should
 * not use meta tags as a simple description (just use the standard tag).
 * <p>
 * Because of the way <span class="src">UnknownElement</span> and
 * <span class="src">DynamicConfigurator</span> interact, it is not currently
 * possible to have data types nested inside a local fixture taskset. The
 * "DynamicConfigurator"-ism overrides the "TaskContainer"-isms.
 * <p>
 * This task will automatically convert variable and reference "URLs" to the
 * current value of the named item <em>whenever the property is read</em>. For
 * example, using the variable URL "<span class="src">$var:ABC</span>" as a
 * value for a property <span class="src">ABC</span> will cause the variable
 * <span class="src">ABC</span> to be read everytime the property
 * <span class="src">ABC</span> is read. Note that you do not have to enable
 * value uris for this capability.
 * <p>
 * <b>Example Usage:</b><pre>
 *     &lt;<b>overlay</b> category="normalization" todo="bug1234"&gt;
 *         ... <i>[Your regular tasks here]</i>
 *     &lt;/overlay&gt;
 *
 *     &lt;<b>overlay</b> meta="category=documentation;audience=public"&gt;
 *         ... <i>[Your regular tasks here]</i>
 *     &lt;/overlay&gt;
 *
 *     &lt;<b>overlay</b> file="${user.name}/.builds/etl.properties"&gt;
 *         ... <i>[Your regular tasks here]</i>
 *     &lt;/overlay&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004-2005,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,helper
 **/

public class OverlayTaskSet extends TaskSet
    implements DynamicAttributeNS, FixtureOverlay, FlexSourceSupport
{
    /** @since JWare/AntXtras 3.0.0 */
    protected final static String MAGIC_DEFAULTPROPERTY_PREFIX=
        "__defaultproperty.";

    /**
     * Initializes a new overlayed fixture taskset. This taskset
     * behaves exactly like a standard AntXtras taskset unless you
     * install local properties.
     * @see #setDynamicAttribute setDynamicAttribute(&#8230;)
     **/
    public OverlayTaskSet()
    {
        this(AntX.fixture+"OverlayTaskSet:");
    }



    /**
     * Initialized an embedded or enclosed overlay taskset.
     * @param iam caller's CV-label
     **/
    public OverlayTaskSet(String iam)
    {
        super(iam);
        setWithLocals(true);
    }



    /**
     * Sets this taskset's primary annotation note text.
     * @param notes the notes (non-null)
     **/
    public final void setMeta(String notes)
    {
       m_metaList = notes==null ? "" : notes;
    }



    /**
     * Returns this taskset's primary annotate note. Never
     * returns <i>null</i> but can return the empty string.
     **/
    public final String getMeta()
    {
        return m_metaList;
    }



    /**
     * Returns a map of name-value pairs represented by
     * this task's <span class="src">meta</span> attribute.
     * Never returns <i>null</i> but can return an
     * empty map.
     **/
    public final Map getMetaMap()
    {
        Map map = AntXFixture.newMap();
        List l = LocalTk.splitPairs(getMeta(),getProject());
        if (!l.isEmpty()) {
            for (Iterator itr=l.iterator();itr.hasNext();) {
                String s = itr.next().toString();
                int i= s.indexOf('=');
                if (i>0) {
                    map.put(s.substring(0,i),s.substring(i+1));
                } else {
                    map.put(s,"");
                }
            }
        }
        l=null;
        return map;
    }



    /**
     * Adds the given attribute to this task's local fixture
     * properties. Will be installed when this task is executed.
     * If the name begins with the special 
     * {@linkplain #MAGIC_DEFAULTPROPERTY_PREFIX prefix}, the
     * name is converted to whatever the matching default property's
     * name should be. For example: "__defaultproperty.delimiter"
     * becomes whatever the property name should for the setting
     * the default AntXtras delimiter string.
     **/
    public final void setDynamicAttribute(String uri, String name, String qName, String value)
    {
        require_(name!=null,"setAttr- nonzro name");
        
        if (name.startsWith(MAGIC_DEFAULTPROPERTY_PREFIX)) {
            Defaults defaults = Iteration.defaultdefaults();
            String field = name.substring(MAGIC_DEFAULTPROPERTY_PREFIX.length());
            if (Tk.isWhitespace(field)) {
                String warning = Errs.ItemImproperlyDefined(name,"property name missing");
                log(warning,Project.MSG_WARN);
                return;
            }
            name = defaults.propertyFrom(field, new Requester.ForComponent(this));
            if (name==null) {
                String warning = Errs.ItemImproperlyDefined(field,"default property unknown");
                log(warning,Project.MSG_DEBUG);
                name = defaults.defaultPropertiesPrefix(getProject())+field;
            }
        }
        if (!Tk.equalStrings(uri,"")) {
            name = uri + ":" + name;
        }
        getOverridePropertiesNoNull().put(name,value);
    }



    /**
     * Common extraction code for a <span class="src">Properties</span>
     * stored at a URL once the URL has been determined.
     * @since JWare/AntX 0.4
     * @throws BuildException if unable to load definition from URL
     **/
    private void setFromPropertiesURL(URL url, String from)
    {
        Map p=null;
        try {
            p= InputFileLoader.loadProperties(url,null);
        } catch(IOException iox) {
            String warning = Errs.CantLoadConfigSource(from,iox.getMessage());
            log(warning,Project.MSG_WARN);
        }
        if (p!=null) {
            getOverridePropertiesNoNull().putAll(p);
            p.clear();
        }
    }



    /* @inherit-doc. Load properties from file.
     */
    public void setFile(String filepath)
    {
        require_(filepath!=null,"setFile- nonzro path");

        File file = getProject().resolveFile(filepath);
        try {
            setFromPropertiesURL(AntXFixture.fileUtils().getFileURL(file),filepath);
        } catch(MalformedURLException mux) {
            String warning = Errs.CantLoadConfigSource(filepath,mux.getMessage());
            log(warning,Project.MSG_WARN);
        }
    }



    /* @inherit-doc. Load properties from resource.
     */
    public void setResource(String resource)
    {
        require_(resource!=null,"setRez- nonzro resource name");

        URL url = LocalTk.getSystemResource(resource, getProject());
        if (url!=null) {
            setFromPropertiesURL(url,resource);
        } else {
            String warning = Errs.CantLoadConfigSource(resource,"Resource Not Found");
            log(warning,Project.MSG_WARN);
        }
    }


    /* @inherit-doc. Load properties from URL.
     */
    public void setURL(String urlstr)
    {
        require_(urlstr!=null,"setURL- nonzro URL");
        URL url = null;
        try {
            url = new URL(urlstr);
        } catch(MalformedURLException mux) {
            String warning = Errs.CantLoadConfigSource(urlstr,mux.getMessage());
            log(warning,Project.MSG_WARN);
        }
        if (url!=null) {
            setFromPropertiesURL(url,urlstr);
        }
    }



    /**
     * Overlay the properties located in the referenced
     * properties-like structure.
     * @param ref reference to properties data object (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setProperties(Reference ref)
    {
        require_(ref!=null,"setProperties- nonzro refid");
        Map p= FixtureExaminer.getReferencedProperties(getProject(),ref.getRefId(),null);
        if (p==null) {
            String warning = getAntXMsg("task.bad.refid.nodetails", ref.getRefId());
            log(warning,Project.MSG_WARN);
        } else {
            getOverridePropertiesNoNull().putAll(p);
        }
    }



    /**
     *  Installs local fixture properties if any exist.
     *  @since JWare/AntXtras 3.0.0
     **/
    protected LocalProperties installLocalScope()
    {
        if (m_localProperties!=null) {
            m_localProperties.install(new Requester.ForComponent(this));
        }
        return super.installLocalScope();
    }



    /**
     * Uninstalls our local fixture properties (if was installed).
     * @since JWare/AntXtras 3.0.0
     **/
    protected void uninstallLocalScope(LocalProperties localscope)
    {
        super.uninstallLocalScope(localscope);
        if (m_localProperties!=null) {
            m_localProperties.uninstall(new Requester.ForComponent(this));
        }
    }



    /**
     * Returns this taskset's dynamic attribute name-value pairs.
     * This taskset will reflect any changes to the map. Will
     * return <i>null</i> if no dynamic attributes added to this
     * taskset.
     **/
    protected final Map getOverrideProperties()
    {
        return m_localProperties;
    }



    /**
     * Returns this taskset's dynamic attribute name-value pairs
     * allocating a new map if necessary.
     **/
    protected final Map getOverridePropertiesNoNull()
    {
        if (m_localProperties==null) {
            m_localProperties = new ScopedProperties(getProject(),true);
        }
        return getOverrideProperties();
    }



    private ScopedProperties m_localProperties;//NB: lazy-inited
    private String m_metaList="";
}

/* end-of-OverlayTaskSet.java */
