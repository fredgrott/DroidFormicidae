/**
 * $Id: GenericParameters.java 916 2009-12-20 17:44:43Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.util.Collection;
import  java.util.Iterator;
import  java.util.Map;
import  java.util.Properties;
import  java.util.StringTokenizer;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;

import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.PropertiesFactoryMethod;
import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * Simple collection of {@linkplain InnerNameValuePair key-value} pairs. Duplicates are
 * permitted (last item added wins). Every parameter's name is normalized to its
 * US lowercase equivalent to ensure they can be used directly with Ant's macro and
 * dynamic attribute facilities. GenericParameters can be used as internal data structs
 * or public-facing script components. Subclasses can alter this normalization by
 * overriding the inherited 'nameFrom' method.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>parameters</b>&gt;
 *      &lt;parameter name="build.vcsid" value="2390"/&gt;
 *      &lt;parameter name="build.seqno" value="165"/&gt;
 *   &lt;/parameters&gt;
 *
 *   -OR (shorthand)-
 *
 *   &lt;<b>parameters</b> list="prune;tag=latest"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    impl,helper
 **/

public class GenericParameters extends ProjectComponent 
    implements Cloneable, ProjectDependent, PropertiesFactoryMethod
{
    /**
     * Initializes a new empty parameters collection bean.
     **/
    public GenericParameters()
    {
    }



    /**
     * Initializes a new empty parameters collection bean
     * associated with a project.
     * @param project this parameter object's enclosing project
     **/
    public GenericParameters(Project project)
    {
        setProject(project);
    }



    /**
     * Returns an independent (deep) clone of this Parameters
     * object. The individual items of the clone are also independent;
     * changes to them are not reflected in this object.
     */
    public Object clone()
    {
        try {
           GenericParameters copy= (GenericParameters)super.clone();
           copy.m_items = SystemFixture.newMapCopy(m_items);
           if (!isEmpty()) {
               Iterator itr= copy.m_items.entrySet().iterator();
               while (itr.hasNext()) {
                   Map.Entry e = (Map.Entry)itr.next();
                   e.setValue(((InnerNameValuePair)e.getValue()).clone());
               }
           }
           return copy;
        } catch(CloneNotSupportedException clnx) {
            throw new InternalError("Broken clone");
        }
    }



    /**
     * Adds a new name-value pair to this collection. The new
     * item is <em>not</em> checked for duplicity. If another item
     * with equivalent name already exists, it is replaced
     * unconditionally.
     * @param item new configured item (must be named)
     * @throws BuildException if incoming item not named.
     **/
    public void addConfiguredParameter(InnerNameValuePair item)
    {
        item.verifyNamed();
        item.setName(nameFrom(item.getName()));
        m_items.put(item.getName(),item);
    }



    /**
     * Synonym for {@linkplain #addConfiguredParameter addConfiguredParameter}
     * that is more appropriate for some uses of this bean.
     * @param item new configured item (must be named)
     */
    public final void addConfiguredArg(InnerNameValuePair item)
    {
        addConfiguredParameter(item);
    }



    /**
     * Synonym for {@linkplain #addConfiguredParameter addConfiguredParameter}
     * that is more appropriate for some uses of this bean.
     * @param item new configured item (must be named)
     */
    public final void addConfiguredProperty(InnerNameValuePair item)
    {
        addConfiguredParameter(item);
    }



    /**
     * Adds a collection of name-value pairs to this collection
     * using a simple semi-colon delimited list. If the list is
     * <i>null</i>, this collection is cleared of all current
     * entries. Each item in the list must be in one of the following
     * forms:<ul>
     *   <li>&lt;name&gt;: where the value is automatically assigned as "true".</li>
     *   <li>&lt;name=&gt; where the value is assigned as the empty string.</li>
     *   <li>&lt;name=value&gt; where the value is assigned whatever "value" is.</li>
     * </ul>
     * @param paramlist the pairs
     **/
    public void setList(String paramlist)
    {
        if (paramlist!=null) {
            StringTokenizer st= new StringTokenizer(paramlist,";");
            while (st.hasMoreTokens()) {

                String kv = st.nextToken();
                InnerNameValuePair nvp = newNVPair();
                int i= kv.indexOf("=");

                if (i>0) {
                    String key = kv.substring(0,i);
                    String value = "";
                    if (i<kv.length()-1) {
                        value = kv.substring(i+1);
                    }
                    nvp.setName(key);
                    nvp.setValue(value);
                } else {
                    nvp.setName(kv);
                    nvp.setValue(Strings.TRUE);
                }

                addConfiguredParameter(nvp);
            }
        } else {
            m_items.clear();
        }
    }



    /**
     * Returns <i>true</i> if this collection is empty.
     **/
    public final boolean isEmpty()
    {
        return m_items.isEmpty();
    }



    /**
     * Returns the number of parameters in this collection.
     **/
    public final int size()
    {
        return m_items.size();
    }



    /**
     * Returns this parameters object's underlying name-value
     * items collection. The returned collection is still connected
     * to this data object, so modifications via its iterators are
     * reflected back to this object. Never returns <i>null</i>.
     **/
    public final Collection values()
    {
        return m_items.values();
    }



    /**
     * Returns an independent unsynchronized map of this collection's
     * name-value items. The returned map contains
     * {@linkplain InnerNameValuePair} items as values.
     **/
    public Map copyOfParameterObjects()
    {
        return SystemFixture.newMapCopy(m_items);
    }



    /**
     * Adaption of {@linkplain #copyOfSimpleKeyValues} to the standard
     * <span class="src">PropertiesFactoryMethod</span> interface.
     * @param P [optional] project used to resolve property references.
     **/
    public final Properties toProperties(Project P)
    {
        return copyOfSimpleKeyValues(P,true);
    }



    /**
     * Returns an independent Properties map of this collection's
     * name-value items as simplified name-stringvalue pairs.
     * The returned map contains the item names and string
     * values. Property references are resolved from given project.
     * @param P [optional] project used to resolve property references.
     * @param altForm <i>true</i> if alternative form (%{...}) of property
     *          references are allowed.
     **/
    public Properties copyOfSimpleKeyValues(final Project P, boolean altForm)
    {
        Properties copy = new Properties();
        if (!m_items.isEmpty()) {
            Iterator itr= m_items.entrySet().iterator();
            while (itr.hasNext()) {
                Map.Entry e = (Map.Entry)itr.next();
                copy.put(e.getKey(),
                    ((InnerNameValuePair)e.getValue()).getValue(P,altForm));
            }
        }
        return copy;
    }



    /**
     * Returns an independent Properties map of this collection's
     * name-value items as simplified name-stringvalue pairs.
     * The returned map contains the item names and string
     * values.
     * @param P [optional] project used to resolve property references.
     **/
    public final Properties copyOfSimpleKeyValues(final Project P)
    {
        return copyOfSimpleKeyValues(P,false);
    }



    /**
     * Combine another parameters collection with this one.
     * Shorthand for calling {@linkplain #addConfiguredParameter
     * addConfiguredParameter} repeatedly. Existing parameters
     * are replaced unconditionally with newer versions.
     * @param other parameters to be merged (non-null)
     **/
    public void mergeOther(GenericParameters other)
    {
        Iterator itr = other.copyOfParameterObjects().values().iterator();
        while (itr.hasNext()) {
            addConfiguredParameter((InnerNameValuePair)itr.next());
        }
    }



    /**
     * Combine another parameters collection in form of a standard
     * Java Properties object. Existing parameters are replaced
     * unconditionally with newer versions.
     * @param other other name-value pairs to be merged (non-null)
     **/
    public void mergeOther(Properties other)
    {
        Iterator itr = other.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry e = (Map.Entry)itr.next();
            put(e.getKey().toString(),(String)e.getValue());
        }
    }



    /**
     * Convenient lookup method for a particular parameter.
     * @param name parameter's name (non-null)
     * @return parameter or <i>null</i> if not found
     **/
    public InnerNameValuePair get(String name)
    {
        name = nameFrom(name);
        return (InnerNameValuePair)m_items.get(name);
    }



    /**
     * Convenient lookup method for only the value of a particular
     * parameter.
     * @param name parameter's name (non-null)
     * @return parameter's value or <i>null</i> if not found
     **/
    public final String getv(String name)
    {
        InnerNameValuePair e = get(name);
        if (e!=null) {
            return e.getValue();
        }
        return null;
    }



    /**
     * Factory method to create a new name-value pair for inclusion
     * in this collection. By default returns standard InnerNameValuePair
     * objects.
     * @since JWare/AntX 0.5
     **/
    protected InnerNameValuePair newNVPair()
    {
        return new InnerNameValuePair();
    }



    /**
     * Conversion method to normalize this parameters object's
     * names. By default will lowercase to US-locale to match
     * what Ant does to all of its parameters.
     * @param original the incoming or original key.
     * @since JWare/AntXtras 2.1.0
     **/
    protected String nameFrom(String original)
    {
        return Tk.lowercaseFrom(original);
    }



    /**
     * Common function to put a single name-value pair into this
     * parameters object.
     * @param name new item's unnormalized name (non-null)
     * @param value new item's value
     **/
    protected void put(String name, String value)
    {
        InnerNameValuePair item = newNVPair();
        item.setName(nameFrom(name.toString()));
        item.setValue(value);
        m_items.put(item.getName(),item);
    }


    /**
     * Convenience method to put a single named-value pair as loose
     * values (not part of configured item).
     * @param name property name (non-null)
     * @param value [optional] property value (if null the 'true' string is saved)
     * @since JWare/AntXtras 2.0.0
     */
    public final void setPair(String name, String value) 
    {
        if (name==null) {
            throw new IllegalArgumentException("setPair- nonzro name");
        }
        if (value==null) {
            value= Strings.TRUE;
        }
        put(name,value);
    }


    private Map m_items = SystemFixture.newMap(11,0.8f);
}

/* end-of-GenericParameters.java */