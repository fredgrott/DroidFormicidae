/**
 * $Id: Empties.java 920 2009-12-22 13:44:47Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  org.apache.tools.ant.Task;

/**
 * Collection of common VM-shareable empty arrays.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  multiple
 * @.group   impl,helper
 **/

public final class Empties extends org.jwaresoftware.internal.helpers.Empties
{
    /** Empty array of Ant Tasks. **/
    public static final Task[] EMPTY_TASK_ARRAY= new Task[0];

    /** Long '0' value. **/
    public static final Long ZERO_LONG = new Long(0L);

    /** Permit application-specific extension. **/
    protected Empties() { }
}

/* end-of-Empties.java */
