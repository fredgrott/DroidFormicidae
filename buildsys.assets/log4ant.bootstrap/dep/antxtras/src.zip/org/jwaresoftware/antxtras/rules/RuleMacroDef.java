/**
 * $Id: RuleMacroDef.java 1019 2010-03-13 16:13:19Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.taskdefs.MacroDef;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.NoiseLevel;
import  org.jwaresoftware.antxtras.starters.MacroMaker;

/**
 * Macro maker that enforces a macro's definition to constraints of 
 * an AntXtras ruleset. However, unlike an regular ruleset, you can
 * also include batch checks in a rule macrodef.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,infra
 * @.pattern GoF.Proxy
 * @see      RuleSet
 **/

public final class RuleMacroDef extends MacroMaker
{
    private static final String IAM_= AntX.conditions+"RuleMacroDef";

    /**
     * Initializes a new rule macro instance.
     **/
    public RuleMacroDef()
    {
        this(IAM_);
    }


    /**
     * Initializes a new enclosed macro instance.
     * @param iam CV-label (non-null)
     **/
    public RuleMacroDef(String iam)
    {
        super(iam);
    }


    /**
     * Adds a new attribute definition to this rule macro.
     * @param attr the attribute definition (non-null)
     **/
    public final void addConfiguredAttribute(MacroDef.Attribute attr)
    {
        addMacroParameter(attr);
    }


    /**
     * Returns the supposed effect if this macro evaluates
     * <i>false</i>. Should be called after this rule is fully
     * configured.
     **/
    public NoiseLevel getFailureEffect()
    {
        return m_failureEffect;
    }


    /**
     * Allows only sub-rules (of single effect) to this rule macro. If
     * the new item is the first sub-rule defined, it determines the kind
     * of subsequent sub-rules allowed. If the item is a rule, it must
     * be of the expected (dominant) type. Note that fixture checks are
     * always allowed.
     * @param taskClass class of task to be instantiated in macro instance
     * @param taskProxy task proxy (UnknownElement), non-null
     * @throws BuildException if task of wrong kind
     **/
    protected boolean includeTask(Class taskClass, Task taskProxy)
        throws BuildException
    {
        if (FixtureCheckTask.class.isAssignableFrom(taskClass)) {//always
            return true;
        }

        boolean isRequire = isRequireType(taskClass);
        boolean isPrefer  = !isRequire && PreferTask.class.isAssignableFrom(taskClass);

        if (!isRequire && !isPrefer) {
            return false;
        }

        if (m_failureEffect!=null) {
            RuleSet.checkAcceptable(this,isRequire,m_failureEffect);
        } else if (isRequire) {
            m_failureEffect = NoiseLevel.ERROR;
        } else {
            m_failureEffect = NoiseLevel.WARNING;
        }

        return true;
    }



    private boolean isRequireType(Class taskClass)
    {
        return AssertTask.class.isAssignableFrom(taskClass) ||
               BatchChecksTaskSet.class.isAssignableFrom(taskClass);
    }


    private NoiseLevel m_failureEffect=null;//NB: unknown->defined by 1st subrule
}

/* end-of-RuleMacroDef.java */
