/**
 * $Id: ThrownErrors.java 1225 2011-08-13 19:15:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.wrap;

import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.FixtureIds;
import  org.jwaresoftware.antxtras.core.FixtureOverlays;
import  org.jwaresoftware.antxtras.core.KillMethodSkeleton;

/**
 * Manages stack of thrown errors for current thread. The errors are pushed/popped
 * by the misc protected tasksets performed (can be nested).
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/
public final class ThrownErrors
{
    private static final String WHOAMI_ = "ThrownErrors";

    
    /** 
     * Overlays data category id for thrown errors management.
     */
    private static final String FXID = FixtureIds.THROWN_ERRORS_STACK;



    /**
     * Returns the last thrown error or <i>null</i> if nothing installed.
     **/
    public static Throwable getLast()
    {
        FixtureOverlays context = FixtureOverlays.getContextInstance();
        return (Throwable)context.nearest(FXID);
    }



    /**
     * Pushes a new thrown error onto the current thread's error stack.
     * @param thrown the captured throwable (non-null) 
     * @param issueHandler [optional] handler callback if cannot store
     * @return the throwable that was current (can be <i>null</i>)
     **/
    public static Throwable installLast(Throwable thrown, ProblemHandler issueHandler)
    {
        AntX.require_(thrown!=null, WHOAMI_, "lastThrown");
        return (Throwable)FixtureOverlays.installIfNot(FXID,thrown,issueHandler,WHOAMI_);
    }



    /**
     * Removes the nearest thrown error from current thread's error
     * stack. Called by the unwinding protected taskset usually.
     * @param issueHandler [optional] handler callback if cannot unwind
     **/
    public static void unwindLast(ProblemHandler issueHandler)
    {
        FixtureOverlays.uninstallIfIs(FXID,issueHandler,WHOAMI_);
    }



    /** Disallowed; only public static utilities. */
    private ThrownErrors() { }


    /**
     * Static initializer that installs our kill method callback.
     **/
    {
        AntXFixture.setKillMethod(
                FXID, 
                new KillMethodSkeleton(FXID,WHOAMI_));
    }
}


/* end-of-ThrownErrors.java */
