/**
 * $Id: BuildError.java 388 2008-03-30 15:44:14Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Location;

/**
 * Error equivalent of a BuildException except will exit the build process w/o
 * being ignored. Use very sparingly to indicate a true unrecoverable fault has
 * occured.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003,2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @.caveat  As of Ant 1.6.5 it's possible for a user to ignore both Exceptions
 *           <em>and Errors</em> unconditionally with the '-keepGoing' option
 *           (to me this makes no sense for Errors as these are typically the JVM's
 *           way of saying something pretty bad has happened please 'STOP'; but
 *           the Ant developers insist this 'typical' meaning is not guaranteed
 *           so they see no need to interpret Errors this way in their framework).
 **/

public final class BuildError extends Error
{
    /**
     * Initializes a new build error. Must provide at least
     * a message.
     * @param message error message (non-null)
     **/
    public BuildError(String message)
    {
        super(message);
    }



    /**
     * Initializes a new build error caused by another exception.
     * @param message error message
     * @param cause the actual cause of build error (non-null)
     * @since JWare/AntX 0.6
     **/
    public BuildError(String message, Exception cause)
    {
        super(message,cause);
    }



    /**
     * Initializes a new build error from a specific build script
     * location.
     * @param message error message (non-null)
     * @param location the build script location (non-null)
     **/
    public BuildError(String message, Location location)
    {
        super(message);
        m_location = location;
    }



    /**
     * Initializes a new build error caused by another exception
     * at a particular build script location.
     * @param message error message (non-null)
     * @param location the build script location (non-null)
     * @param cause the actual cause (non-null)
     * @since JWare/AntX 0.6
     **/
    public BuildError(String message, Location location, Exception cause)
    {
        super(message);
        m_location = location;
    }



    /**
     * Returns the file location where the error occurred.
     */
    public Location getLocation()
    {
        return m_location;
    }



    /**
     * Returns the location of the error and the error message.
     */
    public String toString()
    {
        return String.valueOf(m_location) + getMessage();
    }


    private Location m_location = Location.UNKNOWN_LOCATION;
}

/* end-of-BuildError.java */
