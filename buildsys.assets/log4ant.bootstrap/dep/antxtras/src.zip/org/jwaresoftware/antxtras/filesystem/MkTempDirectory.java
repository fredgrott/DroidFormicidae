/**
 * $Id: MkTempDirectory.java 428 2008-04-27 13:12:32Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.io.File;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

/**
 * Task that creates temporary directories. Note temporary
 * directories (unlike temporary files) are <em>not</em> marked for automatic
 * deletion when the VM exits.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>newtempdir</b> prefix=".sql-" pathproperty="sql.root.d"/&gt;
 *   &lt;<b>newtempdir</b> prefix=".tmp-" in="${userscratch.d}" urlproperty="scratch.url"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 **/

public final class MkTempDirectory extends MkTempObject
{
    /**
     * Create a new task instance.
     **/
    public MkTempDirectory()
    {
        super();
        setPersist(true);
    }


    /**
     * Creates a new temporary directory. Will not produce the
     * same named directory within a single VM instance. If a prototype file was
     * named, a identical copy is created in the new temporary directory.
     **/
    public void execute() throws BuildException
    {
        verifyInProject_("exec");

        File newDir = createDirectory(getInDir());

        if (getPathProperty()!=null || getUrlPathProperty()!=null) {
            saveFinalPath(newDir,true);
        }
        else {
            //NB: there are legitimate reasons not to specify a property (esp. tests)
            String warnmsg = uistrs().get("mktemp.no.property", newDir.getPath());
            log(warnmsg, Project.MSG_VERBOSE);
        }

        if (isAutoDelete()) {
            newDir.deleteOnExit();
        }
    }
}

/* end-of-MkTempDirectory.java */
