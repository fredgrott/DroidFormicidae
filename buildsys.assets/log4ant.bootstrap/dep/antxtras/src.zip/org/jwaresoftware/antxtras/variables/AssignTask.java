/**
 * $Id: AssignTask.java 1331 2012-07-16 13:17:57Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.variables;

import  java.text.DecimalFormat;
import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.core.Scope;
import  org.jwaresoftware.antxtras.helpers.ObjectHandle;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.TransformEnabled;
import  org.jwaresoftware.antxtras.parameters.TransformHelper;
import  org.jwaresoftware.antxtras.parameters.ValueTransform;

/**
 * Helper task that manipulates a modifiable property aka
 * {@linkplain org.jwaresoftware.antxtras.core.Variables
 * a variable}.
 * <p>
 * <b>Example Usage:</b><pre>
 *  &lt;assign var="loopcount" value="0"/&gt;
 *  &lt;assign var="loopcount" op="++"/&gt;
 *  &lt;assign var="__bn" fromproperty="build.number"/&gt;
 *  &lt;assign var="num.changes" op="+" value="${diff.count}"/&gt;
 *  &lt;assign var="num.changes" copyproperty="__loop.num.changes"/&gt;
 *  &lt;assign var="time" op="now"/&gt;
 *  &lt;assign var="duration" op="-now" fromvariable="time"/&gt;
 *  &lt;assign var="time" op="-now"/&gt;
 *  &lt;assign var="totaltime" op="+" fromvariable="duration"/&gt;
 *  &lt;assign var="why" op="+s" value="(${$ref:lasterror})"/&gt;
 *  &lt;assign var="jars" op="+l" value="${next.jar}"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2008-2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   api,helper
 * @see      UnassignTask
 **/

public class AssignTask extends AssertableTask
    implements TransformEnabled, AntLibFriendly
{
    private static final String SRC_ATTRS = "value|fromproperty|fromvar";

// ---------------------------------------------------------------------------------------
// Construction:
// ---------------------------------------------------------------------------------------

    /**
     * Initializes a new assign task instance.
     **/
    public AssignTask()
    {
        super(AntX.fixture+"AssignTask:");
    }


    /**
     * Initializes this task's project.
     **/
    public void setProject(Project project)
    {
        super.setProject(project);
        m_value.setProject(project);
    }


// ---------------------------------------------------------------------------------------
// Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets this assign task's effective scope. Value must be one
     * of "<i>project</i>","<i>thread</i>", or "<i>system</i>".
     * Defaults to "<i>thread</i>".
     * @since JWare/AntX 0.2
     **/
    public void setScope(Scope scope)
    {
        require_(scope!=null,"setScope- nonzro scope");
        m_scope = scope;
    }


    /**
     * Returns this assign task's effective scope. Never returns
     * <i>null</i>; defaults to "<i>thread</i>".
     * @since JWare/AntX 0.2
     **/
    public final Scope getScope()
    {
        return m_scope;
    }


    /**
     * Sets this assign task's modifiable property name.
     * @param name property's name (non-null)
     **/
    public void setName(String name)
    {
        require_(!Tk.isWhitespace(name),"setName- nonwspc name");
        m_name = name;
    }


    /**
     * Synonym for {@linkplain #setName setName}.
     **/
    public final void setVar(String name)
    {
        setName(name);
        
    }


    /**
     * Shortcut to set name of reference to assign to.
     * @since JWare/AntXtras 3.0.0
     **/
    public final void setRef(String name)
    {
        setName(name);
        setScope(Scope.PROJECT);
    }


    /**
     * Returns this assign task's property's name. Will return
     * <i>null</i> if never set.
     **/
    public final String getName()
    {
        return m_name;
    }


    /**
     * Sets this assign task's new value as a literal as-is string.
     * @param value new value (non-null)
     * @see #setOp setOp(&#8230;)
     **/
    public void setValue(String value)
    {
        require_(value!=null,"setValu- nonzro valu");
        m_value.set(value);
        m_value.setIsLiteral();
    }


    /**
     * Sets this assign task's new value from a property's value.
     * @param property property's name (non-null)
     * @since JWare/AntX 0.3
     **/
    public void setFromProperty(String property)
    {
        require_(property!=null,"setFromProp- nonzro name");
        m_value.set(property);
        m_value.setIsProperty(true);
    }


    /**
     * Sets this assign task's new value from another variable's
     * value. The source variable is assumed in the thread-scope.
     * @param variable variable's name (non-null)
     * @since JWare/AntX 0.3
     **/
    public void setFromVariable(String variable)
    {
        require_(variable!=null,"setFromVar- nonzro name");
        m_value.set(variable);
        m_value.setIsVariable(true);
    }


    /**
     * Synonym for {@linkplain #setFromVariable setFromVariable}.
     * @since JWare/AntX 0.4
     **/
    public final void setFromVar(String variable)
    {
        setFromVariable(variable);
    }


    /**
     * Returns this assign task's source value. Can return <i>null</i>
     * if this task's source was never defined or source is missing.
     * The returned value represents a literal ({@linkplain #setValue
     * value}), a property's value ({@linkplain #setFromProperty
     * fromproperty}), or another variable's value ({@linkplain
     * #setFromVariable fromvariable}).
     **/
    public final String getValue()
    {
        return m_value.getValue();
    }


    /**
     * Changes this assign task's default <i>assign</i> operation.
     * @param opname required modification by name (non-null)
     **/
    public final void setOp(String opname)
    {
        require_(opname!=null,"setModf- nonzro op");
        ObjectHandle args = new ObjectHandle();
        Modification op = Modification.from(opname,args);
        if (op==null) {
            String e = Errs.IllegalParameterValue(getTaskName(),"op",opname);
            log(e, Project.MSG_ERR);
            throw new BuildException(e, getLocation());
        }
        m_Op = op;
        m_OpArgs = args.asString();
    }


    /**
     * Returns this assign task's modification operation. Never
     * returns <i>null</i>. Defaults to simple assignment.
     **/
    public final Modification getOp()
    {
        return m_Op;
    }


    /**
     * Sets the value transform for the value copied to
     * the variable.
     * @since JWare/AntX 0.4
     **/
    public final void setTransform(ValueTransform t)
    {
        m_T = t==null ? null : ValueTransform.from(t.getValue());//normalize
    }


    /**
     * Returns the value transformation this task will
     * perform on the to-be-copied value. Will return
     * {@linkplain ValueTransform#NONE} if never set.
     * @since JWare/AntX 0.4
     **/
    public final ValueTransform getTransform()
    {
        return m_T==null ? ValueTransform.NONE : m_T;
    }



    /**
     * Sets a name for a regular property to be updated with new
     * assigned property's value. This update is done <em>in
     * addition</em> to the assigned variable's update. If the 
     * passed in name is the empty string, a property with same
     * name as the variable is created (as of AntXtras 4.0.0).
     * @param property property's name (non-null)
     **/
    public void setCopyProperty(String property)
    {
        require_(property!=null,"setP- nonzro propnam");
        m_copyProperty = property;
    }


    /**
     * Returns name of regular property to be updated in
     * addition to the assigned variable. Returns <i>null</i>
     * if not set. Returns the variable's name if copy
     * property was set to the empty string (as of AntXtras 4.0)
     **/
    public final String getCopyProperty()
    {
        String property = m_copyProperty;
        if (property==null)
            return property;
        if (Tk.isWhitespace(property)) {
            property = getName();
        }
        return property;
    }

// ---------------------------------------------------------------------------------------
// Managing Modifiable Variable:
// ---------------------------------------------------------------------------------------

    /**
     * Returns <i>true</i> if this task's source (value) has
     * not be explicitly defined.
     * @since JWare/AntX 0.3
     **/
    protected final boolean isUndefined()
    {
        return m_value.isUndefined();
    }


    /**
     * Updates the modifiable property with given value. What
     * this method actually effects depends on this task's scope.
     * @see Scope#setTheValue Scope.setTheValue()
     **/
    protected final void setTheProperty(String value)
    {
        boolean erase = !Iteration.defaultdefaults().isEmptyVariablesAllowed(getProject());
        String what = getScope()==Scope.THREAD ? "var" : "ref";
        log("Assigning "+what+": '"+getName()+"' -> "+value,Project.MSG_DEBUG);
        Scope.setTheValue(getScope(),getProject(),getName(),value,erase,null);
    }


    /**
     * Returns the modifiable property's current value. Can return
     * <i>null</i> if property never set.
     * @see Scope#getTheValue Scope.getTheValue()
     **/
    protected final String getTheProperty()
    {
        return Scope.getTheValue(getScope(),getProject(),getName());
    }


    /**
     * Sets a cached predetermined value for this task. This allows
     * pre-checks to cache values w/o changing the task's formal
     * definition.
     * @since JWare/AntX 0.3
     **/
    protected final void setShortcutValue(String value)
    {
        m_shortcutValue = value;
    }


    /**
     * Ensures auto-assigned delta values for certain modification
     * are defined; for example, "++" is shorthand for an increase of
     * one.
     **/
    protected void fixDefaults()
    {
        if (isUndefined()) {
            int op= getOp().getIndex();
            switch (op) {
                case Modification.INC_BY1_INDEX:
                case Modification.DEC_BY1_INDEX: {
                    setShortcutValue("1");
                    break;
                }
                //JWare/AntX 0.3
                case Modification.NOW_INDEX:
                case Modification.MINUS_NOW_INDEX: {
                    setShortcutValue(String.valueOf(System.currentTimeMillis()));
                    break;
                }
            }
        }
    }


    /**
     * Returns the initializing variable value. Defaults to a zero
     * Long. Could be different for typed variables; for instance
     * a timestamp might return the current system time.
     * @param like [optional] hint about the type of operation
     *             value to be used in
     * @since JWare/AntX 0.2
     **/
    protected Number initialValue(Number like)
    {
        if (like instanceof Double) {
            return INITIAL_NUMF;
        }
        return INITIAL_NUMI;
    }


    /**
     * Returns any predetermined value for this task. This allows
     * pre-checks to cache values w/o changing the task's attribute
     * definitions.
     * @since JWare/AntX 0.3
     **/
    protected String shortcutValue()
    {
        return m_shortcutValue;
    }


    /**
     * Returns the value with which this task should operate. Takes
     * any cached shortcut values and/or flex conversion into acccount.
     * @see #getValue
     * @see #shortcutValue
     * @since JWare/AntX 0.3
     **/
    protected String getWorkValue()
    {
        String value = shortcutValue();
        if (value==null) {
            value = getValue();
        }
        return value;
    }



    /**
     * Applies any value transformation instruction(s) to the given
     * value. AntXtras v1 extension point; current best practice is
     * to use a transformation function shortcut.
     * @param value [optional the value to be transformed
     * @param numberValue [optional] the numeric value to be transformed
     * @return the transformed value or same if no transformation necessary
     * @since JWare/AntX 0.4
     **/
    protected String getExportValue(String value, Number numberValue)
    {
        if (value==null) {
            // NB: do what most people expect in terms of float formatting!
            if (m_T==ValueTransform.DECIMAL) {
                synchronized(DFI) {
                    return DFI.format(numberValue);
                }
            }
            value = numberValue.toString();
        }
        if (m_T!=null) {
            value = TransformHelper.apply(m_T,value,getProject());
        }
        return value;
    }



    /**
     * Ensures this task is in a valid project and has an assigned
     * value.
     * @throws BuildException if value not defined
     **/
    protected void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);

        if (getName()==null) {
            String ermsg = Errs.NeedsThisAttribute(getTaskName(),"var|name");
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }

        fixDefaults();

        if (isUndefined() && shortcutValue()==null) {
            if (getCopyProperty()!=null &&
                getOp().getIndex()==Modification.SET_INDEX) {//justCopy
                return;
            }
            String ermsg = Errs.NeedsThisAttribute(getTaskName(),SRC_ATTRS);
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }



    /**
     * Performs a delta operation on the existing property value (which
     * must be either undefined or a valid number).
     * @param negate <i>true</i> if operation is a decrement
     * @throws BuildException if either the current value or the delta
     *         value are not valid numbers
     **/
    protected void doDeltaOperation(boolean negate)
    {
        String value = getWorkValue();
        Number delta = Tk.numberFrom(value);
        if (delta==Tk.NO_NUM_NUM) {
            if (value==null) { 
                value= "{"+Strings.UNDEFINED+"}";
            }
            String ermsg = uistrs().get("assign.value.NAN",value);
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg, getLocation());
        }

        String oldvalue = getTheProperty();
        Number current;
        if (oldvalue!=null) {
            current = Tk.numberFrom(oldvalue);
        } else {
            current = initialValue(delta);//!?
        }
        if (current==Tk.NO_NUM_NUM) {
            String ermsg = uistrs().get("assign.current.NAN",getName(),oldvalue);
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg, getLocation());
        }

        if (current instanceof Double || delta instanceof Double) {
            double delta_ = delta.doubleValue();
            if (negate) {
                delta_ = -delta_;
            }
            current = new Double(current.doubleValue()+delta_);
        } else {
            long delta_ = delta.longValue();
            if (negate) {
                delta_ = -delta_;
            }
            current = new Long(current.longValue()+delta_);
        }
        setTheProperty(getExportValue(null,current));
    }



    /**
     * Performs either of two string-specific operations (len or
     * strcat).
     * @since JWare/AntX 0.5
     **/
    protected void doStringOperation()
    {
        String value = null;
        int opI= getOp().getIndex();
        if (opI==Modification.STRLEN_INDEX) {
            value = String.valueOf(getWorkValue().length());
        }
        else if (opI==Modification.STRCAT_INDEX) {
            value = getTheProperty();
            if (value==null) {
                value = "";
            }
            value = value + getWorkValue();
        }
        setTheProperty(getExportValue(value,null));
    }




    /**
     * Performs the assignment operation of the current value to
     * the assigned variable.
     * @since JWare/AntX 0.3
     **/
    protected void doAssignOperation()
    {
        String value = getWorkValue();
        if (value==null) {
            String ermsg = getAntXMsg("assign.value.undefined",m_value.get());
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
        setTheProperty(getExportValue(value,Tk.NO_NUM_NUM));
    }



    /**
     * Performs a list concatenation operation. Uses the
     * current installed delimiter (default is a comma).
     * Supports index based insertion as: "+1{&lt;index&gt;};"
     * for example: "+l{3}".
     * @since JWare/AntXtras 3.0.0
     **/
    protected void doListOperation()
    {
        String delim = Iteration.defaultdefaults().delimiter(getProject(),"list",true,null);
        int at = -1;//END
        if (m_OpArgs!=null) {
            at = Tk.integerFrom(m_OpArgs,at);
        }
        String value = getTheProperty();
        if (value==null) {
            value = "";
        }
        if (at>=0) {
            List current = Tk.splitList(value,delim);
            if (at>current.size()) {
                String error = getAntXMsg("assign.badindex",String.valueOf(at));
                log(error,Project.MSG_ERR);
                throw new BuildException(error,getLocation());
            }
            current.add(at,getWorkValue());
            value = Tk.stringFrom(current,delim);
        } else {
            if (value.length()>0) {
                value += delim;
            }
            value = value + getWorkValue();
        }
        setTheProperty(getExportValue(value,null));
    }



    /**
     * Returns <i>true</i> if is just copy to property operation.
     **/
    private boolean isJustCopy()
    {
        return isUndefined() &&
            shortcutValue()==null &&
            getCopyProperty()!=null;
    }



    /**
     * Modifies this task's named property according to operation
     * and value definitions.
     * @throws BuildException if invalid parameters or current value
     *        cannot be modified in manner requested
     **/
    public void execute() throws BuildException
    {
        verifyCanExecute_("execute");

        if (isJustCopy()) {
            getProject().setNewProperty(getCopyProperty(),
                              getExportValue(getTheProperty(),Tk.NO_NUM_NUM));
            return;
        }

        switch (getOp().getIndex()) {
            case Modification.NOW_INDEX: {
                if (!isUndefined()) {
                    String warning = Errs.OneOrOtherAttribute("now",SRC_ATTRS);
                    log(warning, Project.MSG_WARN);
                }
                //+fall-through to assign
            }
            case Modification.SET_INDEX: {
                doAssignOperation();
                break;
            }
            case Modification.MINUS_NOW_INDEX: {
                String current = null;
                if (!isUndefined()) { current = getValue(); }
                else { current = getTheProperty(); }
                if (current!=null) {
                    Number from = Tk.numberFrom(current);
                    if (from!=Tk.NO_NUM_NUM) {
                        long diff = System.currentTimeMillis() - from.longValue();
                        if (diff<0) {
                            from= Tk.NO_NUM_NUM;
                        } else {
                            setShortcutValue(String.valueOf(diff));
                            doAssignOperation();
                            break;
                        }
                    }
                    if (from==Tk.NO_NUM_NUM) {
                        String ermsg = uistrs().get("assign.value.NAN",current);
                        log(ermsg, Project.MSG_ERR);
                        throw new BuildException(ermsg, getLocation());
                    }
                }
                doDeltaOperation(true);
                break;
            }
            case Modification.INC_INDEX:
            case Modification.INC_BY1_INDEX: {
                doDeltaOperation(false);
                break;
            }
            case Modification.DEC_INDEX:
            case Modification.DEC_BY1_INDEX: {
                doDeltaOperation(true);
                break;
            }
            case Modification.LCAT_INDEX: {
                doListOperation();
                break;
            }
            default: {
                doStringOperation();
                break;
            }
        }

        if (getCopyProperty()!=null) {
            getProject().setNewProperty(getCopyProperty(), getTheProperty());
        }
    }


    private static final Long INITIAL_NUMI= Long.valueOf(0L);
    private static final Double INITIAL_NUMF= new Double(0.0f);
    private static final DecimalFormat DFI = new DecimalFormat("#.###");//NB:90+% expects

    private String m_name;
    private FlexString m_value = new FlexString();
    private String m_copyProperty;
    private Modification m_Op= Modification.SET;
    private String m_OpArgs;//OPTIONAL
    private Scope m_scope= Scope.DEFAULT_SCOPE;
    private String m_shortcutValue;
    private ValueTransform m_T;//NB: none-by-default
}

/* end-of-AssignTask.java */
