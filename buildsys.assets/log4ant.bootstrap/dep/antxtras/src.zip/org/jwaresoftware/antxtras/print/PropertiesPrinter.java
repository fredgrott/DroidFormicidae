/**
 * $Id: PropertiesPrinter.java 1419 2012-07-31 16:13:43Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.PrintStream;
import  java.util.Properties;

/**
 * Helper to print a properties object without encoding. Useful for a diagnostic
 * view of a properties object (as opposed to a store-it view).
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008,2011-2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class PropertiesPrinter extends XPropertiesPrinter
{
    /**
     * Generate a succinct text output of the given properties object.
     * @param p [optional] the properties object
     * @param out output stream (non-null)
     **/
    public final static void print(Properties p, PrintStream out)
    {
        print(p,out,PlainLine);
    }

    private PropertiesPrinter() { }
}

/* end-of-PropertiesPrinter.java */
