/**
 * $Id: DoWhileTaskSet.java 1486 2012-08-20 00:16:28Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol;

import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.ScopedProperties;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;
import  org.jwaresoftware.antxtras.rules.RulesTk;
import  org.jwaresoftware.antxtras.starters.TaskSet;

/**
 * Taskset that is executed as long as a named condition evaluates <i>true</i>.
 * Usually defined as <span class="src">&lt;dowhile&gt;</span>.
 * <p>
 * While the DoWhileTaskSet can provide a set of overlaid properties to its test,
 * unlike the <span class="src">doforeach</span> type loop tasks, a DoWhileTaskSet
 * does not isolate its sub-tasks' execution from the current project.
 * This means that a DoWhileTaskSet nested tasks can always access (and alter)
 * fixture elements created and/or modified by the loop criteria task. (Of course
 * you can manually isolate the nested tasks inside an AntXtras
 * <span class="src">&lt;isolate&gt;</span> bubble taskset.)
 * <p>
 * Setting a DoWhileTaskSet quiet does not affect(ie&#46; default) the feedback
 * levels of its nested tasks.
 * <p>
 * <b>Example Usage:</b><pre>
 * &lt;macrodef name="waitForCluster"&gt; 
 *   &lt;attribute name="sleepsecs" default="30"/&gt;
 *   &lt;attribute name="maxloops" default=20"/&gt;
 *   &lt;sequential&gt;
 *      &lt;tallyset id="cluster.unavailable"&gt;
 *        &lt;not&gt;
 *          &lt;http url="${wl.adm.ping.url}"/&gt;
 *          &lt;http url="${wl.mi1.ping.url}"/&gt;
 *          &lt;http url="${wl.mi2.ping.url}"/&gt;
 *          &lt;http url="${wl.mi3.ping.url}"/&gt;
 *        &lt;/not&gt;
 *      &lt;/tallyset&gt;
 *      &lt;<b>dowhile</b> test="cluster.unavailable" maxloops="@{maxloops}" haltifmax="yes"&gt;
 *        &lt;emit:show messageid="msg.wl.unavailable" arg1="${$iso:}"/&gt;
 *        &lt;sleep seconds="@{sleepsecs}"/&gt;
 *      &lt;/dowhile&gt;
 *    &lt;/sequential&gt;
 *  &lt;macrodef&gt;
 *  ...
 *  &lt;waitForCluster sleepsecs="10"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010,2012 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   single
 * @.group    api,infra
 **/

public class DoWhileTaskSet extends TaskSet implements HardLimitEnabled
{
    /**
     * Initializes a new DoWhileTaskSet instance.
     **/
    public DoWhileTaskSet()
    {
        super(AntX.flowcontrol+"DoWhileTaskSet:");
        setWithLocals(true);
    }



    /**
     * Defines the test for this repeat taskset. The referred to
     * object must implement either the <span class="src">Condition</span>
     * or <span class="src">ShareableCondition</span> interface.
     * The reference is verified when this task is executed.
     * @param testRef reference of test definition (non-null)
     **/
    public void setCriteria(Reference testRef)
    {
        require_(testRef!=null,"setTest- nonzro test ref");
        m_conditionId = testRef;
    }



    /**
     * Synonym for {@linkplain #setCriteria(Reference) setCriteria}.
     * @param testRef reference to test definition (non-null)
     **/
    public final void setTest(Reference testRef)
    {
        setCriteria(testRef);
    }



    /**
     * Returns this taskset's test's reference. Will return
     * <i>null</i> if never set explicitly. Must be defined before
     * this taskset is executed.
     **/
    public final String getCriteria()
    {
        return (m_conditionId==null) ? null : m_conditionId.getRefId();
    }



    /**
     * Gives this loop task a hard limit for the number of times
     * it can execute. This attribute serves mostly as an error
     * handling mechanism to prevent infinite loops.
     **/
    public void setMaxLoops(int maxLoops)
    {
        m_maxLoops = maxLoops>=0 ? maxLoops : Integer.MAX_VALUE;
    }



    /**
     * Returns <i>true</i> if this repeating taskset has a hard limit.
     **/
    public final boolean hasMax()
    {
        return m_maxLoops!=Integer.MAX_VALUE;
    }



    /**
     * Returns this loop task's hard limit or <span class="src">-1</span>
     * if no such limit exists.
     **/
    public final int getMaxLoops()
    {
        return hasMax() ? m_maxLoops : -1;
    }



    /**
     * Tells this repeating taskset whether to fail if its hard limit is
     * reached. Ignored if this loop task does not have a hard limit.
     * @see #setMaxLoops setMaxLoops(LIMIT)
     **/
    public void setHaltIfMax(boolean halt)
    {
        m_haltIfMax = halt ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this taskset's halt-if-max option setting. Will
     * return <i>null</i> if never set explicitly. By default this
     * taskset will <em>not</em> fail if its hard limit is hit; it
     * just stops.
     **/
    public final Boolean getHaltIfMax()
    {
        return m_haltIfMax;
    }



    /**
     * Tells this taskset how much non-diagnostic feedback to generate.
     * Really only has "loud" vs. "quiet-ish" interpretation. If
     * set quiet, this taskset will not issue a warning if it hits a
     * hard limit.
     * @param level feedback level (non-null)
     **/
    public void setFeedback(String level)
    {
        require_(level!=null,"setFeedback- nonzro level");
        FeedbackLevel fbl = FeedbackLevel.from(level);
        if (fbl==null) {
            String e = Errs.IllegalParameterValue(getTaskName(),"feedback",level);
            log(e, Project.MSG_WARN);
            fbl = FeedbackLevel.NORMAL;
        }
        m_fbLevel = fbl;
    }



    /**
     * Returns this taskset's assigned feedback level. Will return
     * <i>null</i> if never set explicitly.
     **/
    public final FeedbackLevel getFeedbackLevel()
    {
        return m_fbLevel;
    }




    /**
     * Tells this repeating taskset to overlay its current loop
     * cursor value as a property with the given name when its test
     * is called. Unlike the foreach type loops, this is <em>not</em>
     * a required parameter for repeating tasksets.
     * @param cursorName the loop cursor name (as seen by the test)
     **/
    public void setI(String cursorName)
    {
        require_(cursorName!=null,"setI- nonzro name");
        m_iName = cursorName;
    }



    /**
     * Returns this repeating taskset's cursor overlay property's
     * name. Will return <i>null</i> if not set explicitly.
     **/
    public final String getCursorName()
    {
        return m_iName;
    }



    /**
     * Assigns an evaluation context to this repeating taskset. How the
     * context is used by the test is unknown to this taskset. The context
     * can refer to an AntXtras properties list, an Ant propertyset, or 
     * any other object that can be transformed into a properties holder.
     * @param refid reference to collection of key-value settings
     * @see org.jwaresoftware.antxtras.types.PropertiesList PropertiesList
     **/
    public void setContext(Reference refid)
    {
        m_evalContext = refid;
    }



    /**
     * Returns this taskset's evaluation context. Will return
     * <i>null</i> if no context was assigned explicitly.
     **/
    public final Reference getContext()
    {
        return m_evalContext;
    }



    /**
     * Ensures we have been given a test reference and that it is
     * valid. Will also verify that we do not have a always fail
     * situation.
     * @throws BuildException if improperly configured.
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (m_conditionId==null) {
            String error = getAntXMsg(Errs.TNTA, getTaskName(),"criteria");
            log(error, Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
        String testId = getCriteria();
        RulesTk.verifyTest(testId,m_rqlink);

        if (getMaxLoops()==0 && getHaltIfMax()==Boolean.TRUE) {
            if (getFeedbackLevel()!=FeedbackLevel.NONE) {//?always-warn?
                String e = getAntXMsg("flow.loop.alwaysfail");
                log(e, Project.MSG_WARN);
            }
        }
    }



    /**
     * Performs this taskset's nested elements until its named criteria
     * is no longer met.
     * @throws BuildException if verification fails.
     * @throws BuildException if any nested task does.
     * @throws BuildException if hard limit it and haltifmax is turned on.
     **/
    protected void performNestedTasks() throws BuildException
    {
        final String testId = m_conditionId.getRefId();
        int i=0;
        final int n=m_maxLoops;

        while (i<n) {
            boolean continu;
            ScopedProperties overlay = installCriteriaOverlay(i,getContext());
            try {
                continu = RulesTk.evalTest(testId,m_rqlink);
            } finally {
                uninstallCriteriaOverlay(overlay);
                overlay = null;
            }
            if (!continu) {
                break;
            }
            performIterationOfTheTasksList();
            i++;
        }

        if (i==n) {
            String msg = getMsg();
            if (Tk.isWhitespace(msg)) {
                msg = getAntXMsg("flow.loop.overflow",String.valueOf(i));
            }
            if (getHaltIfMax()==Boolean.TRUE) {
                log(msg, Project.MSG_ERR);
                throw new BuildException(msg, getLocation());
            }
            if (!FeedbackLevel.isQuietish(m_fbLevel,false)) {
                log(msg, Project.MSG_WARN);
            }
        }
    }



    /**
     * Installs all of our context properties and switch value
     * as an overlay before calling condition.
     **/
    private ScopedProperties installCriteriaOverlay(int i, Reference context)
    {
        Project P= getProject();
        ScopedProperties overlay=null;

        //NB: Ordering is important; let the switch.value prevail!
        if (context!=null) {
            Properties values = FixtureExaminer.getReferencedProperties(P,context.getRefId(),null);
            if (values!=null) {
                overlay = new ScopedProperties(P,true);
                overlay.put(values);
            }
        }
        if (getCursorName()!=null) {
            if (overlay==null) {
                overlay = new ScopedProperties(P,true);
            }
            overlay.put(getCursorName(), String.valueOf(i));
        }
        if (overlay!=null) {
            overlay.install(m_rqlink);
        }
        return overlay;
    }




    /**
     * Undoes the effect of {@linkplain #installOverlay installOverlay}.
     **/
    private void uninstallCriteriaOverlay(ScopedProperties overlay)
    {
        if (overlay!=null) {
            overlay.uninstall(m_rqlink);
            overlay=null;
        }
    }



    private Requester m_rqlink = new Requester.ForComponent(this);
    private Reference m_conditionId;
    private int m_maxLoops = Integer.MAX_VALUE;
    private Boolean m_haltIfMax;//NB: *NO*
    private FeedbackLevel m_fbLevel;
    private String m_iName;//NB: null => none
    private Reference  m_evalContext;
}


/* end-of-DoWhileTaskSet.java */