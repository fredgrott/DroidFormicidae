/**
 * $Id: NewRefIdFunctionShortcut.java 1176 2010-11-14 11:56:53Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.construct;

import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.SIDs;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that generates a new reference id that does not already exist in
 * the named project. Very useful in tests and SAMS artifact definition methods that
 * need to add data objects to the current project's fixture without worrying about name
 * collisons. Be careful when using this funcut as part of an overlaid property's
 * value&#8212; the value <em>will change everytime</em> the property is dereferenced!
 * <p/>
 * The general URI format: <span class="src">$newrefid:[prefix][?variable-name]</span>
 * where <span class="src">prefix</span> is an optional prefix that is used in new
 * reference name (useful for debugging), and <span class="src">variable-name</span> is
 * the name of the variable that should be updated with the new id.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;assign var="myjunit" value="${<b>$newrefid:junit</b>}"/&gt;
 *  &lt;createtask name="${$var:myjunit}"...&gt;
 * -OR (better)-
 *  &lt;createtask name="${<b>$newrefid:junit?myjunit</b>}"&gt;
 *     &lt;junit.../&gt;
 *  &lt;/createtask&gt;
 *
 * -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="newrefid"
 *           value="${ojaf}.construct.NewRefIdFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @see       RandomFunctionShortcut
 **/

public final class NewRefIdFunctionShortcut extends FunctionShortcutSkeleton
{
    private static final String DEFAULT_PREFIX= "refid";

    /**
     * Initalizes a new (unique) refid value generator.
     **/
    public NewRefIdFunctionShortcut()
    {
        super();
    }


    /**
     * Returns a project-unique reference identifier. If the name of
     * a variable is not provided, the reference object should be
     * inserted ASAP to minimize the collison potential.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project project = clnt.getProject();
        String variable = null;

        String prefix = DEFAULT_PREFIX;
        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            prefix = uriFragment.substring(0,i);
            i += SCHEME_DELIMITER_LEN;
            if (prefix.length()==0) {
                prefix = DEFAULT_PREFIX;
            } else {
                prefix = Tk.resolveString(project,prefix,true);
            }
            if (i<uriFragment.length()) {
                variable = Tk.resolveString(project,uriFragment.substring(i),true);
            }
        } else if (uriFragment.length()>0) {
            prefix = Tk.resolveString(project,uriFragment,true);
        }

        final Map refs = clnt.getProject().getReferences();
        SIDs.Finder refidFinder = new SIDs.Finder() {
                public boolean exists(String sid) {
                    return refs.containsKey(sid);
                }
            };
        String refid;
        synchronized(refs) {
            refid = SIDs.next(refidFinder,prefix);
            if (!Tk.isWhitespace(variable)) {
                refs.put(refid,FixtureExaminer.PENDING_REFERENCE);
                Variables.set(variable,refid,clnt);
            }
        }
        return refid;
    }
}

/* end-of-NewRefIdFunctionShortcut.java */