/**
 * $Id: ProjectDependentSkeleton.java 932 2009-12-28 21:34:03Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.LogEnabled;
import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;

/**
 * Starting point for a simple AntXras utility or helper that depends
 * on a project to perform its function.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2006,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.5.0b2
 * @.safety  single
 * @.group   impl,helper
 * @.impl    Must exist outside of starters package as it's used by helpers
 **/

public abstract class ProjectDependentSkeleton implements ProjectDependent, LogEnabled
{
    /**
     * Initializes this project dependent object.
     **/
    protected ProjectDependentSkeleton()
    {
    }


    /**
     * Initializes this project dependent object with specific project.
     * @param P the project
     * @since JWare/AntXtras 2.1.0
     **/
    protected ProjectDependentSkeleton(Project P)
    {
        m_P = P;
    }


    /**
     * (Re)initialize this dependent target project.
     * @param P the project
     **/
    public void setProject(Project P)
    {
        m_P = P;
    }



    /**
     * Returns this object's targeted project. Can return
     * <i>null</i> if this attribute never defined.
     **/
    public Project getProject()
    {
        return m_P;
    }


    /**
     * Returns this object's targeted project ensuring the
     * reference is not <i>null</i>. Calls {@linkplain #getProject}.
     * @throws IllegatStateException if project is <i>null</i>.
     **/
    protected final Project getProjectNoNull()
    {
        Project P= getProject();
        AntX.verify_(P!=null,AntX.AntX+"ProjectDependent:","getProj- inited");
        return P;
    }



    /**
     * Logs given message to our project if project exists.
     * Otherwise, writes message to stdout.
     * @param message the message (non-null)
     * @since JWare/AntX 0.5
     **/
    public void log(String message)
    {
        Project P = getProject();
        if (P!=null) {
            P.log(message);
        } else {
            LogEnabled.SYSTEM.log(message);
        }
    }



    /**
     * Logs given message at named level to our project if
     * project exists. Otherwise, writes message to stdout
     * or stderr.
     * @param message the message (non-null)
     * @param msgLevel message noise level
     * @since JWare/AntX 0.5
     **/
    public void log(String message, int msgLevel)
    {
        Project P = getProject();
        if (P!=null) {
            P.log(message,msgLevel);
        } else {
            LogEnabled.SYSTEM.log(message,msgLevel);
        }
    }



    private Project m_P;
}

/* end-of-ProjectDependentSkeleton.java */
