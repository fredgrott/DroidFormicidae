/**
 * $Id: NowFunctionShortcut.java 1225 2011-08-13 19:15:37Z ssmc $
 * Copyright (c) 2002-2012 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.text.SimpleDateFormat;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.DateTimeFormat;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that captures the timestamp for "now". Can also
 * be used to capture the delta between "now" and a previously 
 * captured timestamp.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   1) &lt;assign var="start" value=${$now:}"/&gt;
 *         <i>[...work work work...]</i>
 *      &lt;assign var="delta" value="${$now:--${$var:start}}"/&gt;
 *      &lt;emit message="duration(${stage},${$var:delta|$duration:})"/&gt;
 *   
 *   2) &lt;echo message="It is: ${$now:dd-MMM h:mm a}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="now"
 *             value="${ojaf}.datetime.NowValueURIHandler"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009,2011 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.5.0b2
 * @.safety   multiple
 * @.group    api,helper
 * @see       org.jwaresoftware.antxtras.variables.AssignTask
 **/

public final class NowFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new $now: shortcut handler.
     **/
    public NowFunctionShortcut()
    {
    }


    /**
     * Returns now timestamp as a long unless a format string also
     * specified.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final long now = now();
        if (uriFragment.length()==0) {
            return String.valueOf(now);
        }
        String query = uriFragment.toLowerCase();
        if (query.startsWith("++") || query.startsWith("--")) {
            long time = now;
            long delta = Tk.longFrom(query.substring(2),-1L);
            if (delta>=0) {
                if (query.charAt(0)=='+') {
                    time += delta;
                } else {
                    time -= delta;
                }
            }
            return String.valueOf(time);
        }
        SimpleDateFormat df = new SimpleDateFormat(uriFragment);
        return DateTimeFormat.format(now,df);
    }


    /**
     * Tells this handler what "now" means. Never used from live shortcut
     * handling mechanism; only for testing and stubs.
     * @param timestamp the required value of "now" (>=0L)
     * @.impl Used for testing this class.
     * @since JWare/AntXtras 2.0.0
     **/
    public void setNow(long timestamp)
    {
        AntX.require_(timestamp>=0L,AntX.utilities+"NowFunctionShortcut:",
                      "setnow- valid timstamp");
        m_nowTS = timestamp;
    }


    /** Factory method for "now" which permits testing. **/
    private long now()
    {
        return m_nowTS<0L ? System.currentTimeMillis() : m_nowTS;
    }


    private long m_nowTS = -1L;
}

/* end-of-NowFunctionShortcut.java */